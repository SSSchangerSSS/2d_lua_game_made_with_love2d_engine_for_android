


function PLAYER_functions()


if player.x - speed * scale_x < 6/2 * scale_x then
	player.x = 7/2 * scale_x
end

--Code for shooting :: starts here


--light gun
if should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false and 
PASSING_FINISHeD_GAME == 0 and
(enemys[1].isAlive == true or
enemys[2].isAlive == true ) or amuzeshi_gameplay == true then

bulletspeed = 7/2

if shootTime > 15 then
    shotFire = false
end

if shootTime > 30 then
	canshoot = true
end
if shootTime <= 30 then
    canshoot = false
    shootTime = shootTime + 1
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets[i].x > 800/2 * scale_x then 
	bullets[i].visible = false
end
end
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets == nil or bullets[i] == nil then
break    
elseif bullets[i].visible == false then
	table.remove(bullets , i)
end
end
end

if #bullets >= 1 then
for s = 1 ,#bullets do
if bullets[s].visible ~= false then 
	bullets[s].x = bullets[s].x + bulletspeed * scale_x
end
end
end
end



--hand gun

if not((should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false) and 
enemys[1].isAlive == true or
enemys[2].isAlive == true ) and handle_SHOT_GUN == false and handle_HEAVY_GUN == false and handle_LAZER_GUN == false and not (handle_HEAVY_GUN == true) and amuzeshi_gameplay == false then

bulletspeed = 12/2

if shootTime > 15 then
    shotFire = false
end

if shootTime > 35 then
	canshoot = true
end
if shootTime <= 35 then
    canshoot = false
    shootTime = shootTime + 1
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets[i].x > 800/2  * scale_x then 
	bullets[i].visible = false
end
end
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets == nil or bullets[i] == nil then
break    
elseif bullets[i].visible == false then
	table.remove(bullets , i)
end
end
end

if #bullets >= 1 then
for s = 1 ,#bullets do
if bullets[s].visible ~= false then 
	bullets[s].x = bullets[s].x + bulletspeed * scale_x
end
end
end
end




--shot gun

if handle_SHOT_GUN == true and amuzeshi_gameplay == false then

bulletspeed = 8/2

if shootTime > 13 then
    shotFire = false
end

if shootTime > 25 then
    canshoot = true
end
if shootTime <= 25 then
    canshoot = false
    shootTime = shootTime + 1
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets[i].x > 800/2 * scale_x then 
    bullets[i].visible = false
end
end
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets == nil or bullets[i] == nil then
break    
elseif bullets[i].visible == false then
    table.remove(bullets , i)
end
end
end

if #bullets >= 1 then
for s = 1 ,#bullets do
if bullets[s].visible ~= false then 
    bullets[s].x = bullets[s].x + bulletspeed * scale_x
end
end
end
end





--heavy gun

if handle_HEAVY_GUN == true and amuzeshi_gameplay == false then

bulletspeed = 10/2

if shootTime > 13 then
    shotFire = false
end

if shootTime > 15 then
    canshoot = true
end
if shootTime <= 15 then
    canshoot = false
    shootTime = shootTime + 1
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets[i].x > 800/2 * scale_x then 
    bullets[i].visible = false
end
end
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets == nil or bullets[i] == nil then
break    
elseif bullets[i].visible == false then
    table.remove(bullets , i)
end
end
end

if #bullets >= 1 then
for s = 1 ,#bullets do
if bullets[s].visible ~= false then 
    bullets[s].x = bullets[s].x + bulletspeed * scale_x
end
end
end
end






--lazer gun

if handle_LAZER_GUN == true and amuzeshi_gameplay == false then

bulletspeed = 20/2

if shootTime > 13 then
    shotFire = false
end

if shootTime > 30 then
    canshoot = true
end
if shootTime <= 30 then
    canshoot = false
    shootTime = shootTime + 1
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets[i].x > 800/2 * scale_x then 
    bullets[i].visible = false
end
end
end

if #bullets >= 1 then
for i = 1 , #bullets do
if bullets == nil or bullets[i] == nil then
break    
elseif bullets[i].visible == false then
    table.remove(bullets , i)
end
end
end

if #bullets >= 1 then
for s = 1 ,#bullets do
if bullets[s].visible ~= false then 
    bullets[s].x = bullets[s].x + bulletspeed * scale_x
end
end
end
end



--Code for shooting :: ends here



--Code for jumping :: starts here


if jumped == true and Jumptiming < JumpTime then 
Jumptiming = Jumptiming + 0.06
jumping = true    
gravityT = gravityT + 0.4
player.y = player.y - (gravity/2 * 0.024) * gravityT  * scale_y
end

if jumped == true and Jumptiming >= JumpTime then
Jumptiming = 0
jumping = true
gravityT = 1
jumped = false
end

if jumped == false and player.y < GROUND then
jumping = true
gravityT = gravityT + 0.4
player.y = player.y + (gravity/2 * .018) * gravityT  * scale_y
end

if player.y >= GROUND then
player.y = GROUND
gravityT = 1
jumping = false
end

if jumping == true and ducking == false then
if player.health >= 3 then
player.img = playerJumping
end
if player.health == 2 then
player.img = playerJumpingWithTwobattry
end
if player.health == 1 then
player.img = playerJumpingWithOnebattry
end
end





--Code for jumping :: ends here

end








function BOSS_WALK()


if BOSS_WALKING_frameSpeed >= 5 * 0.018 then
BOSS_WALKING_frameSpeed = 0


if BOSS_WALKING_frame < 12 then
    BOSS_WALKING_frame = BOSS_WALKING_frame + 1
else
    BOSS_WALKING_frame = 1
end

else

BOSS_WALKING_frameSpeed = BOSS_WALKING_frameSpeed + 0.028

end


BOSS_WALKING_IMG = BOSS_WALKING[BOSS_WALKING_frame]


end





function BOSS2_WALK()


if BOSS2_WALKING_frameSpeed >= 5 * 0.018 then
BOSS2_WALKING_frameSpeed = 0


if BOSS2_WALKING_frame < 7 then
    BOSS2_WALKING_frame = BOSS2_WALKING_frame + 1
else
    BOSS2_WALKING_frame = 1
end

else

BOSS2_WALKING_frameSpeed = BOSS2_WALKING_frameSpeed + 0.028

end


BOSS2_WALKING_IMG = BOSS2_WALKING[BOSS2_WALKING_frame]


end


function BOSS3_WALK()


if BOSS3_WALKING_frameSpeed >= 5 * 0.018 then
BOSS3_WALKING_frameSpeed = 0


if BOSS3_WALKING_frame < 7 then
    BOSS3_WALKING_frame = BOSS3_WALKING_frame + 1
else
    BOSS3_WALKING_frame = 1
end

else

BOSS3_WALKING_frameSpeed = BOSS3_WALKING_frameSpeed + 0.028

end


BOSS3_WALKING_IMG = BOSS3_WALKING[BOSS3_WALKING_frame]


end