-- constructor :: starts here
guns = { x , y , img }

function guns:new( o )
o = o or {}
setmetatable( o , self )    
self.__index = self
return o
end
--constructor :: ends here
function guns:update()
  
--light gun  
   if should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false and 
PASSING_FINISHeD_GAME == 0 and
(enemys[1].isAlive == true or
enemys[2].isAlive == true ) or amuzeshi_gameplay == true then

AMMO_BULLET = AMMO_BULLET_HANDGUN
if movingRight == true and jumping == false and movingLeft == false and ducking == false  then
self.x = player.x  self.y = player.y - 8/2 * scale_y self.img = lightGun
end

if jumping == true and ducking == false then
self.x = player.x  self.y = player.y - 8/2 * scale_y self.img = lightGun 
end

if jumping == true and movingLeft == true and ducking == false and movingRight == false then
self.x = player.x - 114/2 * scale_x self.y = player.y - 8/2 * scale_y self.img = lightGunMovingLeft
end	

if movingRight == false and jumping == false and movingLeft == false and ducking == false then
self.x = player.x  self.y = player.y - 8/2 * scale_y self.img = lightGun
end

if movingLeft == true and jumping == false and movingRight == false and ducking == false then
self.x = player.x - 114/2 * scale_x self.y = player.y - 8/2 * scale_y self.img = lightGunMovingLeft
end

if ducking == true and jumping == false then
self.x = player.x - 48/2 * scale_x self.y = player.y - 7/2 * scale_y self.img = lightGunDucked
end

-- hand gun
  elseif not((should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false) and 
enemys[1].isAlive == true or
enemys[2].isAlive == true ) and handle_SHOT_GUN == false and handle_HEAVY_GUN == false and handle_LAZER_GUN == false and not (handle_HEAVY_GUN == true) and amuzeshi_gameplay == false then

AMMO_BULLET = AMMO_BULLET_HANDGUN
if movingRight == true and jumping == false and movingLeft == false and ducking == false  then
self.x = player.x  self.y = player.y - 8/2 * scale_y self.img = HAND_GUN
end

if jumping == true and ducking == false then
self.x = player.x  self.y = player.y - 8/2 * scale_y self.img = HAND_GUN 
end

if jumping == true and movingLeft == true and ducking == false and movingRight == false then
self.x = player.x - 114/2 * scale_x self.y = player.y - 8/2 * scale_y self.img = HAND_GUN_MOVINGLEFT
end	

if movingRight == false and jumping == false and movingLeft == false and ducking == false then
self.x = player.x  self.y = player.y - 8/2 * scale_y self.img = HAND_GUN
end

if movingLeft == true and jumping == false and movingRight == false and ducking == false then
self.x = player.x - 114/2 * scale_x self.y = player.y - 8/2 * scale_y self.img = HAND_GUN_MOVINGLEFT
end

if ducking == true and jumping == false then
self.x = player.x - 48/2 * scale_x self.y = player.y - 7/2 * scale_y self.img = HAND_GUN_DUCKED
end


-- shot gun
  elseif handle_SHOT_GUN == true and amuzeshi_gameplay == false then

AMMO_BULLET = AMMO_BULLET_SHOT_GUN 

if movingRight == true and jumping == false and movingLeft == false and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = SHOT_GUN
end

if jumping == true and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = SHOT_GUN 
end

if jumping == true and movingLeft == true and ducking == false and movingRight == false then
 self.x = player.x - 46/2 * scale_x self.y = player.y self.img = SHOT_GUN_MOVINGLEFT
end	

if movingRight == false and jumping == false and movingLeft == false and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = SHOT_GUN 
end

if movingLeft == true and jumping == false and movingRight == false and ducking == false then
 self.x = player.x - 46/2 * scale_x self.y = player.y self.img = SHOT_GUN_MOVINGLEFT
end

if ducking == true and jumping == false then
self.x = player.x + 35/2 * scale_x self.y = player.y - 15/2 * scale_y self.img = SHOT_GUN_DUCKED
end

-- heavy gun
  elseif handle_HEAVY_GUN == true and amuzeshi_gameplay == false then

AMMO_BULLET = AMMO_BULLET_HEAVYGUN

if movingRight == true and jumping == false and movingLeft == false and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = heavyGun
end

if jumping == true and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = heavyGun 
end

if jumping == true and movingLeft == true and ducking == false and movingRight == false then
 self.x = player.x - 46/2 * scale_x self.y = player.y self.img = heavyGunMovingLeft
end	

if movingRight == false and jumping == false and movingLeft == false and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = heavyGun 
end

if movingLeft == true and jumping == false and movingRight == false and ducking == false then
 self.x = player.x - 46/2 * scale_x self.y = player.y self.img = heavyGunMovingLeft
end

if ducking == true and jumping == false then
self.x = player.x + 35/2 * scale_x self.y = player.y - 15/2 * scale_y self.img = heavyGunDucked
end


-- lazer gun

  elseif handle_LAZER_GUN == true and amuzeshi_gameplay == false then

AMMO_BULLET = AMMO_BULLET_LAZER_GUN

if movingRight == true and jumping == false and movingLeft == false and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = LAZER_GUN
end

if jumping == true and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = LAZER_GUN 
end

if jumping == true and movingLeft == true and ducking == false and movingRight == false then
 self.x = player.x - 46/2 * scale_x self.y = player.y self.img = LAZER_GUN_MOVINGLEFT
end	

if movingRight == false and jumping == false and movingLeft == false and ducking == false then
self.x = player.x - 20/2 * scale_x self.y = player.y  self.img = LAZER_GUN
end

if movingLeft == true and jumping == false and movingRight == false and ducking == false then
 self.x = player.x - 46/2 * scale_x self.y = player.y self.img = LAZER_GUN_MOVINGLEFT
end

if ducking == true and jumping == false then
self.x = player.x + 35/2 * scale_x self.y = player.y - 15/2 * scale_y self.img = LAZER_GUN_DUCKED
end



end

end
-- guns class :: starts here