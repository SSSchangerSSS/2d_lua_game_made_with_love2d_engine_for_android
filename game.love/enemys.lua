--enemy_helicoopter calss :: starts here



--constructor :: starts here



enemys_helicoopter = { x , y , img = nil , health = 2 , isAlive = true , goingUp = true , goingDown = false , helicoopter = {} , EBullets = {} , shouldAttack = false , attackSpeed = 0 , TIMEFORDIE = 0 , X_TIMEFORDIE = nil , X_TIME = false , changeforpicture = 0 , hit_effect_start = false , hit_effect_TIME = 0}




--Animation clip for enemy_helicoopter




enemys_helicoopter.helicoopter[1] = love.graphics.newImage('crowenemy1.png')
enemys_helicoopter.helicoopter[2] = love.graphics.newImage('crowenemy2.png')
enemys_helicoopter.helicoopter[3] = love.graphics.newImage('crowenemy3.png')
enemys_helicoopter.helicoopter[4] = love.graphics.newImage('crowenemy4.png')
enemys_helicoopter.helicoopter[5] = love.graphics.newImage('crowenemynumber2_1.png')
enemys_helicoopter.helicoopter[6] = love.graphics.newImage('crowenemynumber2_2.png')
enemys_helicoopter.helicoopter[7] = love.graphics.newImage('crowenemynumber2_3.png')
enemys_helicoopter.helicoopter[8] = love.graphics.newImage('crowenemynumber2_4.png')
enemys_helicoopter.helicoopter[9] = love.graphics.newImage('crowenemynumber3_1.png')
enemys_helicoopter.helicoopter[10] = love.graphics.newImage('crowenemynumber3_2.png')
enemys_helicoopter.helicoopter[11] = love.graphics.newImage('crowenemynumber3_3.png')
enemys_helicoopter.helicoopter[12] = love.graphics.newImage('crowenemynumber3_4.png')
enemys_helicoopter.helicoopter_frameSpeed = 0
enemys_helicoopter.helicoopter_frame = 1








--the end!



function enemys_helicoopter:new(o)
o = o or {}
setmetatable(o , self)
self.__index = self 
return o
end



--constructor ends :: here



--basic Ai starts :: here



function enemys_helicoopter:Ai()
    if self.goingUp == true and self.goingDown == false then
        if self.changeforpicture == 1 then
            self.y = self.y - 4/2 * scale_y
        
        if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.y = self.y - 1/2 * scale_y
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.y = self.y - 2/2 * scale_y
        
        end


        end
        
        if self.changeforpicture == 2 then
            self.y = self.y - 5/2 * scale_y
        
        if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.y = self.y - 1/2 * scale_y
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.y = self.y - 2/2 * scale_y
        
        end



        end
        
        if self.changeforpicture == 3 then
            self.y = self.y - 6/2 * scale_y
            
        if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.y = self.y - 1/2 * scale_y
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.y = self.y - 2/2 * scale_y
        
        end   
    
        end
    
    end
    if self.y <= 20/2 * scale_y then
            self.goingUp = false
            self.goingDown = true
    end
    if self.goingDown == true and self.goingUp == false then
        if self.changeforpicture == 1 then
            self.y = self.y + 4/2 * scale_y
        

        if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.y = self.y + 1/2 * scale_y
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.y = self.y + 2/2 * scale_y
        
        end

        end
        
        if self.changeforpicture == 2 then
            self.y = self.y + 5/2 * scale_y
        
        
        if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.y = self.y + 1/2 * scale_y
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.y = self.y + 2/2 * scale_y
        
        end

        end
        
        if self.changeforpicture == 3 then
            self.y = self.y + 6/2 * scale_y
        
          
        if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.y = self.y + 1/2 * scale_y
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.y = self.y + 2/2 * scale_y
        
        end

        end
    
    end
    
    if self.y >= 360/2 * scale_y then
            self.goingUp = true
            self.goingDown = false
    end
end



--basic Ai ends :: here



--basic enemy_helicoopter shooting::starts here


function enemys_helicoopter:attack()
if self.shouldAttack == true then	
local nbullet = {x = self.x , y = self.y + 60/2 * scale_y , visible = true , img = nil}
if self.changeforpicture == 1 then
nbullet.img = loader.bulletE1
end
if self.changeforpicture == 2 then
nbullet.img = loader.bulletE2
end
if self.changeforpicture == 3 then
nbullet.img = loader.bulletE3
end
table.insert(self.EBullets,1,nbullet)
--self.attackSpeed = love.math.random(0,0.01)
self.attackSpeed = 0
self.shouldAttack = false	
end
end



function enemys_helicoopter:attack_update() 



if self.attackSpeed <= 1 then
    self.shouldAttack = false

   if self.changeforpicture == 1 then
   self.attackSpeed = self.attackSpeed + 0.0045 
   if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
   self.attackSpeed = self.attackSpeed + 0.0100 
   elseif PASSING_FINISHeD_GAME > 1 then
   self.attackSpeed = self.attackSpeed + 0.0150      
   end
   end
   if self.changeforpicture == 2 then
   self.attackSpeed = self.attackSpeed + 0.0055 
   if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
   self.attackSpeed = self.attackSpeed + 0.0110 
   elseif PASSING_FINISHeD_GAME > 1 then
   self.attackSpeed = self.attackSpeed + 0.0160      
   end
   end
   if self.changeforpicture == 3 then
   self.attackSpeed = self.attackSpeed + 0.0060 
   if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
   self.attackSpeed = self.attackSpeed + 0.0120 
   elseif PASSING_FINISHeD_GAME > 1 then
   self.attackSpeed = self.attackSpeed + 0.0170      
   end
   end

 --  local r = love.math.random(0.0020,0.0050)   

   
   
 --  self.attackSpeed = self.attackSpeed + r  



end

if self.attackSpeed > 1 then
    self.shouldAttack = true
end


if #self.EBullets >= 1 then

for s = 1 ,#self.EBullets do
if self.EBullets[s].visible ~= false then 

   if self.changeforpicture == 1 then
   self.EBullets[s].x = self.EBullets[s].x - 2/2 * scale_x 
   
if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.EBullets[s].x = self.EBullets[s].x - 1/2 * scale_x 
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.EBullets[s].x = self.EBullets[s].x - 1.4/2 * scale_x 
        
        end


   end
   
   if self.changeforpicture == 2 then
   self.EBullets[s].x = self.EBullets[s].x - 2.4/2 * scale_x
   
if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.EBullets[s].x = self.EBullets[s].x - 1/2 * scale_x
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.EBullets[s].x = self.EBullets[s].x - 1.4/2 * scale_x
        
        end


   end
   
   if self.changeforpicture == 3 then
   self.EBullets[s].x = self.EBullets[s].x - 2.8/2 * scale_x

if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.EBullets[s].x = self.EBullets[s].x - 1/2 * scale_x
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.EBullets[s].x = self.EBullets[s].x - 1.4/2 * scale_x
        
        end


   end

end
end




for i = 1 , #self.EBullets do
if self.EBullets[i].x < 10/2 * scale_x then 
self.EBullets[i].visible = false
end
end

for i = 1 , #self.EBullets do
if self.EBullets[i] == nil then
break
elseif self.EBullets[i].visible == false then
table.remove(self.EBullets,i)  
end
end


for i = 1 , #self.EBullets do
if self.EBullets[i] == nil then
break
end
if movingRight == true and movingLeft == false and jumping == false and ducking == false then
testCollision1 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true
--or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.EBullets[i].x , self.EBullets[i].y , 20 , 10) == true __shouldn't use
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true then	

table.remove(self.EBullets,i)

playerGETHIT()    

end
else
testCollision1 = false
end

if movingLeft == true and movingRight == false and jumping == false and ducking == false then
testCollision2 = true
if CheckCollision(rect6.x , rect6.y , rect6.w , rect6.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true 
or CheckCollision(rect7.x , rect7.y , rect7.w , rect7.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true
or CheckCollision(rect8.x , rect8.y , rect8.w , rect8.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true then


if player.health == 1 then
GAME_PlAY = false
end

table.remove(self.EBullets,i)

playerGETHIT()      

end
else
testCollision2 = false
end

if jumping == true and ducking == false then
testCollision3 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true
--or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.EBullets[i].x , self.EBullets[i].y , 20 , 10) == true __shouldn't use
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true then    


table.remove(self.EBullets,i) 

playerGETHIT()           

end
else
testCollision3 = false    
end

if ducking == true and movingRight == false and movingLeft == false and jumping == false then
testCollision4 = true
if CheckCollision(rect9.x , rect9.y , rect9.w , rect9.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true 
or CheckCollision(rect10.x , rect10.y , rect10.w , rect10.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true
or CheckCollision(rect11.x , rect11.y , rect11.w , rect11.h , self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true then

table.remove(self.EBullets,i)

playerGETHIT()      
  
  
end
else
testCollision4 = false
end


if self.EBullets[i] == nil then
break
end
if headofmamouth == HEADOFMAMOUTH[6] then
if  CheckCollision(self.EBullets[i].x , self.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y, BLOCKJUMPS[blockJumpForHelis].x , BLOCKJUMPS[blockJumpForHelis].y , BLOCKJUMPS[blockJumpForHelis].width , BLOCKJUMPS[blockJumpForHelis].height) == true then
self.EBullets[i].visible = false 
end
end



end       

end






end
  




function enemys_helicoopter:update_getHit()
for i = 1 , #bullets do
if bullets[i] == nil or bullets == nil then
break    
else
if CheckCollision( self.x + 23/2 * scale_x , self.y + 23/2 * scale_y , 50/2 * scale_x , 60/2 * scale_y , bullets[i].x , bullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true then 

-- bullets of LAZER gun cross the enemy
if handle_LAZER_GUN == false then
bullets[i].visible = false
end

scoore = scoore + 1

scoore_update()--function.lua

if self.health >=2 then
self.health = self.health - 1

if handle_LAZER_GUN == false then
self.hit_effect_start = true
end

else
self.isAlive = false    
self.hit_effect_TIME = 0
self.hit_effect_start = false
AMMO = AMMO + 3
break    
end
end
end
end
end
 

function enemys_helicoopter:draw_hit_effect()
if self.hit_effect_start == true then

self.hit_effect_TIME = self.hit_effect_TIME + 1

if self.hit_effect_TIME >= 30 then
self.hit_effect_TIME = 0
self.hit_effect_start = false
end

love.graphics.draw(hit_effect , self.x - 40/2 * scale_x , self.y , 0 , scale_x , scale_y)



end
end


function enemys_helicoopter:die()    


if self.EBullets ~= nil then
self:attack_update()
end
end


function enemys_helicoopter:reborn(r)
self.X_TIMEFORDIE = self.x	
if r == 0 then
self.changeforpicture = love.math.random(1,3)
elseif r == 1 then
self.changeforpicture = r + 1
elseif r == 2 then
self.changeforpicture = r + 1
elseif r == 3 then    
self.changeforpicture = r - 1
end    
if self.changeforpicture == 1 then
self.img = love.graphics.newImage('crowenemy1.png')
self.helicoopter_frame = 1
elseif self.changeforpicture == 2 then
self.img = love.graphics.newImage('crowenemynumber2_1.png')
self.helicoopter_frame = 5
elseif self.changeforpicture == 3 then
self.img = love.graphics.newImage('crowenemynumber3_1.png')
self.helicoopter_frame = 9
end 
local random = love.math.random(60/2,310/2) * scale_y
local random1 = love.math.random(-10/2,10/2) * scale_y
self.y = random + random1
self.goingUp = true 
self.goingDown = false
self.isAlive = true
self.health = 3
self.hit_effect_TIME = 0
self.hit_effect_start = false
end

--function(remove enemy will be neede)

--basic enemy_helicoopter shooting::ends here 



--enemy_helicoopter class :: ends here
















