
require ("PLAYER_FUNCTIONS")
require ("functions")
require ("Guns")
require ("enemys")
require ("BOSS")
require ("BOSS2")
require ("BOSS3")
require ("set_null")
require ("BIG_LOADER_LIB")
require ("clothes")


function love.load()


--connection: should work with release
--[[
love.graphics.draw(menu_pad_asli , 0 , 0 , 0 , scale_x , scale_y)
love.graphics.rectangle("fill" , 37.8*scale_x , 125.8*scale_y , 80 * scale_x , 45  * scale_y )



love.graphics.draw(connection, 0 , 0 , 0 , scale_x , scale_y)
--for safhe ersal nazarat
love.graphics.rectangle("fill" , 138*scale_x , 135*scale_y , 154 * scale_x , 50  * scale_y )
--for safhe ersal nazarat

--for safhe bazi
love.graphics.rectangle("fill" , 160*scale_x , 65.5 * scale_y , 106 * scale_x , 50 * scale_y)
--for safhe bazi


--for safhe email us
love.graphics.rectangle("fill" , 115*scale_x , 210 * scale_y , 205 * scale_x , 50 * scale_y)
--for safhe email us


--for bazgasht 
love.graphics.rectangle("fill" , 0 , 0 , 62.5 * scale_x , 80 * scale_y)
--for bazgasht

--]]


love.window.setMode(0, 0 --[[,{fullscreen = false}]])

screen_width = love.graphics.getWidth()
screen_height = love.graphics.getHeight()
width = 800/2
height = 530/2
scale_x = (screen_width/width)
scale_y = (screen_height/height)

--Continue as normal
love.window.setMode(screen_width, screen_height)-- , {fullscreen = true})
--love.window.setFullscreen(true, "exclusive")


loader = loading_all()
clothes_all = new_clothes()
clothes_all.set_first_hat_id()
clothes_all.set_hat()
clothes_all.set_first_belt_id()
clothes_all.set_belt()

nooooeeee = clothes_all.hat_id
nooooeeee_2 = clothes_all.belt_id



time_to_wait_helper = 3
time_to_wait_helper_bool = false
--for changing clothes:
--current_hat
--current_hat_to_show
--in set function load all hats and belts with names hat0_headleft -> 13

--current_belt

end











function love.draw()


if loader.should_start_the_game() then	


if studio_bool == false then	


if GAME_PlAY == false then




--deleting left bullets of all


bullets = {}


boss.helper.EBullets = {}


enemys[1].EBullets = {} 


enemys[2].EBullets = {} 


boss.BBullets = {}


boss2.BBullets = {}


boss3.BBullets = {}


boss3.BBullets1 = {}


boss3.BBullets2 = {}

--end





if SCORE_SAVE_BOOL == true then

if not love.filesystem.exists("save.txt") then
jupiter = require "jupiter"
data = {_fileName = "save.txt", scoore}
success = jupiter.save(data)
else


jupiter = require "jupiter"
newData = jupiter.load("save.txt")
newData[#newData+1] = scoore

function zsort(object1, object2)
    return object1 > object2
end

table.sort( newData, zsort )

if #newData > 9 then
for i = 10 , #newData do	

table.remove(newData,i)

end
end

table.sort( newData, zsort )

success1 = jupiter.save(newData)


end 

SCORE_SAVE_BOOL = false


--love.system.openURL("http://love2d.org/")


end--score_save_bool





    local touches = love.touch.getTouches()
 
    for i, id in ipairs(touches) do
        local x, y = love.touch.getPosition(id)






if x > 135/2 * scale_x and x < 395/2 * scale_x and y > 0 * scale_y and y < 135/2 * scale_y  then

if menu_pad ~= menu_pad_bazgasht and menu_pad ~= change_clothes then

play_music = 1

jupiter = require "jupiter"
newData = jupiter.load("music.txt")
newData[1] = 1
s = jupiter.save(newData)

set_volume()	

end	

end

if x > 405/2 * scale_x and x < 665/2 * scale_x and y > 0 * scale_y and y < 135/2 * scale_y  then

if menu_pad ~= menu_pad_bazgasht and menu_pad ~= change_clothes then

play_music = 0

jupiter = require "jupiter"
newData = jupiter.load("music.txt")
newData[1] = 0
s = jupiter.save(newData)

end

end 



end


love.graphics.draw(menu,0,0 , 0 , scale_x , scale_y)
love.graphics.draw(menu_pad , 0 , 0 , 0 , scale_x, scale_y)




--for showing clothes
if is_base_menu() and menu_pad == change_clothes then

local show_cloth = { x = 185 , y = 140}

love.graphics.draw(player.img , show_cloth.x * scale_x , show_cloth.y * scale_y , 0 , scale_x , scale_y)

clothes_all.draw_belt_in_room(show_cloth,nooooeeee_2)
clothes_all.draw_hat_in_room(show_cloth,nooooeeee) 


if time_to_wait_helper > 0  then
if time_to_wait_helper_bool == true then
time_to_wait_helper = time_to_wait_helper - 1
end
else
time_to_wait_helper_bool = false
time_to_wait_helper = 3
end	

end
--end






--for change_clothes:
--love.graphics.rectangle("fill",292.2*scale_x,125.8*scale_y,80*scale_x,55*scale_y)
--for change_clothes:previous
--love.graphics.rectangle("fill",15*scale_x,120*scale_y,55*scale_x,80*scale_y)
--for change_clothes:next
--love.graphics.rectangle("fill",330*scale_x,120*scale_y,55*scale_x,80*scale_y)
--for change_clothes:save
--love.graphics.rectangle("fill",100*scale_x,205*scale_y,200*scale_x,70*scale_y)
--love.graphics.rectangle("fill", 0 , 0 , 135*scale_x , 530 * scale_y)
--love.graphics.rectangle("fill", 665*scale_x , 0 , 800*scale_x , 260 * scale_y)
--love.graphics.rectangle("fill", 665*scale_x , 270*scale_y , 800*scale_x , 530 * scale_y)


if menu == SCORE_IMAGE then
--show 10 scores


jupiter = require "jupiter"
newData = jupiter.load("save.txt")

for i = 1 , #newData do

local SCORE1 = {}
SCORE1[1] = SCORE:new()
SCORE1[2] = SCORE:new()
SCORE1[3] = SCORE:new()
SCORE1[4] = SCORE:new()
SCORE1[1].x = 320/2 * scale_x   SCORE1[1].y = (i - 1) * scale_y * 50/2 + 100/2 * scale_y SCORE1[1].img = NUMBER0   SCORE1[1].toshow = 0
SCORE1[2].x = 360/2 * scale_x   SCORE1[2].y = (i - 1) * scale_y * 50/2 + 100/2 * scale_y SCORE1[2].img = NUMBER0   SCORE1[2].toshow = 0
SCORE1[3].x = 400/2 * scale_x   SCORE1[3].y = (i - 1) * scale_y * 50/2 + 100/2 * scale_y SCORE1[3].img = NUMBER0   SCORE1[3].toshow = 0
SCORE1[4].x = 440/2 * scale_x   SCORE1[4].y = (i - 1) * scale_y * 50/2 + 100/2 * scale_y SCORE1[4].img = NUMBER0   SCORE1[4].toshow = 0

if newData[i] < 9999 then

SCORE1[4].toshow = newData[i] % 10

SCORE1[3].toshow = ((newData[i] % 100) - SCORE1[4].toshow )/10

SCORE1[2].toshow = ((newData[i] % 1000) - SCORE1[3].toshow - SCORE1[4].toshow)/100 

SCORE1[1].toshow = ((newData[i] % 10000) - SCORE1[2].toshow - SCORE1[3].toshow - SCORE1[4].toshow)/1000 

end--<9999

SCORE1[1]:SCORE_UPDATE_IMAGE()
SCORE1[2]:SCORE_UPDATE_IMAGE()
SCORE1[3]:SCORE_UPDATE_IMAGE()
SCORE1[4]:SCORE_UPDATE_IMAGE()

love.graphics.draw(SCORE1[1].img , SCORE1[1].x , SCORE1[1].y , 0 , scale_x , scale_y)
love.graphics.draw(SCORE1[2].img , SCORE1[2].x , SCORE1[2].y , 0 , scale_x , scale_y)
love.graphics.draw(SCORE1[3].img , SCORE1[3].x , SCORE1[3].y , 0 , scale_x , scale_y)
love.graphics.draw(SCORE1[4].img , SCORE1[4].x , SCORE1[4].y , 0 , scale_x , scale_y)


end--for

 
end--menu == SCORE_IMAGE






end



if GAME_PlAY == true then


if gamepaused == false then


--Code for touches :: starts here

    local touches = love.touch.getTouches()
 
    for i, id in ipairs(touches) do
        local x, y = love.touch.getPosition(id)



   -- for up
    if x > touchX_up and x < touchX_up + 53/2 * scale_x * 2 and y > touchY_up and y < touchY_up + 57/2 * scale_y * 1.3 then

if player.y == GROUND and jumped == false and ducking == false and jumping == false then --and not (x > touchX_down and x < touchX_down + 53 * scale_x and y > touchY_down and y < touchY_down + 57 * scale_y) then

jumping = true
ducking = false
jumped = true  

    
end
    
   end





   -- for down
    if x > touchX_down and x < touchX_down + 53/2 * scale_x * 2 and y > touchY_down and y < touchY_down + 57/2 * scale_y * 1.3 then

    
if jumping == false and jumped == false then --and not(x > touchX_up and x < touchX_up + 53 * scale_x and y > touchY_up and y < touchY_up + 57 * scale_y) then

 if player.health >= 3 then
 player.img = playerDockedImg
end
 if player.health == 2 then
 player.img = playerDockedImgWithTwobattry
end
 if player.health == 1 then
 player.img = playerDockedImgWithOnebattry
end
 movingRight = false
 movingLeft = false
 ducking = true
 jumping = false


canshoot = false



end


    end


--for not down
if x < touchX_down and x > touchX_down + 53/2 * scale_x * 2 and y < touchY_down and y > touchY_down + 57/2 * scale_y * 1.3 then
	player.img = playerImg
    ducking = false
end


   -- for right
    if x > touchX_right and x < touchX_right + 53/2 * scale_x * 1.5 and y > touchY_right and y < touchY_right + 57/2 * scale_y * 1.5 then
    




--player moving right and background not :: starts here
if player.x + speed* scale_x  < 215/2 * scale_x then --and not( x > touchX_left and x < touchX_left + 53 * scale_x and y > touchY_left and y < touchY_left + 57 * scale_y or x > touchX_down and x < touchX_down + 53 * scale_x and y > touchY_down and y < touchY_down + 57 * scale_y ) then

player.x = player.x + speed * scale_x
movingRight = true
movingLeft = false
ducking = false


--Animation for playerMovingRight :: starts here



if player.health >= 3 then
if playerMovingRight_frameSpeed >= 5 * 0.018 then
playerMovingRight_frameSpeed = 0
if playerMovingRight_frame < 12 then
	playerMovingRight_frame = playerMovingRight_frame + 1
else
	playerMovingRight_frame = 1
end
else
	playerMovingRight_frameSpeed = playerMovingRight_frameSpeed + 0.028
end
player.img = playerMovingRight[playerMovingRight_frame]
end



if player.health == 2 then
if playerMovingRightWithTwobattry_frameSpeed >= 5 * 0.018 then
playerMovingRightWithTwobattry_frameSpeed = 0
if playerMovingRightWithTwobattry_frame < 12 then
	playerMovingRightWithTwobattry_frame = playerMovingRightWithTwobattry_frame + 1
else
	playerMovingRightWithTwobattry_frame = 1
end
else
	playerMovingRightWithTwobattry_frameSpeed = playerMovingRightWithTwobattry_frameSpeed + 0.028
end
player.img = playerMovingRightWithTwobattry[playerMovingRightWithTwobattry_frame]
end



if player.health == 1 then
 if playerMovingRightWithOnebattry_frameSpeed >= 5 * 0.018 then
 playerMovingRightWithOnebattry_frameSpeed = 0
if playerMovingRightWithOnebattry_frame < 12 then
	playerMovingRightWithOnebattry_frame = playerMovingRightWithOnebattry_frame + 1
else
	playerMovingRightWithOnebattry_frame = 1
end
else
	playerMovingRightWithOnebattry_frameSpeed = playerMovingRightWithOnebattry_frameSpeed + 0.028
end
player.img = playerMovingRightWithOnebattry[playerMovingRightWithOnebattry_frame]
end



--Animation for playerMovingRight :: ends here
end
--player moving right and background not :: ends here





--player and background moving right :: starts here

if player.x + speed * scale_x >= 215/2 * scale_x then --and not( x > touchX_left and x < touchX_left + 53 * scale_x and y > touchY_left and y < touchY_left + 57 * scale_y or x > touchX_down and x < touchX_down + 53 * scale_x and y >= touchY_down and y <= touchY_down + 57 * scale_y ) then



player.x = player.x

movingRight = true
movingLeft = false
ducking = false


--Animation for playerMovingRight :: starts here



if player.health >= 3  then
if playerMovingRight_frameSpeed >= 5 * 0.018 then
playerMovingRight_frameSpeed = 0
if playerMovingRight_frame < 12 then
	playerMovingRight_frame = playerMovingRight_frame + 1
else
	playerMovingRight_frame = 1
end
else
	playerMovingRight_frameSpeed = playerMovingRight_frameSpeed + 0.028
end
player.img = playerMovingRight[playerMovingRight_frame]
end



if player.health == 2 then
if playerMovingRightWithTwobattry_frameSpeed >= 5 * 0.018 then
playerMovingRightWithTwobattry_frameSpeed = 0
if playerMovingRightWithTwobattry_frame < 12 then
	playerMovingRightWithTwobattry_frame = playerMovingRightWithTwobattry_frame + 1
else
	playerMovingRightWithTwobattry_frame = 1
end
else
	playerMovingRightWithTwobattry_frameSpeed = playerMovingRightWithTwobattry_frameSpeed + 0.028
end
player.img = playerMovingRightWithTwobattry[playerMovingRightWithTwobattry_frame]
end



if player.health == 1 then
if playerMovingRightWithOnebattry_frameSpeed >= 5 * 0.018 then
playerMovingRightWithOnebattry_frameSpeed = 0
if playerMovingRightWithOnebattry_frame < 12 then
	playerMovingRightWithOnebattry_frame = playerMovingRightWithOnebattry_frame + 1
else
	playerMovingRightWithOnebattry_frame = 1
end
else
	playerMovingRightWithOnebattry_frameSpeed = playerMovingRightWithOnebattry_frameSpeed + 0.028
end
player.img = playerMovingRightWithOnebattry[playerMovingRightWithOnebattry_frame]
end



--Animation for playerMovingRight :: ends here



--Code for moving Background :: starts here

if not ( enemys[1].isAlive == true or enemys[2].isAlive == true ) and passing == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false and amuzeshi_gameplay == false then
background1.x = background1.x - speed * scale_x
background2.x = background2.x - speed * scale_x
headofmamouthX = headofmamouthX - speed * scale_x
Crow1.x = Crow1.x - speed * scale_x
BLOCKJUMPS[blockforfightingboss1].x = BLOCKJUMPS[blockforfightingboss1].x - speed * scale_x
BLOCKJUMPS[blockforfightingboss2].x = BLOCKJUMPS[blockforfightingboss2].x - speed * scale_x
flyingbird.x = flyingbird.x - speed * scale_x

for i = 1 , #enemys do

if enemys[i].X_TIME == true then
enemys[i].X_TIMEFORDIE = enemys[i].X_TIMEFORDIE - speed * scale_x

end

end

for i = 1 , #enemys do

if #enemys[1].EBullets > 0 and enemys[1].EBullets ~= nil then

for i = 1 , #enemys[1].EBullets do
if enemys[1].EBullets[i] ~= nil then

enemys[1].EBullets[i].x = enemys[1].EBullets[i].x - 2/2  * scale_x

end
end
end



if #enemys[2].EBullets > 0 and enemys[2].EBullets ~= nil then

for i = 1 , #enemys[2].EBullets do
if enemys[2].EBullets[i] ~= nil then

enemys[2].EBullets[i].x = enemys[2].EBullets[i].x - 2/2  * scale_x

end
end
end


end


if should_summon_boss1 == true then

BOSS_WALK() -- down -- 

end


if should_summon_boss2 == true then

BOSS2_WALK() -- down -- 

end


if should_summon_boss3 == true then

BOSS3_WALK() -- down -- 

end


if passing == false and boss.isAlive == true then

if boss.helper.X_TIME == true then
boss.helper.X_TIMEFORDIE = boss.helper.X_TIMEFORDIE - speed * scale_x
end
end

if boss.isAlive == false then
for i = 1 , #boss.BBullets do
if boss.BBullets[i] ~= nil then

boss.BBullets[i].x = boss.BBullets[i].x - speed * scale_x 

end
end
end



GRASSES.x = GRASSES.x - speed * scale_x




GRASSES1.x = GRASSES1.x - speed * scale_x



for i = 1 , 4 do
GROUND_TO_SHOW[i] = GROUND_TO_SHOW[i] - speed * scale_x
end

for i = 1 , 4 do
GROUND1_TO_SHOW[i] = GROUND1_TO_SHOW[i] - speed * scale_x
end

RAIN.x = RAIN.x - speed * scale_x
RAIN1.x = RAIN1.x - speed * scale_x
RAIN_RED.x = RAIN_RED.x - speed * scale_x


for i = 1 , #WATER_DROP_LB do

WATER_DROP_LB[i].x  = WATER_DROP_LB[i].x - speed * scale_x

end

for i = 1 , #WATER_DROP_RB do

WATER_DROP_RB[i].x  = WATER_DROP_RB[i].x - speed * scale_x

end

for i = 1 , #WATER_DROP_LB_RED do

WATER_DROP_LB_RED[i].x  = WATER_DROP_LB_RED[i].x - speed * scale_x

end


LIGHTNING_R_1.x = LIGHTNING_R_1.x - speed * scale_x
LIGHTNING_R_2.x = LIGHTNING_R_2.x - speed * scale_x

LIGHTNING_L_1.x = LIGHTNING_L_1.x - speed * scale_x
LIGHTNING_L_2.x = LIGHTNING_L_2.x - speed * scale_x

WIND.x = WIND.x - speed * scale_x
WIND1.x = WIND1.x - speed * scale_x

SUN.x = SUN.x - speed * scale_x
SUN1.x = SUN1.x - speed * scale_x

FLOWERS1_1.x = FLOWERS1_1.x - speed * scale_x
FLOWERS1_2.x = FLOWERS1_2.x - speed * scale_x

FLOWERS2_1.x = FLOWERS2_1.x - speed * scale_x
FLOWERS2_2.x = FLOWERS2_2.x - speed * scale_x

FLOWERS3_1.x = FLOWERS3_1.x - speed * scale_x
FLOWERS3_2.x = FLOWERS3_2.x - speed * scale_x

FLOWERS4_1.x = FLOWERS4_1.x - speed * scale_x
FLOWERS4_2.x = FLOWERS4_2.x - speed * scale_x

BOSS_WALKING_X = BOSS_WALKING_X - speed * scale_x
BOSS2_WALKING_X = BOSS2_WALKING_X - speed * scale_x
BOSS3_WALKING_X = BOSS3_WALKING_X - speed * scale_x

CONG1.x = CONG1.x - speed * scale_x
CONG2.x = CONG2.x - speed * scale_x
CONG3.x = CONG3.x - speed * scale_x
CONG4.x = CONG4.x - speed * scale_x

CONG1_1.x = CONG1_1.x - speed * scale_x
CONG2_1.x = CONG2_1.x - speed * scale_x
CONG3_1.x = CONG3_1.x - speed * scale_x
CONG4_1.x = CONG4_1.x - speed * scale_x

white_flyingbird1.x = white_flyingbird1.x - speed * scale_x
white_flyingbird2.x = white_flyingbird2.x - speed * scale_x
white_flyingbird3.x = white_flyingbird3.x - speed * scale_x
white_flyingbird4.x = white_flyingbird4.x - speed * scale_x

wing1_congs.x = wing1_congs.x - speed * scale_x
wing2_congs.x = wing2_congs.x - speed * scale_x


if BOSS_WALKING_X <= boss.x + 10/2 * scale_x then
BOSS_WALKING_X = BOSS_WALKING_X + 1600/2 * scale_x
end


if BOSS2_WALKING_X <= boss2.x + 210/2 * scale_x then
BOSS2_WALKING_X = BOSS2_WALKING_X + 1600/2 * scale_x
end


if BOSS3_WALKING_X <= boss3.x + 10/2 * scale_x then
BOSS3_WALKING_X = BOSS3_WALKING_X + 1600/2 * scale_x
end



if background1.x - speed < -800/2 * scale_x then
	
	background1.x = background1.x + 1600/2 * scale_x
	

GRASSES.x = GRASSES.x + 1600/2 * scale_x


for i = 1 , 4 do
GROUND_TO_SHOW[i] = GROUND_TO_SHOW[i] + 1600/2 * scale_x
end

RAIN.x = RAIN.x + 1600/2 * scale_x
RAIN_RED.x = RAIN_RED.x + 1600/2 * scale_x

LIGHTNING_R_1.x = LIGHTNING_R_1.x + 1600/2 * scale_x
LIGHTNING_L_1.x = LIGHTNING_L_1.x + 1600/2 * scale_x

for i = 1 , #WATER_DROP_LB do

WATER_DROP_LB[i].x  = WATER_DROP_LB[i].x + 1600/2 * scale_x

end

for i = 1 , #WATER_DROP_LB_RED do

WATER_DROP_LB_RED[i].x  = WATER_DROP_LB_RED[i].x + 1600/2 * scale_x

end

WIND.x = WIND.x + 1600/2 * scale_x
SUN.x = SUN.x + 1600/2 * scale_x

FLOWERS1_1.x = FLOWERS1_1.x + 1600/2 * scale_x
FLOWERS2_1.x = FLOWERS2_1.x + 1600/2 * scale_x
FLOWERS3_1.x = FLOWERS3_1.x + 1600/2 * scale_x
FLOWERS4_1.x = FLOWERS4_1.x + 1600/2 * scale_x

CONG1.x = CONG1.x + 1600/2 * scale_x
CONG2.x = CONG2.x + 1600/2 * scale_x
CONG3.x = CONG3.x + 1600/2 * scale_x
CONG4.x = CONG4.x + 1600/2 * scale_x

white_flyingbird1.x = white_flyingbird1.x + 1600/2 * scale_x
white_flyingbird2.x = white_flyingbird2.x + 1600/2 * scale_x

wing1_congs.x = wing1_congs.x + 1600/2 * scale_x
    
    headofmamouthX = headofmamouthX + 800/2 * scale_x
    Crow1.x = Crow1.x + 1600/2 * scale_x
    pass1 = pass1 + 1
elseif background2.x - speed < -800/2 * scale_x then

GRASSES1.x = GRASSES1.x + 1600/2 * scale_x


for i = 1 , 4 do
GROUND1_TO_SHOW[i] = GROUND1_TO_SHOW[i] + 1600/2 * scale_x
end


RAIN1.x = RAIN1.x + 1600/2 * scale_x


LIGHTNING_R_2.x = LIGHTNING_R_2.x + 1600/2 * scale_x
LIGHTNING_L_2.x = LIGHTNING_L_2.x + 1600/2 * scale_x

for i = 1 , #WATER_DROP_RB do

WATER_DROP_RB[i].x  = WATER_DROP_RB[i].x + 1600/2 * scale_x

end

WIND1.x = WIND1.x + 1600/2 * scale_x
SUN1.x = SUN1.x + 1600/2 * scale_x

FLOWERS1_2.x = FLOWERS1_2.x + 1600/2 * scale_x
FLOWERS2_2.x = FLOWERS2_2.x + 1600/2 * scale_x
FLOWERS3_2.x = FLOWERS3_2.x + 1600/2 * scale_x
FLOWERS4_2.x = FLOWERS4_2.x + 1600/2 * scale_x

CONG1_1.x = CONG1_1.x + 1600/2 * scale_x
CONG2_1.x = CONG2_1.x + 1600/2 * scale_x
CONG3_1.x = CONG3_1.x + 1600/2 * scale_x
CONG4_1.x = CONG4_1.x + 1600/2 * scale_x

white_flyingbird3.x = white_flyingbird3.x + 1600/2 * scale_x
white_flyingbird4.x = white_flyingbird4.x + 1600/2 * scale_x

wing2_congs.x = wing2_congs.x + 1600/2 * scale_x

	background2.x = background2.x + 1600/2 * scale_x
    headofmamouthX = headofmamouthX + 800/2 * scale_x
    flyingbird.x = flyingbird.x + 1600/2 * scale_x
    BLOCKJUMPS[blockforfightingboss1].x = BLOCKJUMPS[blockforfightingboss1].x + 1600/2 * scale_x
    BLOCKJUMPS[blockforfightingboss2].x = BLOCKJUMPS[blockforfightingboss2].x + 1600/2 * scale_x
    pass = pass + 1
end
end


--Code for moving Background :: ends here
end
--player and background moving right :: ends here




    end




   -- for left
    if x > touchX_left and x < touchX_left + 53/2 * scale_x * 1.5 and y > touchY_left and y < touchY_left + 57/2 * scale_y * 1.5 then
   
--if not ( x > touchX_right and x < touchX_right + 53 * scale_x and y > touchY_right and y < touchY_right + 57 * scale_y or x > touchX_down and x < touchX_down + 53 * scale_x and y > touchY_down and y < touchY_down + 57 * scale_y ) then

player.x = player.x - speed * scale_x
movingRight = false 
movingLeft = true
ducking = false



canshoot = false




--Animation for playerMovingLeft :: starts here


if player.health >= 3 then
if playerMovingLeft_frameSpeed >= 5 * 0.018 then
playerMovingLeft_frameSpeed = 0
if playerMovingLeft_frame < 12 then
	playerMovingLeft_frame = playerMovingLeft_frame + 1
else
	playerMovingLeft_frame = 1
end
else
	playerMovingLeft_frameSpeed = playerMovingLeft_frameSpeed + 0.028
end
player.img = playerMovingLeft[playerMovingLeft_frame]
end

if player.health == 2 then
if playerMovingLeftWithTwobattry_frameSpeed >= 5 * 0.018 then
playerMovingLeftWithTwobattry_frameSpeed = 0
if playerMovingLeftWithTwobattry_frame < 12 then
	playerMovingLeftWithTwobattry_frame = playerMovingLeftWithTwobattry_frame + 1
else
	playerMovingLeftWithTwobattry_frame = 1
end
else
	playerMovingLeftWithTwobattry_frameSpeed = playerMovingLeftWithTwobattry_frameSpeed + 0.028
end
player.img = playerMovingLeftWithTwobattry[playerMovingLeftWithTwobattry_frame]
end

if player.health == 1 then
if playerMovingLeftWithOnebattry_frameSpeed >= 5 * 0.018 then
playerMovingLeftWithOnebattry_frameSpeed = 0
if playerMovingLeftWithOnebattry_frame < 12 then
	playerMovingLeftWithOnebattry_frame = playerMovingLeftWithOnebattry_frame + 1
else
	playerMovingLeftWithOnebattry_frame = 1
end
else
	playerMovingLeftWithOnebattry_frameSpeed = playerMovingLeftWithOnebattry_frameSpeed + 0.028
end
player.img = playerMovingLeftWithOnebattry[playerMovingLeftWithOnebattry_frame]
end


--Animation for playerMovingLeft :: ends here

--end

    end



--shooting
if x > touchX_shoot and x < touchX_shoot + 400/2 * scale_x and y > touchY_shoot and y < touchY_shoot + 530/2 * scale_y then
    
if canshoot == true and AMMO > 0 then --and not (x > touchX_left and x < touchX_left + 53 * scale_x and y > touchY_left and y < touchY_left + 57 * scale_y or x > touchX_down and x < touchX_down + 53 * scale_x and y > touchY_down and y < touchY_down + 57 * scale_y) then

shotFire = true
ducking = false
movingLeft = false
movingRight = true


--here should change to fix the problem!







-- end!




--light gun
if should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false and 
PASSING_FINISHeD_GAME == 0 and
(enemys[1].isAlive == true or
enemys[2].isAlive == true )
or amuzeshi_gameplay == true then

newbullet = {x = player.x + 125/2 * scale_x  , y = player.y + 16/2 * scale_y , visible = true , img = bulletImg}   
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end

--hand gun
if not((should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false) and 
enemys[1].isAlive == true or
enemys[2].isAlive == true ) and handle_SHOT_GUN == false and handle_HEAVY_GUN == false and handle_LAZER_GUN == false and not (handle_HEAVY_GUN == true) and amuzeshi_gameplay == false then
newbullet = {x = player.x + 135/2 * scale_x  , y = player.y + 16/2 * scale_y , visible = true , img = bulletImg}   
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end	

--shot gun
if handle_SHOT_GUN == true and AMMO >=2 and amuzeshi_gameplay == false then
newbullet = {x = player.x + 90/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_SHOT_GUN}
newbullet1 = {x = player.x + 150/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_SHOT_GUN}
table.insert(bullets,newbullet)
table.insert(bullets,newbullet1)
--Code for AMMO

AMMO = AMMO - 2

--Code for AMMO
shootTime = 0
end

--heavy gun
if handle_HEAVY_GUN == true and amuzeshi_gameplay == false then
newbullet = {x = player.x + 103/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_HEAVY_GUN}	
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end

--lazer gun
if handle_LAZER_GUN == true and AMMO >=5 and amuzeshi_gameplay == false then
newbullet = {x = player.x + 108/2 * scale_x  , y = player.y + 34/2 * scale_y , visible = true , img = bullet_LAZER_GUN}	
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 5

--Code for AMMO
shootTime = 0


end



if #love.touch.getTouches() == 1 then

movingRight = true
movingLeft = false
ducking = false

if player.health >= 3 then
if playerStanding_frameSpeed >= 25 * 0.018 then
playerStanding_frameSpeed = 0
if playerStanding_frame < 5 then
	playerStanding_frame = playerStanding_frame + 1
else
	playerStanding_frame = 1
end
else
	playerStanding_frameSpeed = playerStanding_frameSpeed + 0.028
end
player.img = playerStanding[playerStanding_frame]
end

if player.health == 2 then
if playerStandingWithTwobattry_frameSpeed >= 25 * 0.018 then
playerStandingWithTwobattry_frameSpeed = 0
if playerStandingWithTwobattry_frame < 5 then
	playerStandingWithTwobattry_frame = playerStandingWithTwobattry_frame + 1
else
	playerStandingWithTwobattry_frame = 1
end
else
	playerStandingWithTwobattry_frameSpeed = playerStandingWithTwobattry_frameSpeed + 0.028
end
player.img = playerStandingWithTwobattry[playerStandingWithTwobattry_frame]
end

if player.health == 1 then
if playerStandingWithOnebattry_frameSpeed >= 25 * 0.018 then
playerStandingWithOnebattry_frameSpeed = 0
if playerStandingWithOnebattry_frame < 5 then
	playerStandingWithOnebattry_frame = playerStandingWithOnebattry_frame + 1
else
	playerStandingWithOnebattry_frame = 1
end
else
	playerStandingWithOnebattry_frameSpeed = playerStandingWithOnebattry_frameSpeed + 0.028
end
player.img = playerStandingWithOnebattry[playerStandingWithOnebattry_frame]
end



end

if #love.touch.getTouches() == 1 then

movingRight = true
movingLeft = false
ducking = false

if player.health >= 3 then
if playerStanding_frameSpeed >= 25 * 0.018 then
playerStanding_frameSpeed = 0
if playerStanding_frame < 5 then
	playerStanding_frame = playerStanding_frame + 1
else
	playerStanding_frame = 1
end
else
	playerStanding_frameSpeed = playerStanding_frameSpeed + 0.028
end
player.img = playerStanding[playerStanding_frame]
end

if player.health == 2 then
if playerStandingWithTwobattry_frameSpeed >= 25 * 0.018 then
playerStandingWithTwobattry_frameSpeed = 0
if playerStandingWithTwobattry_frame < 5 then
	playerStandingWithTwobattry_frame = playerStandingWithTwobattry_frame + 1
else
	playerStandingWithTwobattry_frame = 1
end
else
	playerStandingWithTwobattry_frameSpeed = playerStandingWithTwobattry_frameSpeed + 0.028
end
player.img = playerStandingWithTwobattry[playerStandingWithTwobattry_frame]
end

if player.health == 1 then
if playerStandingWithOnebattry_frameSpeed >= 25 * 0.018 then
playerStandingWithOnebattry_frameSpeed = 0
if playerStandingWithOnebattry_frame < 5 then
	playerStandingWithOnebattry_frame = playerStandingWithOnebattry_frame + 1
else
	playerStandingWithOnebattry_frame = 1
end
else
	playerStandingWithOnebattry_frameSpeed = playerStandingWithOnebattry_frameSpeed + 0.028
end
player.img = playerStandingWithOnebattry[playerStandingWithOnebattry_frame]
end



end






end
end


if not(x > touchX_shoot and x < touchX_shoot + 400 * scale_x and y > touchY_shoot and y < touchY_shoot + 530 * scale_y or x > touchX_up and x < touchX_up + 53 * scale_x and y > touchY_up and y < touchY_up + 57 * scale_y or x > touchX_right and x < touchX_right + 53 * scale_x and y > touchY_right and y < touchY_right + 57 * scale_y or x > touchX_left and x < touchX_left + 53 * scale_x and y > touchY_left and y < touchY_left + 57 * scale_y or x > touchX_down and x < touchX_down + 53 * scale_x and y > touchY_down and y < touchY_down + 57 * scale_y) then

movingRight = true
movingLeft = false
ducking = false

if player.health >= 3 then
if playerStanding_frameSpeed >= 25 * 0.018 then
playerStanding_frameSpeed = 0
if playerStanding_frame < 5 then
	playerStanding_frame = playerStanding_frame + 1
else
	playerStanding_frame = 1
end
else
	playerStanding_frameSpeed = playerStanding_frameSpeed + 0.028
end
player.img = playerStanding[playerStanding_frame]
end

if player.health == 2 then
if playerStandingWithTwobattry_frameSpeed >= 25 * 0.018 then
playerStandingWithTwobattry_frameSpeed = 0
if playerStandingWithTwobattry_frame < 5 then
	playerStandingWithTwobattry_frame = playerStandingWithTwobattry_frame + 1
else
	playerStandingWithTwobattry_frame = 1
end
else
	playerStandingWithTwobattry_frameSpeed = playerStandingWithTwobattry_frameSpeed + 0.028
end
player.img = playerStandingWithTwobattry[playerStandingWithTwobattry_frame]
end

if player.health == 1 then
if playerStandingWithOnebattry_frameSpeed >= 25 * 0.018 then
playerStandingWithOnebattry_frameSpeed = 0
if playerStandingWithOnebattry_frame < 5 then
	playerStandingWithOnebattry_frame = playerStandingWithOnebattry_frame + 1
else
	playerStandingWithOnebattry_frame = 1
end
else
	playerStandingWithOnebattry_frameSpeed = playerStandingWithOnebattry_frameSpeed + 0.028
end
player.img = playerStandingWithOnebattry[playerStandingWithOnebattry_frame]
end



end	

--standing (should add not touch the screen next :: after the for for the touches).
if x < touchX_up and x > touchX_up + 53/2 * scale_x * 2 and y < touchY_up and y > touchY_up + 57/2 * scale_y * 1.3 -- up
and x > touchX_down and x > touchX_down + 53/2 * scale_x * 2 and y < touchY_down and y > touchY_down + 57/2 * scale_y * 1.3 -- down
and x > touchX_right and x > touchX_right + 53/2 * scale_x * 1.5 and y < touchY_right and y > touchY_right + 57/2 * scale_y * 1.5 -- right
and x > touchX_left and x > touchX_left + 53/2 * scale_x * 1.5 and y < touchY_left and y > touchY_left + 57/2 * scale_y * 1.5 -- left
and x > touchX_shoot and x > touchX_shoot + 400/2 * scale_x and y < touchY_shoot and y > touchY_shoot + 530/2 * scale_y -- shoot
or x == touchX_up and x == touchX_up + 53/2 * scale_x * 2 and y == touchY_up and y == touchY_up + 57/2 * scale_y * 1.3 -- up
or x == touchX_down and x == touchX_down + 53/2 * scale_x * 2 and y == touchY_down and y == touchY_down + 57/2 * scale_y * 1.3 -- down
or x == touchX_right and x == touchX_right + 53/2 * scale_x * 1.5 and y == touchY_right and y == touchY_right + 57/2 * scale_y * 1.5 -- right
or x == touchX_left and x == touchX_left + 53/2 * scale_x * 1.5 and y == touchY_left and y == touchY_left + 57/2 * scale_y * 1.5 -- left
or x == touchX_shoot and x == touchX_shoot + 400/2 * scale_x and y == touchY_shoot and y == touchY_shoot + 530/2 * scale_y -- shoot
then --not(x > touchX_shoot and x < touchX_shoot + 400 * scale_x and y > touchY_shoot and y < touchY_shoot + 530 * scale_y or x > touchX_up and x < touchX_up + 53 * scale_x and y > touchY_up and y < touchY_up + 57 * scale_y or x > touchX_right and x < touchX_right + 53 * scale_x and y > touchY_right and y < touchY_right + 57 * scale_y or x > touchX_left and x < touchX_left + 53 * scale_x and y > touchY_left and y < touchY_left + 57 * scale_y or x > touchX_down and x < touchX_down + 53 * scale_x and y > touchY_down and y < touchY_down + 57 * scale_y) then

movingRight = true
movingLeft = false
ducking = false

if player.health >= 3 then
if playerStanding_frameSpeed >= 25 * 0.018 then
playerStanding_frameSpeed = 0
if playerStanding_frame < 5 then
	playerStanding_frame = playerStanding_frame + 1
else
	playerStanding_frame = 1
end
else
	playerStanding_frameSpeed = playerStanding_frameSpeed + 0.028
end
player.img = playerStanding[playerStanding_frame]
end

if player.health == 2 then
if playerStandingWithTwobattry_frameSpeed >= 25 * 0.018 then
playerStandingWithTwobattry_frameSpeed = 0
if playerStandingWithTwobattry_frame < 5 then
	playerStandingWithTwobattry_frame = playerStandingWithTwobattry_frame + 1
else
	playerStandingWithTwobattry_frame = 1
end
else
	playerStandingWithTwobattry_frameSpeed = playerStandingWithTwobattry_frameSpeed + 0.028
end
player.img = playerStandingWithTwobattry[playerStandingWithTwobattry_frame]
end

if player.health == 1 then
if playerStandingWithOnebattry_frameSpeed >= 25 * 0.018 then
playerStandingWithOnebattry_frameSpeed = 0
if playerStandingWithOnebattry_frame < 5 then
	playerStandingWithOnebattry_frame = playerStandingWithOnebattry_frame + 1
else
	playerStandingWithOnebattry_frame = 1
end
else
	playerStandingWithOnebattry_frameSpeed = playerStandingWithOnebattry_frameSpeed + 0.028
end
player.img = playerStandingWithOnebattry[playerStandingWithOnebattry_frame]
end



end

end

--Code for touches :: ends here

if #love.touch.getTouches() == 0 then

movingRight = true
movingLeft = false
ducking = false

if player.health >= 3 then
if playerStanding_frameSpeed >= 25 * 0.018 then
playerStanding_frameSpeed = 0
if playerStanding_frame < 5 then
	playerStanding_frame = playerStanding_frame + 1
else
	playerStanding_frame = 1
end
else
	playerStanding_frameSpeed = playerStanding_frameSpeed + 0.028
end
player.img = playerStanding[playerStanding_frame]
end

if player.health == 2 then
if playerStandingWithTwobattry_frameSpeed >= 25 * 0.018 then
playerStandingWithTwobattry_frameSpeed = 0
if playerStandingWithTwobattry_frame < 5 then
	playerStandingWithTwobattry_frame = playerStandingWithTwobattry_frame + 1
else
	playerStandingWithTwobattry_frame = 1
end
else
	playerStandingWithTwobattry_frameSpeed = playerStandingWithTwobattry_frameSpeed + 0.028
end
player.img = playerStandingWithTwobattry[playerStandingWithTwobattry_frame]
end

if player.health == 1 then
if playerStandingWithOnebattry_frameSpeed >= 25 * 0.018 then
playerStandingWithOnebattry_frameSpeed = 0
if playerStandingWithOnebattry_frame < 5 then
	playerStandingWithOnebattry_frame = playerStandingWithOnebattry_frame + 1
else
	playerStandingWithOnebattry_frame = 1
end
else
	playerStandingWithOnebattry_frameSpeed = playerStandingWithOnebattry_frameSpeed + 0.028
end
player.img = playerStandingWithOnebattry[playerStandingWithOnebattry_frame]
end



end








love.graphics.draw(background1.img , background1.x , background1.y , 0 , scale_x , scale_y)

if boss2.img == boss2.BOSSIMAGES.BOSS_WAIT[8] or boss2.img == boss2.BOSSIMAGES.BOSS_WAIT[9] then

if boss2_upTremble == true then
background2.y =  - 2 * scale_y
boss2_upTremble_T = boss2_upTremble_T + 1
if boss2_upTremble_T >= Tremble_Tlimit then
boss2_upTremble_T = 0
boss2_upTremble = false
boss2_midTremble = true
end
end

if boss2_midTremble == true then
background2.y = 0
boss2_midTremble_T = boss2_midTremble_T + 1
if boss2_midTremble_T >= Tremble_Tlimit then
boss2_midTremble_T = 0
boss2_midTremble = false
boss2_downTremble = true
end
end

if boss2_downTremble == true then
background2.y = 2 * scale_y
boss2_downTremble_T = boss2_downTremble_T + 1
if boss2_downTremble_T >= Tremble_Tlimit then
boss2_downTremble_T = 0
boss2_downTremble = false
boss2_mid2Tremble = true
end
end

if boss2_mid2Tremble == true then
background2.y = 0
boss2_mid2Tremble_T = boss2_mid2Tremble_T + 1
if boss2_mid2Tremble_T >= Tremble_Tlimit then
boss2_mid2Tremble_T = 0
boss2_mid2Tremble = false
boss2_upTremble = true
end
end

else

background2.y = 0

end

love.graphics.draw(background2.img , background2.x , background2.y , 0 , scale_x , scale_y)



--CONGRATULATION
if not( should_summon_boss3 == true or (should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == false and boss3_finished == true)) then

DRAW_CONGRATULATION()

end




if should_summon_boss1 == true then
DRAW_RAIN() -- function.lua
DRAW_LIGHTNING() -- function.lua
DRAW_WATER_DROP() -- function.lua
end

if should_summon_boss2 == true then
DRAW_SUN() -- function.lua	
DRAW_WIND() -- function.lua
DRAW_FLOWERS() -- function.lua



if boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[16] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[17] then
love.graphics.draw(JAG , player.x , 430/2 * scale_y , 0 , scale_x , scale_y)
end





if boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[12] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[13] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[14] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[15] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[16] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[17] then
love.graphics.draw(JAG_NOT , player.x , player.y - 100/2 * scale_y , 0 , scale_x , scale_y)
end



end









if should_summon_boss3 == true then

DRAW_RAIN_RED() -- function.lua
DRAW_WATER_DROP_RED() -- function.lua

end




DRAW_GRASS() -- function.lua
GROUND_SHOW() -- function.lua

--DRAWING SCORE && AMMO :: starts here

for i = 1 , #SCORES do
love.graphics.draw(SCORES[i].img , SCORES[i].x , SCORES[i].y , 0 , scale_x , scale_y)
end

for i = 1 , #AMMOTOSHOW do
love.graphics.draw(AMMOTOSHOW[i].img , AMMOTOSHOW[i].x , AMMOTOSHOW[i].y , 0 , scale_x , scale_y)
end

love.graphics.draw(AMMOTIME.img , AMMOTIME.x , AMMOTIME.y , 0 , scale_x , scale_y)
love.graphics.draw(CLOCK , AMMOTIME.x - 48/2 * scale_x , AMMOTIME.y - 3/2 * scale_y , 0 , scale_x , scale_y)

if handle_SHOT_GUN == false then

love.graphics.draw(AMMO_BULLET , AMMOTOSHOW[2].x + 75/2 * scale_x , AMMOTOSHOW[2].y - 17/2 * scale_y , 0 , scale_x , scale_y)

elseif handle_SHOT_GUN == true then

love.graphics.draw(AMMO_BULLET , AMMOTOSHOW[2].x + 75/2 * scale_x , AMMOTOSHOW[2].y - 10/2 * scale_y , 0 , scale_x , scale_y)

end
--DRAWING SCORE && AMMO :: ends here




-- Animation for the HEADOFMAMOUTH :: starts here

if not( headofmamouth == HEADOFMAMOUTH[1] and not ( enemys[1].isAlive == true or enemys[2].isAlive == true ) ) then
love.graphics.draw(headofmamouth , headofmamouthX , headofmamouthY , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill' , BLOCKJUMPS[blockJumpForHelis].x , BLOCKJUMPS[blockJumpForHelis].y , BLOCKJUMPS[blockJumpForHelis].width , BLOCKJUMPS[blockJumpForHelis].height)
end

-- Animation for the HEADOFMAMOUTH :: ends here

--BLOCKJUMPFORFIGHTINGBOSS

if #boss.BBullets > 0 or should_summon_boss1 == true or should_summon_boss3 == true then
love.graphics.draw(BLOCKJUMPFORFIGHTINGBOSS , BLOCKJUMPS[blockforfightingboss1].x , BLOCKJUMPS[blockforfightingboss1].y , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill' , BLOCKJUMPS[blockforfightingboss1].x , BLOCKJUMPS[blockforfightingboss1].y , BLOCKJUMPS[blockforfightingboss1].width , BLOCKJUMPS[blockforfightingboss1].height)
love.graphics.draw(BLOCKJUMPFORFIGHTINGBOSS , BLOCKJUMPS[blockforfightingboss2].x , BLOCKJUMPS[blockforfightingboss2].y , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill' , BLOCKJUMPS[blockforfightingboss2].x , BLOCKJUMPS[blockforfightingboss2].y , BLOCKJUMPS[blockforfightingboss2].width , BLOCKJUMPS[blockforfightingboss2].height)
else
BLOCKJUMPS[blockforfightingboss1].onBlock = false 
BLOCKJUMPS[blockforfightingboss2].onBlock = false
end

--BLOCKJUMPFORFIGHTINGBOSS





--love.graphics.setColor(1,.3,.3)
if enemys[1].isAlive == true or enemys[2].isAlive == true or boss.isAlive == true then
love.graphics.draw(deadline,300/2 * scale_x ,0 , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill',BLOCKJUMPS[blockJumpForHelis].x,BLOCKJUMPS[blockJumpForHelis].y,BLOCKJUMPS[blockJumpForHelis].width,BLOCKJUMPS[blockJumpForHelis].height)
end

if amuzeshi_gameplay == true then

love.graphics.draw(deadline,300/2 * scale_x ,0 , 0 , scale_x , scale_y)

end




--Animation for crows and flyingbird :: starts here 
if not( CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false) then
love.graphics.draw(Crow1.img , Crow1.x , Crow1.y , 0 , scale_x , scale_y)
love.graphics.draw(flyingbird.img , flyingbird.x , flyingbird.y , 0 , scale_x , scale_y)
end

--Animation for crows and flyingbird :: ends here




love.graphics.draw(player.img , player.x , player.y , 0 , scale_x , scale_y)







for i = 1 , #enemys do

if enemys[i].attackSpeed <= 0.5 and #enemys[i].EBullets >=1  then 

if enemys[i].changeforpicture == 1 then
enemys[i].img = CROWENEMY_SHOOT 
end

if enemys[i].changeforpicture == 2 then
enemys[i].img = CROWENEMYNUMBER2_SHOOT 
end

if enemys[i].changeforpicture == 3 then
enemys[i].img = CROWENEMYNUMBER3_SHOOT 
end

end

if enemys[i].isAlive == false  then
if enemys[i].y < 1000/2 * scale_y then
enemys[i].X_TIME = true	
enemys[i].TIMEFORDIE = enemys[i].TIMEFORDIE + 0.1
if enemys[i].TIMEFORDIE > 4 then
    enemys[i].TIMEFORDIE = 0
    enemys[i].y = 1820/2 * scale_y
    enemys[i].X_TIME = false
end
end

if enemys[i].changeforpicture == 1 then
love.graphics.draw(CROWENEMY_DIE , enemys[i].X_TIMEFORDIE , enemys[i].y , 0 , scale_x , scale_y)
end

if enemys[i].changeforpicture == 2 then
love.graphics.draw(CROWENEMYNUMBER2_DIE , enemys[i].X_TIMEFORDIE , enemys[i].y , 0 , scale_x , scale_y)
end

if enemys[i].changeforpicture == 3 then
love.graphics.draw(CROWENEMYNUMBER3_DIE , enemys[i].X_TIMEFORDIE , enemys[i].y , 0 , scale_x , scale_y)
end


else
love.graphics.draw(enemys[i].img , enemys[i].x , enemys[i].y , 0 , scale_x , scale_y)    
enemys[i]:draw_hit_effect()
end

end


--showing health bar for enemys :: starts here

for i = 1 , #enemys do

DRAW_HEALTH_BAR_ENEMY(enemys[i].changeforpicture , enemys[i].health ,  enemys[i].isAlive  , enemys[i].x , enemys[i].y) -- function.lua

end









if boss.helper.attackSpeed <= 0.5 and #boss.helper.EBullets >=1  then 

if boss.helper.changeforpicture == 1 then
boss.helper.img = CROWENEMY_SHOOT 
end

if boss.helper.changeforpicture == 2 then
boss.helper.img = CROWENEMYNUMBER2_SHOOT 
end

if boss.helper.changeforpicture == 3 then
boss.helper.img = CROWENEMYNUMBER3_SHOOT 
end

end

if boss.helper.isAlive == false and boss.isAlive == true then
if boss.helper.y < 1000/2 * scale_y then
boss.helper.X_TIME = true	
boss.helper.TIMEFORDIE = boss.helper.TIMEFORDIE + 0.1
if boss.helper.TIMEFORDIE > 4 then
    boss.helper.TIMEFORDIE = 0
    boss.helper.y = 1820/2 * scale_y
    boss.helper.X_TIME = false
end
end

if boss.helper.changeforpicture == 1 then
love.graphics.draw(CROWENEMY_DIE , boss.helper.X_TIMEFORDIE , boss.helper.y , 0 , scale_x , scale_y)
end

if boss.helper.changeforpicture == 2 then
love.graphics.draw(CROWENEMYNUMBER2_DIE , boss.helper.X_TIMEFORDIE , boss.helper.y , 0 , scale_x , scale_y)
end

if boss.helper.changeforpicture == 3 then
love.graphics.draw(CROWENEMYNUMBER3_DIE , boss.helper.X_TIMEFORDIE , boss.helper.y , 0 , scale_x , scale_y)
end

elseif boss.helper.isAlive == true and boss.isAlive == true then

love.graphics.draw(boss.helper.img , boss.helper.x , boss.helper.y , 0 , scale_x , scale_y)    
boss.helper:draw_hit_effect()

end



-- showing healthbar for boss.helper :: starts here

if boss.isAlive == true then

DRAW_HEALTH_BAR_ENEMY(boss.helper.changeforpicture , boss.helper.health ,  boss.helper.isAlive  , boss.helper.x , boss.helper.y) -- function.lua

end




--showing guns and fireshot :: starts here


if movingLeft == false and ducking == false then

--light gun

if shotFire == true and (should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false and 
PASSING_FINISHeD_GAME == 0 and
(enemys[1].isAlive == true or
enemys[2].isAlive == true ) or amuzeshi_gameplay == true) then
love.graphics.draw(fire , player.x + 140/2 * scale_x , player.y + 7/2 * scale_y , 0 , scale_x , scale_y)   
end

--hand gun

if shotFire == true and not((should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false) and 
enemys[1].isAlive == true or
enemys[2].isAlive == true ) and handle_SHOT_GUN == false and handle_HEAVY_GUN == false and handle_LAZER_GUN == false and not (handle_HEAVY_GUN == true) and amuzeshi_gameplay == false then
love.graphics.draw(fire , player.x + 140/2 * scale_x , player.y + 7/2 * scale_y , 0 , scale_x , scale_y)   
end

--shot gun

if shotFire == true and handle_SHOT_GUN == true and amuzeshi_gameplay == false then
love.graphics.draw(shotFireImg , player.x + 115/2 * scale_x , player.y + 18/2 * scale_y , 0 , scale_x , scale_y) 
love.graphics.draw(shotFireImg , player.x + 115/2 * scale_x , player.y + 27/2 * scale_y , 0 , scale_x , scale_y)
end

--heavy gun

if shotFire == true and handle_HEAVY_GUN == true and amuzeshi_gameplay == false then
love.graphics.draw(shotFireImg , player.x + 115/2 * scale_x , player.y + 23/2 * scale_y , 0 , scale_x , scale_y) 
end

--lazer gun

--if shotFire == true and handle_LAZER_GUN == true then
--love.graphics.draw(shotFireImg , player.x + 115 , player.y + 23) 
--end


end

--showing guns and fireshot :: ends here


-- showing head and belt :: starts here
--clothes_all.set_hat_id(0)
clothes_all.update_hat_position(player,ducking)
clothes_all.update_belt_position(player)
--
if clothes_all.hat_id == nil then
print("clothes_all.hat_id")
print(nil)
end
if clothes_all.head_right.img == nil then
print("clothes_all.head_right.img")
print(nil)
end
if clothes_all.head_left.img == nil then
print("clothes_all.head_left.img")
print(nil)
end
--]]



if clothes_all.belt_id ~= nil and clothes_all.belt.img ~= nil then

if player.health >= 4 and movingLeft == true and jumping == false  then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_l , clothes_all.belt.y_l , clothes_all.belt.ro_l , -clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and movingRight == true or player.health >= 4 and jumping == true and movingLeft == false then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_r , clothes_all.belt.y_r , clothes_all.belt.ro_r , clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and ducking == true then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_d , clothes_all.belt.y_d , clothes_all.belt.ro_d , clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and movingLeft == true and jumping == true  then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_l , clothes_all.belt.y_l , clothes_all.belt.ro_l , -clothes_all.belt.scale_x , clothes_all.belt.scale_y)
end

end



if clothes_all.hat_id ~= nil and clothes_all.head_right.img ~= nil and clothes_all.head_left.img ~= nil then

if player.health == 5 and movingLeft == true and jumping == false then
love.graphics.draw(clothes_all.head_left.img , clothes_all.head_left.x , clothes_all.head_left.y , 0 , scale_x , scale_y)
elseif player.health == 5 and movingRight == true or player.health == 5 and jumping == true and movingLeft == false then
love.graphics.draw(clothes_all.head_right.img , clothes_all.head_right.x , clothes_all.head_right.y , 0 , scale_x , scale_y)   
elseif player.health == 5 and ducking == true then
love.graphics.draw(clothes_all.head_right.img , clothes_all.head_right.x , clothes_all.head_right.y , 0 , scale_x , scale_y)
elseif player.health == 5 and movingLeft == true and jumping == true then
love.graphics.draw(clothes_all.head_left.img , clothes_all.head_left.x , clothes_all.head_left.y , 0 , scale_x , scale_y)       
end

end











love.graphics.draw(player_guns.img , player_guns.x , player_guns.y , 0 , scale_x , scale_y)


-- showing head and belt :: ends here
if amuzeshi_gameplay == true then
love.graphics.draw(A_background , background1.x , background1.y , 0 , scale_x , scale_y)

if headofmamouth == HEADOFMAMOUTH[6] then

love.graphics.draw(AA_background , background1.x , background1.y , 0 , scale_x , scale_y)

end

end





--BOSS

if boss.isAlive == true then

DRAW_BOSS() --function.lua

end

if should_summon_boss1 == true then

love.graphics.draw(BOSS_WALKING_IMG , BOSS_WALKING_X , BOSS_WALKING_Y , 0 , scale_x , scale_y)

end

DRAW_BOSS_DEAD() --function.lua




if boss2.isAlive == true then

DRAW_BOSS2() --function.lua

end

if should_summon_boss2 == true then

love.graphics.draw(BOSS2_WALKING_IMG , BOSS2_WALKING_X , BOSS2_WALKING_Y , 0 , scale_x , scale_y)

end

DRAW_BOSS2_DEAD() --function.lua








--love.draw.rectangle(200 , 0 , 10 , 800)
-- CheckCollision TEST :: starts here 


--if testCollision1 == true then

-- rect1 :: body_stand&&movingRight
--love.graphics.rectangle('fill',rect1.x,rect1.y,rect1.w,rect1.h)


-- rect2 :: legs_stand&&movingRight
--love.graphics.rectangle('fill',rect2.x,rect2.y,rect2.w,rect2.h)



-- rect3 :: hand_stand&&movingRight
--love.graphics.rectangle('fill',rect3.x,rect3.y,rect3.w,rect3.h)



-- rect4 :: head_stand&&movingRight
--love.graphics.rectangle('fill',rect4.x,rect4.y,rect4.w,rect4.h)

--end


--if testCollision2 == true then

-- rect6 :: legs_movingLeft
--love.graphics.rectangle('fill',rect6.x,rect6.y,rect6.w,rect6.h)



-- rect7 :: body_movingLeft
--love.graphics.rectangle('fill',rect7.x,rect7.y,rect7.w,rect7.h)



-- rect8 :: head_movingLeft
--love.graphics.rectangle('fill',rect8.x,rect8.y,rect8.w,rect8.h)

--end

--if testCollision3 == true then


-- rect1 :: body_stand&&movingRight
--love.graphics.rectangle('fill',rect1.x,rect1.y,rect1.w,rect1.h)



-- rect3 :: hand_stand&&movingRight
--love.graphics.rectangle('fill',rect3.x,rect3.y,rect3.w,rect3.h)



-- rect4 :: head_stand&&movingRight
--love.graphics.rectangle('fill',rect4.x,rect4.y,rect4.w,rect4.h)



-- rect5 :: leg_jumped
--love.graphics.rectangle('fill',rect5.x,rect5.y,rect5.w,rect5.h)

--end

--if testCollision4 == true then

-- rect9 :: legs_ducked
--love.graphics.rectangle('fill',rect9.x,rect9.y,rect9.w,rect9.h)



-- rect10 :: hand_ducked
--love.graphics.rectangle('fill',rect10.x,rect10.y,rect10.w,rect10.h)



-- rect11 :: head_ducked
--love.graphics.rectangle('fill',rect11.x,rect11.y,rect11.w,rect11.h)

--end

-- rect12 :: Block_usage
--love.graphics.rectangle('fill',rect12.x,rect12.y,rect1.w,rect12.h)



-- CheckCollision TEST :: ends here






--drawing player bullets :: start



for i = 1 , #bullets do
if bullets[i].visible ~= false then 
	love.graphics.draw(bullets[i].img , bullets[i].x , bullets[i].y , 0 , scale_x , scale_y)
end
end



--the end



--drawing enemys_helicoopter bullets :: start



for i = 1 , #enemys[1].EBullets do
if enemys[1].EBullets[i].visible ~= false then 
	love.graphics.draw(enemys[1].EBullets[i].img , enemys[1].EBullets[i].x , enemys[1].EBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[1].EBullets[i].x,enemys[1].EBullets[i].y,10,5)
end
end



for i = 1 , #enemys[2].EBullets do
if enemys[2].EBullets[i].visible ~= false then 
	love.graphics.draw(enemys[2].EBullets[i].img , enemys[2].EBullets[i].x , enemys[2].EBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end




for i = 1 , #boss.helper.EBullets do
if boss.helper.EBullets[i].visible ~= false then 
	love.graphics.draw(boss.helper.EBullets[i].img , boss.helper.EBullets[i].x , boss.helper.EBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end





--the end



--drawing BOSS bullets :: start
for i = 1 , #boss.BBullets do
if boss.BBullets[i].visible ~= false then 
	love.graphics.draw(boss.BULLET_IMG , boss.BBullets[i].x , boss.BBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end



--drawing BOSS2 bullets :: start
for i = 1 , #boss2.BBullets do
if boss2.BBullets[i].visible ~= false then 
	love.graphics.draw(boss2.BULLET_IMG , boss2.BBullets[i].x , boss2.BBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end






love.graphics.draw(touch_pad_lefty, 0 , 0 , 0 , scale_x , scale_y)
--for left
--love.graphics.rectangle('fill' , 42 * scale_x , 368 * scale_y , 53/2 * scale_x , 57/2 * scale_y)
--for right
--love.graphics.rectangle('fill' , 178 * scale_x , 368 * scale_y , 53/2 * scale_x , 57/2 * scale_y)
--for up
--love.graphics.rectangle('fill' , 110 * scale_x , 322 * scale_y , 53/2 * scale_x , 57/2 * scale_y)
--for down
--love.graphics.rectangle('fill' , 110 * scale_x , 420 * scale_y , 53/2 * scale_x , 57/2 * scale_y)
--for shoot
--love.graphics.rectangle('fill' , 400 * scale_x , 0 , 400 * scale_x , 530 * scale_y)



if GAME_PlAY == true and studio_bool == false and menu_pad ~= change_clothes and after_lost_choose == false then

if gamepaused == true then

if amuzeshi_gameplay == false then

love.graphics.draw(play_img , 0 , 0 , 0 , scale_x , scale_y)


else

love.graphics.draw(play_img_a , 0 , 0 , 0 , scale_x , scale_y)

end


else 

love.graphics.draw(stop_img , 0 , 0 , 0 , scale_x , scale_y)

end	

end


if enemys[1].isAlive == false and enemys[2].isAlive == false then

if boss.isAlive == false and boss2.isAlive == false and boss3.isAlive == false then


if BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then


if hand_help_framespeed >= 12 then
hand_help_framespeed = 0
if hand_help_frame < 2 then
	hand_help_frame = hand_help_frame + 1
else
	hand_help_frame = 1
end
else
	hand_help_framespeed = hand_help_framespeed + 1
end
hand = hand_help[hand_help_frame]

if amuzeshi_gameplay == false then

love.graphics.draw(hand , 0 , 0 , 0 , scale_x , scale_y)

end


end

end

end









if should_summon_boss3 == true or (should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == false and boss3_finished == true) then



	DRAW_BACKGROUND_BOSS3()


--CONGRATULATION
DRAW_CONGRATULATION()




--DRAWING SCORE && AMMO :: starts here

for i = 1 , #SCORES do
love.graphics.draw(SCORES[i].img , SCORES[i].x , SCORES[i].y , 0 , scale_x , scale_y)
end

for i = 1 , #AMMOTOSHOW do
love.graphics.draw(AMMOTOSHOW[i].img , AMMOTOSHOW[i].x , AMMOTOSHOW[i].y , 0 , scale_x , scale_y)
end

love.graphics.draw(AMMOTIME.img , AMMOTIME.x , AMMOTIME.y , 0 , scale_x , scale_y)
love.graphics.draw(CLOCK , AMMOTIME.x - 48/2 * scale_x , AMMOTIME.y - 3/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(AMMO_BULLET , AMMOTOSHOW[2].x + 75/2 * scale_x , AMMOTOSHOW[2].y - 17/2 * scale_y , 0 , scale_x , scale_y)

--DRAWING SCORE && AMMO :: ends here





if #boss.BBullets > 0 or should_summon_boss1 == true or should_summon_boss3 == true then
love.graphics.draw(BLOCKJUMPFORFIGHTINGBOSS , BLOCKJUMPS[blockforfightingboss1].x , BLOCKJUMPS[blockforfightingboss1].y , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill' , BLOCKJUMPS[blockforfightingboss1].x , BLOCKJUMPS[blockforfightingboss1].y , BLOCKJUMPS[blockforfightingboss1].width , BLOCKJUMPS[blockforfightingboss1].height)
love.graphics.draw(BLOCKJUMPFORFIGHTINGBOSS , BLOCKJUMPS[blockforfightingboss2].x , BLOCKJUMPS[blockforfightingboss2].y , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill' , BLOCKJUMPS[blockforfightingboss2].x , BLOCKJUMPS[blockforfightingboss2].y , BLOCKJUMPS[blockforfightingboss2].width , BLOCKJUMPS[blockforfightingboss2].height)
else
BLOCKJUMPS[blockforfightingboss1].onBlock = false 
BLOCKJUMPS[blockforfightingboss2].onBlock = false
end








love.graphics.draw(player.img , player.x , player.y , 0 , scale_x , scale_y)

--showing guns and fireshot :: starts here


if movingLeft == false and ducking == false then

--light gun

if shotFire == true and should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false and 
PASSING_FINISHeD_GAME == 0 and
(enemys[1].isAlive == true or
enemys[2].isAlive == true ) then
love.graphics.draw(fire , player.x + 140/2 * scale_x , player.y + 7/2 * scale_y , 0 , scale_x , scale_y)   
end

--hand gun

if shotFire == true and not((should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false) and 
enemys[1].isAlive == true or
enemys[2].isAlive == true ) and handle_SHOT_GUN == false and handle_HEAVY_GUN == false and handle_LAZER_GUN == false and not (handle_HEAVY_GUN == true) then
love.graphics.draw(fire , player.x + 140/2 * scale_x , player.y + 7/2 * scale_y , 0 , scale_x , scale_y)   
end

--shot gun

if shotFire == true and handle_SHOT_GUN == true then
love.graphics.draw(shotFireImg , player.x + 115/2 * scale_x , player.y + 18/2 * scale_y , 0 , scale_x , scale_y) 
love.graphics.draw(shotFireImg , player.x + 115/2 * scale_x , player.y + 27/2 * scale_y , 0 , scale_x , scale_y)
end

--heavy gun

if shotFire == true and handle_HEAVY_GUN == true then
love.graphics.draw(shotFireImg , player.x + 115/2 * scale_x , player.y + 23/2 * scale_y , 0 , scale_x , scale_y) 
end

--lazer gun

--if shotFire == true and handle_LAZER_GUN == true then
--love.graphics.draw(shotFireImg , player.x + 115 , player.y + 23) 
--end


end

--showing guns and fireshot :: ends here


-- showing head and belt :: starts here
clothes_all.update_hat_position(player,ducking)
clothes_all.update_belt_position(player)




if clothes_all.belt_id ~= nil and clothes_all.belt.img ~= nil then

if player.health >= 4 and movingLeft == true and jumping == false  then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_l , clothes_all.belt.y_l , clothes_all.belt.ro_l , -clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and movingRight == true or player.health >= 4 and jumping == true and movingLeft == false then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_r , clothes_all.belt.y_r , clothes_all.belt.ro_r , clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and ducking == true then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_d , clothes_all.belt.y_d , clothes_all.belt.ro_d , clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and movingLeft == true and jumping == true  then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_l , clothes_all.belt.y_l , clothes_all.belt.ro_l , -clothes_all.belt.scale_x , clothes_all.belt.scale_y)
end

end


if clothes_all.hat_id ~= nil and clothes_all.head_right.img ~= nil and clothes_all.head_left.img ~= nil then

if player.health == 5 and movingLeft == true and jumping == false then
love.graphics.draw(clothes_all.head_left.img , clothes_all.head_left.x , clothes_all.head_left.y , 0 , scale_x , scale_y)
elseif player.health == 5 and movingRight == true or player.health == 5 and jumping == true and movingLeft == false then
love.graphics.draw(clothes_all.head_right.img , clothes_all.head_right.x , clothes_all.head_right.y , 0 , scale_x , scale_y)   
elseif player.health == 5 and ducking == true then
love.graphics.draw(clothes_all.head_right.img , clothes_all.head_right.x , clothes_all.head_right.y , 0 , scale_x , scale_y)
elseif player.health == 5 and movingLeft == true and jumping == true then
love.graphics.draw(clothes_all.head_left.img , clothes_all.head_left.x , clothes_all.head_left.y , 0 , scale_x , scale_y)       
end

end




-- showing head and belt :: ends here

--drawing player bullets :: start
love.graphics.draw(player_guns.img , player_guns.x , player_guns.y , 0 , scale_x , scale_y)

for i = 1 , #bullets do
if bullets[i].visible ~= false then 
	love.graphics.draw(bullets[i].img , bullets[i].x , bullets[i].y , 0 , scale_x , scale_y)
end
end





if boss3.isAlive == true then

DRAW_BOSS3() --function.lua

end

if should_summon_boss3 == true then

love.graphics.draw(BOSS3_WALKING_IMG , BOSS3_WALKING_X , BOSS3_WALKING_Y + 110/2 * scale_y , 0 , scale_x , scale_y)

end


DRAW_BOSS3_DEAD() --function.lua




--drawing BOSS3 TO FIRE bullets :: start
for i = 1 , #boss3.BBullets do
if boss3.BBullets[i].visible ~= false then 
	love.graphics.draw(boss3.BULLET_IMG , boss3.BBullets[i].x , boss3.BBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end




--the end


--drawing BOSS3 TO CREEP bullets :: start
for i = 1 , #boss3.BBullets1 do
if boss3.BBullets1[i] == nil then
break
elseif boss3.BBullets1 ~= nil then


if boss3.BBullets1[i].goingright == false and boss3.BBullets1[i].goingleft == true and boss3.BBullets1[i].visible ~= false then

boss3:BULLETIMG1()

	love.graphics.draw(boss3.BULLET1_IMG , boss3.BBullets1[i].x , boss3.BBullets1[i].y , 0 , scale_x , scale_y)


elseif boss3.BBullets1[i].goingright == true and boss3.BBullets1[i].goingleft == false and boss3.BBullets1[i].visible ~= false then 

	love.graphics.draw(boss3.BULLET1_2IMG , boss3.BBullets1[i].x , boss3.BBullets1[i].y , 0 , scale_x , scale_y)

boss3:BULLETIMG1_2()
 

end 
end
end
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)





--the end


--drawing BOSS3 TO GLAD bullets :: start
for i = 1 , #boss3.BBullets2 do
if boss3.BBullets2[i].visible ~= false then 
	love.graphics.draw(boss3.BULLET2_IMG , boss3.BBullets2[i].x , boss3.BBullets2[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end




--the end


love.graphics.draw(touch_pad_lefty, 0 , 0 , 0 , scale_x , scale_y)

if GAME_PlAY == true and studio_bool == false and menu_pad ~= change_clothes and after_lost_choose == false then

if gamepaused == true then

if amuzeshi_gameplay == false then	

love.graphics.draw(play_img , 0 , 0 , 0 , scale_x , scale_y)


else

love.graphics.draw(play_img_a , 0 , 0 , 0 , scale_x , scale_y)

end	


else 

love.graphics.draw(stop_img , 0 , 0 , 0 , scale_x , scale_y)

end	

end

if enemys[1].isAlive == false and enemys[2].isAlive == false then

if boss.isAlive == false and boss2.isAlive == false and boss3.isAlive == false then

if BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then

if amuzeshi_gameplay == false then

love.graphics.draw(hand , 0 , 0 , 0 , scale_x , scale_y)

end

end

end

end


end






else--pause

pasus_display()



if GAME_PlAY == true and studio_bool == false and menu_pad ~= change_clothes and after_lost_choose == false then

if gamepaused == true then

if amuzeshi_gameplay == false then

love.graphics.draw(play_img , 0 , 0 , 0 , scale_x , scale_y)

else

love.graphics.draw(play_img_a , 0 , 0 , 0 , scale_x , scale_y)

end	


else 

love.graphics.draw(stop_img , 0 , 0 , 0 , scale_x , scale_y)

end	

end





end--pause 





end

--love.graphics.draw(GRASS1[2] , 750 , 415)



else


love.graphics.draw(studio_pic , 0 , 0 , 0 , scale_x , scale_y)


end--studio_bool




gameover_show()



if after_lost_choose == true then

love.audio.stop()

pasus_display()

love.graphics.draw(after_lost_choose_img , 0 , 0 , 0 , scale_x , scale_y)

for i = 1 , #SCORES do
love.graphics.draw(SCORES[i].img , SCORES[i].x , SCORES[i].y , 0 , scale_x , scale_y)
end

end-- after_lost_choose





--for seting new controller:

--for left
--love.graphics.rectangle('fill' , touchX_left , touchY_left - 57/2 * scale_y * 0.4 , 53/2 * scale_x * 1.5 , 57/2 * scale_y * 1.5)

--for right
--love.graphics.rectangle('fill' , touchX_right +  53/2 * scale_x * 1.35 , touchY_right - 57/2 * scale_y * 0.4 , 53/2 * scale_x * 1.5 , 57/2 * scale_y * 1.5)

--for up
--love.graphics.rectangle('fill' , touchX_up + 53/2 * scale_x * 0.45 , touchY_up - 57/2.2 * scale_y , 53/2 * scale_x * 2  , 57/2 * scale_y * 1.3 )

--for down
--love.graphics.rectangle('fill' , touchX_down + 53/2 * scale_x * 0.45 , touchY_down + 57/2.2 * scale_y * 0.2 , 53/2 * scale_x * 2  , 57/2 * scale_y * 1.3 )


-- for checking new controller:

--for left
--love.graphics.rectangle('fill' , touchX_left , touchY_left , 53/2 * scale_x * 1.5 , 57/2 * scale_y * 1.5)

--for right
--love.graphics.rectangle('fill' , touchX_right  , touchY_right , 53/2 * scale_x * 1.5 , 57/2 * scale_y * 1.5)

--for up
--love.graphics.rectangle('fill' , touchX_up  , touchY_up  , 53/2 * scale_x * 2  , 57/2 * scale_y * 1.3 )

--for down
--love.graphics.rectangle('fill' , touchX_down  , touchY_down  , 53/2 * scale_x * 2  , 57/2 * scale_y * 1.3 )



else

--love.graphics.rectangle("fill" , 0 , 0 , 400 , 400)	display powered by love2d



end-- if loader.should_start_the_game()




end--love.draw()









function love.update(dt)

if loader.should_start_the_game() then		

if amuzeshi_gameplay == true then

amuzeshi_gameplay_update()--function.lua

end



gameover_update()--function.lua

if GAME_PlAY == false then

timer_pad = timer_pad + 1

if menu ~= SCORE_IMAGE and menu ~= amuzesh then 

menu_animation()--function.lua

end

if menu ~= SCORE_IMAGE and menu ~= amuzesh then

if studio_bool == false then

menu_sound:play()

end

else

love.audio.stop(menu_sound)	

end	

end


if studio_bool == false then
	
love.audio.stop(studio_music)





if GAME_PlAY == true then


if gamepaused == false then	









-- player rectangles for CheckCollision :: function.lua

player_rectangles_update()

-- GAME_PLAY_ENEMYS :: function.lua

GAME_PLAY_ENEMYS()

-- PLAYER_FUNCTIONS

PLAYER_functions()

-- enemys_animation :: function.lua

Enemys_Animation ()

-- guns_Update :: Guns.lua

player_guns:update()


--Code for enemys_helicoopter :: starts here

for i = 1 , #enemys do

if enemys[i].isAlive == true then 
enemys[i]:Ai()

if amuzeshi_gameplay == false then
enemys[i]:attack()
enemys[i]:attack_update()
end

enemys[i]:update_getHit()
else
enemys[i]:die()
end

end

for i = 1 , #enemys do

if enemys[i].isAlive == false then

if #enemys[i].EBullets >= 1 then

for j = 1 , #enemys[i].EBullets do

if enemys[i].EBullets ~= nil then

table.remove(enemys[i].EBullets,j)

end	

end

end

end

end


if pass >=1 then
if player.health ~= 5 then    
player.health = player.health + 1
else
scoore = scoore + 5

scoore_update() --update scoore :: function.lua

AMMO = AMMO + 8
end	
    pass = 0

        enemys[1]:reborn(0)
        enemys[2]:reborn(enemys[1].changeforpicture)


if should_summon_boss1 == false and boss1_finished == true and boss2_finished == false then should_summon_boss2 = true 

handle_SHOT_GUN = true
handle_HEAVY_GUN = false
handle_LAZER_GUN = false


if PASSING_FINISHeD_GAME == 0 then
jupiter = require "jupiter"
data = {_fileName = "checkpoint.txt", 2}
success = jupiter.save(data)
else
jupiter = require "jupiter"
data = {_fileName = "checkpoint.txt", 1}
success = jupiter.save(data)
end


end

if should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and boss3_finished == false then should_summon_boss3 = true 

handle_HEAVY_GUN = true
handle_SHOT_GUN = false
handle_LAZER_GUN = false


if PASSING_FINISHeD_GAME == 0 then
jupiter = require "jupiter"
data = {_fileName = "checkpoint.txt", 3}
success = jupiter.save(data)
else
jupiter = require "jupiter"
data = {_fileName = "checkpoint.txt", 1}
success = jupiter.save(data)
end


end

if should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == false and boss3_finished == true then 
    
    PASSING_FINISHeD_GAME = PASSING_FINISHeD_GAME + 1

    boss1_finished = false
    boss2_finished = false
    boss3_finished = false
	should_summon_boss1 = true 

    handle_LAZER_GUN = true
    handle_SHOT_GUN = false
    handle_HEAVY_GUN = false



jupiter = require "jupiter"
data = {_fileName = "checkpoint.txt", 1}
success = jupiter.save(data)



end


CONG_HANDLER = false


end




if pass1 >=1 then
if player.health ~= 5 then    
player.health = player.health + 1
else
scoore = scoore + 5

scoore_update() --update scoore :: function.lua


AMMO = AMMO + 8
end

pass1 = 0
passing = false

if should_summon_boss1 == true then

boss:reborn()
boss.helper:reborn(0)
boss.t = 0
boss.t1 = 0
boss.shouldgethit = false

end

if should_summon_boss2 == true then

boss2:reborn()
boss2.t = 0
boss2.t1 = 0
boss2.t2 = 0
boss2.shouldgethit = false

end

if should_summon_boss3 == true then

boss3:reborn()
boss3:RANDOMIZE()
boss3.t = 0
boss3.t1 = 0
boss3.t2 = 0
boss3.t3 = 0
boss3.t4 = 0
boss3.changeToLight = true
boss3.FIRST_ATTACK = false
boss3.shouldgethit = false
boss3.to_first = true
boss3.to_second = false
boss3.to_third = false
boss3.to_get = false

end


end



-- BOSS FUNCTIONS
if boss.isAlive == true then
boss:ShouldGetHit()	
boss:BULLETIMG()
if boss.should_summon_helper == true  then
boss.helper:reborn(0)
boss_frame_ATTACK = 1
boss.should_summon_helper = false
end

if boss.helper.isAlive == true then 	
boss.helper:Ai()
boss.helper:attack()
boss.helper:attack_update()
boss.helper:update_getHit()
else
boss.helper:die()
end


if boss.helper.isAlive == false then

if #boss.helper.EBullets >= 1 then

for j = 1 , #boss.helper.EBullets do

if boss.helper.EBullets ~= nil then

table.remove(boss.helper.EBullets,j)

end	

end

end

end




if boss.isAlive == true then
if boss.shouldgethit == false and boss.helper.isAlive == false then
if boss.img == boss.BOSSIMAGES.BOSS_ATTACK[7] then
boss:attack()
end
boss:attack_update()
elseif boss.shouldgethit == true then 

boss.BBullets = {}

boss:update_getHit()	
end
else
boss:die()	


boss.BBullets = {}


end
else
boss:attack_update()
boss:BULLETIMG()	
end


for i = 1 , #boss.BBullets do
if boss.BBullets[i] == nil then
break
elseif boss.helper.isAlive == true and boss.BBullets ~= nil then
table.remove(boss.BBullets,i)  
end
end


for i = 1 , #boss.helper.EBullets do
if boss.helper.EBullets ~= nil and boss.helper.EBullets[i] ~= nil then
if CheckCollision(BLOCKJUMPS[blockforfightingboss1].x , BLOCKJUMPS[blockforfightingboss1].y , BLOCKJUMPS[blockforfightingboss1].width , BLOCKJUMPS[blockforfightingboss1].height , boss.helper.EBullets[i].x , boss.helper.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true 
or CheckCollision(BLOCKJUMPS[blockforfightingboss2].x , BLOCKJUMPS[blockforfightingboss2].y , BLOCKJUMPS[blockforfightingboss2].width , BLOCKJUMPS[blockforfightingboss2].height , boss.helper.EBullets[i].x , boss.helper.EBullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true 
then
table.remove(boss.helper.EBullets,i) 
end
end
end









-- BOSS2 FUNCTIONS


BOSS2_DRIL() --function.lua
BOSS2_TREMBL() --function.lua


if boss2.isAlive == true then
boss2:ShouldGetHit()	
boss2:BULLETIMG()



if boss2.isAlive == true then
if boss2.shouldgethit == false and boss2.SECOND_ATTACK == false then
boss2:attack()
boss2:attack_update()
elseif boss2.shouldgethit == true then 
boss2:update_getHit()	

boss2.BBullets = {}

end
else
boss2:die()	


boss2.BBullets = {}


end
else
boss2:attack_update()
boss2:BULLETIMG()	
end


if boss2.SECOND_ATTACK == true then

boss2.BBullets = {}

end












-- BOSS3 TO SKEL
BOSS3_TO_SKEL_ATTACK() --function.lua
BOSS3_TO_SKEL_END_OF_ATTACK() --function.lua
BOSS3_TO_SKEL_CHANGE_POSITION() --function.lua


if boss3.isAlive == true then
boss3:ShouldGetHit()	

--function.lua
if BOSS3_TO_FIRE_SHOULD_ATTACK() then

boss3:BOSS3_TO_FIRE_ATTACK()


elseif not BOSS3_TO_FIRE_SHOULD_ATTACK() then

for i = 1 , #boss3.BBullets do
if boss3.BBullets[i] == nil then
break
elseif boss3.BBullets ~= nil then
table.remove(boss3.BBullets,i)  
end
end

end


-- BOSS3 TO FIRE
boss3:BOSS3_TO_FIRE_ATTACK_UPDATE()
boss3:BULLETIMG()



--function.lua
if BOSS3_TO_CREEP_SHOULD_ATTACK() then

boss3:BOSS3_TO_CREEP_ATTACK()

elseif not BOSS3_TO_CREEP_SHOULD_ATTACK() then

for i = 1 , #boss3.BBullets1 do
if boss3.BBullets1[i] == nil then
break
elseif boss3.BBullets1 ~= nil then
table.remove(boss3.BBullets1,i)  
end
end

end



-- BOSS3 TO FIRE
boss3:BOSS3_TO_CREEP_ATTACK_UPDATE()






--function.lua
if BOSS3_TO_GLAD_SHOULD_ATTACK() then

boss3:BOSS3_TO_GLAD_ATTACK()

elseif not BOSS3_TO_GLAD_SHOULD_ATTACK() then

for i = 1 , #boss3.BBullets2 do
if boss3.BBullets2[i] == nil then
break
elseif boss3.BBullets2 ~= nil then
table.remove(boss3.BBullets2,i)  
end
end

end



-- BOSS3 TO FIRE
boss3:BOSS3_TO_GLAD_ATTACK_UPDATE()
boss3:BULLETIMG2()















if boss3.shouldgethit == true then

boss3:update_getHit()

end


end


--[[
for i = 1 , #boss3.BBullets do
if boss3.BBullets[i] == nil then
break
elseif boss3.SECOND_ATTACK == true and boss3.BBullets ~= nil then
table.remove(boss3.BBullets,i)  
end
end
--]]



--Animation for CROWS :: starts here


if Crow_frameSpeed >= 25 * 0.018 then
Crow_frameSpeed = 0
if Crow_frame < 5 then
    Crow_frame = Crow_frame + 1
else
    Crow_frame = 1
end
else
    Crow_frameSpeed = Crow_frameSpeed + 0.028
end
Crow1.img = Crow[Crow_frame]


if FLYINGBIRD_frameSpeed >= 8 * 0.018 then
FLYINGBIRD_frameSpeed = 0
if FLYINGBIRD_frame < 11 then
    FLYINGBIRD_frame = FLYINGBIRD_frame + 1
else
    FLYINGBIRD_frame = 1
end
else
    FLYINGBIRD_frameSpeed = FLYINGBIRD_frameSpeed + 0.028
end
flyingbird.img = FLYINGBIRD[FLYINGBIRD_frame]


--Animation for CROWS :: end here



--Code for SCORES and AMMO :: starts here





for i = 1 , #SCORES do
SCORES[i]:SCORE_UPDATE_IMAGE()
end

for i = 1 , #AMMOTOSHOW do
AMMOTOSHOW[i]:SCORE_UPDATE_IMAGE()
end

AMMOTIME:SCORE_UPDATE_IMAGE()

AMMOTOSHOW[1].toshow = AMMO % 10

AMMOTOSHOW[2].toshow = ((AMMO % 100) - AMMOTOSHOW[1].toshow )/10

AMMOTOSHOW[3].toshow = ((AMMO % 1000) - AMMOTOSHOW[2].toshow - AMMOTOSHOW[1].toshow )/100

if enemys[1].isAlive == true and enemys[2].isAlive == false or enemys[2].isAlive == true and enemys[1].isAlive == false then
AMMO_TIME = AMMO_TIME + dt
if AMMO_TIME >= 4 then
AMMO_TIME = 0    
AMMOTIME.toshow = AMMOTIME.toshow - 1
end

if AMMOTIME.toshow <= 0 then
AMMOTIME.toshow = 9
AMMO = AMMO + 8
end

elseif enemys[1].isAlive == true and enemys[2].isAlive == true then

AMMO_TIME = AMMO_TIME + dt
if AMMO_TIME >= 2 then
AMMO_TIME = 0    
AMMOTIME.toshow = AMMOTIME.toshow - 1
end

if AMMOTIME.toshow <= 0 then
AMMOTIME.toshow = 9
AMMO = AMMO + 8
end

elseif boss.isAlive == true then

AMMO_TIME = AMMO_TIME + dt
if AMMO_TIME >= 4 then
AMMO_TIME = 0    
AMMOTIME.toshow = AMMOTIME.toshow - 1
end

if AMMOTIME.toshow <= 0 then
AMMOTIME.toshow = 9
AMMO = AMMO + 8
end

elseif boss2.isAlive == true then

AMMO_TIME = AMMO_TIME + dt
if AMMO_TIME >= 4 then

AMMO_TIME = 0    
AMMOTIME.toshow = AMMOTIME.toshow - 1
end

if AMMOTIME.toshow <= 0 then
AMMOTIME.toshow = 9
AMMO = AMMO + 8
end

elseif boss3.isAlive == true then

AMMO_TIME = AMMO_TIME + dt
if AMMO_TIME >= 4 then
AMMO_TIME = 0    
AMMOTIME.toshow = AMMOTIME.toshow - 1
end

if AMMOTIME.toshow <= 0 then
AMMOTIME.toshow = 9
AMMO = AMMO + 8
end

end




--Code for SCORES and AMMO :: ends here





--Code for BLOCKJUMPS starts :: here

if enemys[1].isAlive == true or enemys[2].isAlive == true then


BLOCKJUMPS[blockJumpForHelis]:Update()


end

if not (enemys[1].isAlive == true or enemys[2].isAlive == true) and #boss.BBullets > 0 or should_summon_boss1 == true or should_summon_boss3 == true then

BLOCKJUMPS[blockforfightingboss1]:Update()

BLOCKJUMPS[blockforfightingboss2]:Update()

end



  
if not (enemys[1].isAlive == true or enemys[2].isAlive == true)  then

if BLOCKJUMPS[blockforfightingboss1].onBlock == true  then
GROUND = BLOCKJUMPS[blockforfightingboss1].GROUND
elseif BLOCKJUMPS[blockforfightingboss1].onBlock == false and BLOCKJUMPS[blockforfightingboss2].onBlock == false then
    GROUND = MAINGROUND
end

if BLOCKJUMPS[blockforfightingboss2].onBlock == true  then
GROUND = BLOCKJUMPS[blockforfightingboss2].GROUND
elseif BLOCKJUMPS[blockforfightingboss2].onBlock == false and BLOCKJUMPS[blockforfightingboss1].onBlock == false then
    GROUND = MAINGROUND
end


end







--Code for BLOCKJUMPS ends :: here





--Code for HEADOFMAMOUTH :: starts here



if enemys[1].isAlive == true or enemys[2].isAlive == true then
HEADOFMAMOUTHAnimationStart = true
if HEADOFMAMOUTHAnimationStart == true then

if HEADOFMAMOUTH_framespeed >= 5 then
HEADOFMAMOUTH_framespeed = 0
if HEADOFMAMOUTH_frame < 6 then
    HEADOFMAMOUTH_frame = HEADOFMAMOUTH_frame + 1
if HEADOFMAMOUTH_frame > 2 then 
    headofmamouthY = headofmamouthY - 15/2 * scale_y
end
else
    HEADOFMAMOUTHAnimationStart = false
end
else
    HEADOFMAMOUTH_framespeed = HEADOFMAMOUTH_framespeed + .2
end
headofmamouth = HEADOFMAMOUTH[HEADOFMAMOUTH_frame]
end
end

if not ( enemys[1].isAlive == true or enemys[2].isAlive == true ) and amuzeshi_gameplay == false then
HEADOFMAMOUTHAnimationStart = true
if HEADOFMAMOUTHAnimationStart == true then

if HEADOFMAMOUTH_framespeed >= 5 then
HEADOFMAMOUTH_framespeed = 0
if HEADOFMAMOUTH_frame > 1  then
    HEADOFMAMOUTH_frame = HEADOFMAMOUTH_frame - 1
if HEADOFMAMOUTH_frame < 5 then  
    headofmamouthY = headofmamouthY + 15/2 * scale_y
end
else
    HEADOFMAMOUTHAnimationStart = false
end
else
    HEADOFMAMOUTH_framespeed = HEADOFMAMOUTH_framespeed + .2
end
headofmamouth = HEADOFMAMOUTH[HEADOFMAMOUTH_frame]
end
end


if enemys[1].isAlive == true or enemys[2].isAlive == true then

if headofmamouth == HEADOFMAMOUTH[6] then

if BLOCKJUMPS[blockJumpForHelis].onBlock ==  true  then
GROUND = BLOCKJUMPS[blockJumpForHelis].GROUND
else 
    BLOCKJUMPS[blockJumpForHelis].onBlock = false
    GROUND = MAINGROUND
end

end

end

--Code for HEADOFMAMOUTH :: ends here






--Code for BLOCKJUMPS ends :: here


end











--code for sound && music :: starts here


if play_music == 1 and gameover_explode_bool == false then


--music for GAMEOVER&GAMESTART
if GAME_PlAY == false then
GAMEOVER_MUSIC_BOOLEAN = true
end

if GAMEOVER_MUSIC_BOOLEAN == true and GAME_PlAY == false then
GAMEOVER_MUSIC:play()
GAMEOVER_MUSIC_BOOLEAN = false
end

if GAMEOVER_MUSIC_BOOLEAN == false and GAME_PlAY == false and not GAMEOVER_MUSIC:isPlaying() then
GAMEOVER_MUSIC_BOOLEAN = true
end

if GAME_PlAY == true and GAMEOVER_MUSIC:isPlaying() then
love.audio.stop(GAMEOVER_MUSIC)
end


--music&sounds for boss1 
if GAME_PlAY == true then


if should_summon_boss1 == true then
BOSS1_THEME_MUSIC_BOOLEAN = true
end	

if BOSS1_THEME_MUSIC_BOOLEAN == true and should_summon_boss1 == true then
BOSS1_THEME_MUSIC:play()
BOSS1_THEME_MUSIC_BOOLEAN = false
end

if BOSS1_THEME_MUSIC_BOOLEAN == false and should_summon_boss1 == true and not BOSS1_THEME_MUSIC:isPlaying() then
BOSS1_THEME_MUSIC_BOOLEAN = true
end

if should_summon_boss1 == false and BOSS1_THEME_MUSIC:isPlaying() then
love.audio.stop(BOSS1_THEME_MUSIC)
end


end

if GAME_PlAY == false and BOSS1_THEME_MUSIC:isPlaying() then
love.audio.stop(BOSS1_THEME_MUSIC)
end
--




--boss1 wait
if boss.isAlive == true and boss.shouldgethit == false and boss.helper.isAlive == true and GAME_PlAY == true then
BOSS1_WAIT_SOUND:play()
end

if not(boss.isAlive == true and boss.shouldgethit == false and boss.helper.isAlive == true) or GAME_PlAY == false then
love.audio.stop(BOSS1_WAIT_SOUND)
end
--



--boss1 gethit
if boss.isAlive == true and boss.shouldgethit == true and boss.helper.isAlive == false and GAME_PlAY == true then
BOSS1_GETHIT_SOUND:play()
end

if not(boss.isAlive == true and boss.shouldgethit == true and boss.helper.isAlive == false) or GAME_PlAY == false then
love.audio.stop(BOSS1_GETHIT_SOUND)
end
--


--boss1 attack
if boss.isAlive == true and boss.shouldgethit == false and boss.helper.isAlive == false and GAME_PlAY == true then
BOSS1_ATTACK_SOUND:play()
end

if not(boss.isAlive == true and boss.shouldgethit == false and boss.helper.isAlive == false) or GAME_PlAY == false then
love.audio.stop(BOSS1_ATTACK_SOUND)
end
--


--boss1 die
if BOSS_DEAD_shouldshow == true then

if BOSS1_DIE_SOUND_PLAYED < 1 then
BOSS1_DIE_SOUND:play()
BOSS1_DIE_SOUND_PLAYED = BOSS1_DIE_SOUND_PLAYED + 1
end

end

if BOSS_DEAD_shouldshow == false then	
love.audio.stop(BOSS1_DIE_SOUND)
BOSS1_DIE_SOUND_PLAYED = 0
end
--

--boss1 in flames
if BOSS_DEAD_shouldshow == true then

BOSS1_INFLAME_SOUND:play()

end

if BOSS_DEAD_shouldshow == false then	

love.audio.stop(BOSS1_INFLAME_SOUND)

end
--




--sound for rain
if GAME_PlAY == true then


if should_summon_boss1 == true then
RAIN_SOUND_BOOLEAN = true
end	

if RAIN_SOUND_BOOLEAN == true and should_summon_boss1 == true then
RAIN_SOUND:play()
RAIN_SOUND_BOOLEAN = false
end

if RAIN_SOUND_BOOLEAN == false and should_summon_boss1 == true and not RAIN_SOUND:isPlaying() then
RAIN_SOUND_BOOLEAN = true
end

if should_summon_boss1 == false and RAIN_SOUND:isPlaying() then
love.audio.stop(RAIN_SOUND)
end


end

if GAME_PlAY == false and RAIN_SOUND:isPlaying() then
love.audio.stop(RAIN_SOUND)
end



--sound for LIGHTNING
if GAME_PlAY == true then


if should_summon_boss1 == true then
LIGHTENING_SOUND_BOOLEAN = true
end	

if LIGHTENING_SOUND_BOOLEAN == true and should_summon_boss1 == true then
LIGHTENING_SOUND:play()
RAIN_SOUND_BOOLEAN = false
end

if LIGHTENING_SOUND_BOOLEAN == false and should_summon_boss1 == true and not LIGHTENING_SOUND:isPlaying() then
LIGHTENING_SOUND_BOOLEAN = true
end

if should_summon_boss1 == false and LIGHTENING_SOUND:isPlaying() then
love.audio.stop(LIGHTENING_SOUND)
end


end

if GAME_PlAY == false and LIGHTENING_SOUND:isPlaying() then
love.audio.stop(LIGHTENING_SOUND)
end




















--music&sounds for boss2 
if GAME_PlAY == true then


if should_summon_boss2 == true then
BOSS2_THEME_MUSIC_BOOLEAN = true
end	

if BOSS2_THEME_MUSIC_BOOLEAN == true and should_summon_boss2 == true then
BOSS2_THEME_MUSIC:play()
BOSS2_THEME_MUSIC_BOOLEAN = false
end

if BOSS2_THEME_MUSIC_BOOLEAN == false and should_summon_boss2 == true and not BOSS2_THEME_MUSIC:isPlaying() then
BOSS2_THEME_MUSIC_BOOLEAN = true
end

if should_summon_boss2 == false and BOSS2_THEME_MUSIC:isPlaying() then
love.audio.stop(BOSS2_THEME_MUSIC)
end


end

if GAME_PlAY == false and BOSS2_THEME_MUSIC:isPlaying() then
love.audio.stop(BOSS2_THEME_MUSIC)
end
--


--boss2 attack
if boss2.isAlive == true and boss2.shouldgethit == false and boss2.SECOND_ATTACK == false and GAME_PlAY == true then
BOSS2_ATTACK_SOUND:play()
end

if not (boss2.isAlive == true and boss2.shouldgethit == false and boss2.SECOND_ATTACK == false) or GAME_PlAY == false then
love.audio.stop(BOSS2_ATTACK_SOUND)
end
--



--boss2 jump
if boss2.isAlive == true and boss2.shouldgethit == false and boss2.SECOND_ATTACK == true and GAME_PlAY == true  then
BOSS2_JUMPING_SOUND:play()
end

if not (boss2.isAlive == true and boss2.shouldgethit == false and boss2.SECOND_ATTACK == true) or GAME_PlAY == false then
love.audio.stop(BOSS2_JUMPING_SOUND)
end
--



--boss2 gethit
if boss2.isAlive == true and boss2.shouldgethit == true and boss2.SECOND_ATTACK == false and GAME_PlAY == true then
BOSS2_GEHIT_SOUND:play()
end

if not (boss2.isAlive == true and boss2.shouldgethit == true and boss2.SECOND_ATTACK == false) or GAME_PlAY == false then
love.audio.stop(BOSS2_GEHIT_SOUND)
end
--


--boss2 die
if BOSS2_DEAD_shouldshow == true then

if BOSS2_DIE_SOUND_PLAYED < 1 then
BOSS2_DIE_SOUND:play()
BOSS2_DIE_SOUND_PLAYED = BOSS2_DIE_SOUND_PLAYED + 1
end

end

if BOSS2_DEAD_shouldshow == false then	
love.audio.stop(BOSS2_DIE_SOUND)
BOSS2_DIE_SOUND_PLAYED = 0
end
--

--boss2 in flames
if BOSS2_DEAD_shouldshow == true then

BOSS2_INFLAME_SOUND:play()

end

if BOSS2_DEAD_shouldshow == false then	

love.audio.stop(BOSS2_INFLAME_SOUND)

end
--



--sound for wind
if GAME_PlAY == true then


if should_summon_boss2 == true then
WIND_SOUND_BOOLEAN = true
end	

if WIND_SOUND_BOOLEAN == true and should_summon_boss2 == true then
WIND_SOUND:play()
WIND_SOUND_BOOLEAN = false
end

if WIND_SOUND_BOOLEAN == false and should_summon_boss2 == true and not WIND_SOUND:isPlaying() then
WIND_SOUND_BOOLEAN = true
end

if should_summon_boss2 == false and WIND_SOUND:isPlaying() then
love.audio.stop(WIND_SOUND)
end


end

if GAME_PlAY == false and WIND_SOUND:isPlaying() then
love.audio.stop(WIND_SOUND)
end
--















--music&sounds for boss3
if GAME_PlAY == true then


if should_summon_boss3 == true then
BOSS3_THEME_MUSIC_BOOLEAN = true
end	

if BOSS3_THEME_MUSIC_BOOLEAN == true and should_summon_boss3 == true then
BOSS3_THEME_MUSIC:play()
BOSS3_THEME_MUSIC_BOOLEAN = false
end

if BOSS3_THEME_MUSIC_BOOLEAN == false and should_summon_boss3 == true and not BOSS3_THEME_MUSIC:isPlaying() then
BOSS3_THEME_MUSIC_BOOLEAN = true
end

if should_summon_boss3 == false and BOSS3_THEME_MUSIC:isPlaying() then
love.audio.stop(BOSS3_THEME_MUSIC)
end


end

if GAME_PlAY == false and BOSS3_THEME_MUSIC:isPlaying() then
love.audio.stop(BOSS3_THEME_MUSIC)
end




--boss3 all sounds

if GAME_PlAY == true then


if boss3.isAlive == true and boss3.changeToLight == true then 

BOSS3_TO_LIGHT_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)


elseif boss3.isAlive == true and boss3.FIRST_ATTACK == true then

if boss3.RANDOM_ATTACK == 1 then

--BOSS3_FIRE
BOSS3_TO_FIRE_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)


elseif boss3.RANDOM_ATTACK == 2 then

--BOSS3_GLAD
BOSS3_TO_GLAD_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 3 then

--BOSS3_GOUL
BOSS3_TO_GIANT_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 4 then

--BOSS3_SKEL
BOSS3_TO_SKEL_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 5 then

--BOSS3_CREEP
BOSS3_TO_CREEP_SOUND:play()
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)


end



elseif boss3.isAlive == true and boss3.SECOND_ATTACK == true then

if boss3.RANDOM_ATTACK == 1 then

--BOSS3_FIRE
BOSS3_TO_FIRE_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)


elseif boss3.RANDOM_ATTACK == 2 then

--BOSS3_GLAD
BOSS3_TO_GLAD_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 3 then

--BOSS3_GOUL
BOSS3_TO_GIANT_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 4 then

--BOSS3_SKEL
BOSS3_TO_SKEL_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 5 then

--BOSS3_CREEP
BOSS3_TO_CREEP_SOUND:play()
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)


end



elseif boss3.isAlive == true and boss3.THIRD_ATTACK == true then 

if boss3.RANDOM_ATTACK == 1 then

--BOSS3_FIRE
BOSS3_TO_FIRE_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)


elseif boss3.RANDOM_ATTACK == 2 then

--BOSS3_GLAD
BOSS3_TO_GLAD_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 3 then

--BOSS3_GOUL
BOSS3_TO_GIANT_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 4 then

--BOSS3_SKEL
BOSS3_TO_SKEL_SOUND:play()
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

elseif boss3.RANDOM_ATTACK == 5 then

--BOSS3_CREEP
BOSS3_TO_CREEP_SOUND:play()
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)


end


elseif boss3.isAlive == true and boss3.shouldgethit == true then 

BOSS3_WAIT_SOUND:play()
love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)

end





else

love.audio.stop(BOSS3_TO_LIGHT_SOUND)
love.audio.stop(BOSS3_TO_CREEP_SOUND)
love.audio.stop(BOSS3_TO_GLAD_SOUND)
love.audio.stop(BOSS3_TO_GIANT_SOUND)
love.audio.stop(BOSS3_TO_SKEL_SOUND)
love.audio.stop(BOSS3_TO_FIRE_SOUND)
love.audio.stop(BOSS3_WAIT_SOUND)

end



--boss3 die
if BOSS3_DEAD_shouldshow == true then

if BOSS3_DIE_SOUND_PLAYED < 1 then
BOSS3_DIE_SOUND:play()
BOSS3_DIE_SOUND_PLAYED = BOSS3_DIE_SOUND_PLAYED + 1
end

end

if BOSS3_DEAD_shouldshow == false then	
love.audio.stop(BOSS3_DIE_SOUND)
BOSS3_DIE_SOUND_PLAYED = 0
end
--

--boss3 in flames
if BOSS3_DEAD_shouldshow == true then

BOSS3_INFLAME_SOUND:play()

end

if BOSS3_DEAD_shouldshow == false then	

love.audio.stop(BOSS3_INFLAME_SOUND)

end
--







--sound for bloodrain
if GAME_PlAY == true then


if should_summon_boss3 == true then
if background1.x <=0 and background1.x > -800/2 * scale_x then	
BLOOD_RAIN_SOUND_BOOLEAN = true
else
BLOOD_RAIN_SOUND_BOOLEAN = false
love.audio.stop(BLOOD_RAIN_SOUND)
end
end	

if BLOOD_RAIN_SOUND_BOOLEAN == true and should_summon_boss3 == true then
BLOOD_RAIN_SOUND:play()
BLOOD_RAIN_SOUND_BOOLEAN = false
end

if BLOOD_RAIN_SOUND_BOOLEAN == false and should_summon_boss3 == true and not BLOOD_RAIN_SOUND:isPlaying() then
if background1.x <=0 and background1.x > -800/2 * scale_x then	
BLOOD_RAIN_SOUND_BOOLEAN = true
else
BLOOD_RAIN_SOUND_BOOLEAN = false
love.audio.stop(BLOOD_RAIN_SOUND)
end
end

if should_summon_boss3 == false and BLOOD_RAIN_SOUND:isPlaying() then
love.audio.stop(BLOOD_RAIN_SOUND)
end


end

if GAME_PlAY == false and BLOOD_RAIN_SOUND:isPlaying() then
love.audio.stop(BLOOD_RAIN_SOUND)
end



--sound for water
if GAME_PlAY == true then


if should_summon_boss3 == true or (should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == false and boss3_finished == true) then 
if background2.x <=0 and background2.x > -800/2 * scale_x then	
WATER_SOUND_BOOLEAN = true
else
WATER_SOUND_BOOLEAN = false
love.audio.stop(WATER_SOUND)
end
end	

if WATER_SOUND_BOOLEAN == true and should_summon_boss3 == true or (should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == false and boss3_finished == true) then
WATER_SOUND:play()
WATER_SOUND_BOOLEAN = false
end

if WATER_SOUND_BOOLEAN == false and should_summon_boss3 == true or (should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == false and boss3_finished == true) and not WATER_SOUND:isPlaying() then
if background2.x <=0 and background2.x > -800/2 * scale_x then	
WATER_SOUND_BOOLEAN = true
else
WATER_SOUND_BOOLEAN = false
love.audio.stop(WATER_SOUND)
end
end

if not(should_summon_boss3 == true or (should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == false and boss3_finished == true)) and WATER_SOUND:isPlaying() then
love.audio.stop(WATER_SOUND)
end


end

if GAME_PlAY == false and WATER_SOUND:isPlaying() then
love.audio.stop(WATER_SOUND)
end















--music for CONGRATULATIONS
if GAME_PlAY == true then


if CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then
CONGRATULATIONS_SOUND_BOOLEAN = true
end	

if CONGRATULATIONS_SOUND_BOOLEAN == true and CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then
CONGRATULATIONS_SOUND:play()
CONGRATULATIONS_SOUND_BOOLEAN = false
end

if CONGRATULATIONS_SOUND_BOOLEAN == false and CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false and not CONGRATULATIONS_SOUND:isPlaying() then
CONGRATULATIONS_SOUND_BOOLEAN = true
end

if not(CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false) and CONGRATULATIONS_SOUND:isPlaying() then
love.audio.stop(CONGRATULATIONS_SOUND)
end


end

if GAME_PlAY == false and CONGRATULATIONS_SOUND:isPlaying() then
love.audio.stop(CONGRATULATIONS_SOUND)
end


--voice for CONGRATULATIONS
if GAME_PlAY == true then


if CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then
CONGRATULATIONS_VOICE_SOUND_BOOLEAN = true
end	

if CONGRATULATIONS_VOICE_SOUND_BOOLEAN == true and CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then
if CONGRATULATIONS_VOICE_SOUND_PLAYED < 1 then
CONGRATULATIONS_VOICE_SOUND:play()
CONGRATULATIONS_VOICE_SOUND_PLAYED = CONGRATULATIONS_VOICE_SOUND_PLAYED + 1
end

end


if not(CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false) then
CONGRATULATIONS_VOICE_SOUND_BOOLEAN = false
CONGRATULATIONS_VOICE_SOUND_PLAYED = 0
love.audio.stop(CONGRATULATIONS_VOICE_SOUND)
end

end

if GAME_PlAY == false and CONGRATULATIONS_VOICE_SOUND:isPlaying() then
love.audio.stop(CONGRATULATIONS_VOICE_SOUND)
end








--sounds for crows
if GAME_PlAY == true then


if enemys[1].isAlive == true or enemys[2].isAlive == true or boss.helper.isAlive == true then
CROWS_SOUND_BOOLEAN = true
end	

if CROWS_SOUND_BOOLEAN == true and (enemys[1].isAlive == true or enemys[2].isAlive == true or boss.helper.isAlive == true) then
CROWS_SOUND:play()
CROWS_SOUND_BOOLEAN = false
end

if CROWS_SOUND_BOOLEAN == false and (enemys[1].isAlive == true or enemys[2].isAlive == true or boss.helper.isAlive == true) and not CROWS_SOUND:isPlaying() then
CROWS_SOUND_BOOLEAN = true
end

if (enemys[1].isAlive == false and enemys[2].isAlive == false and boss.helper.isAlive == false) and CROWS_SOUND:isPlaying() then
love.audio.stop(CROWS_SOUND)
end


end

if GAME_PlAY == false and CROWS_SOUND:isPlaying() then
love.audio.stop(CROWS_SOUND)
end





--sound for enemy1 get hit 
if enemys[1].hit_effect_start == true then

if ENEMY1_GET_HIT_SOUND_PLAYED < 1 then

if GAME_PlAY == true then
ENEMY1_GET_HIT_SOUND:play()
end

ENEMY1_GET_HIT_SOUND_PLAYED = ENEMY1_GET_HIT_SOUND_PLAYED + 1
end

end

if enemys[1].hit_effect_start == false then

ENEMY1_GET_HIT_SOUND_PLAYED = 0
love.audio.stop(ENEMY1_GET_HIT_SOUND)

end
--


--sound for enemy2 get hit 
if enemys[2].hit_effect_start == true then

if ENEMY2_GET_HIT_SOUND_PLAYED < 1 then

if GAME_PlAY == true then
ENEMY2_GET_HIT_SOUND:play()
end

ENEMY2_GET_HIT_SOUND_PLAYED = ENEMY2_GET_HIT_SOUND_PLAYED + 1
end

end

if enemys[2].hit_effect_start == false then

ENEMY2_GET_HIT_SOUND_PLAYED = 0
love.audio.stop(ENEMY2_GET_HIT_SOUND)

end
--


--sound for boss.helper get hit 
if boss.helper.hit_effect_start == true then

if BOSS1_HELPER_GET_HIT_SOUND_PLAYED < 1 then

if GAME_PlAY == true then
BOSS1_HELPER_GET_HIT_SOUND:play()
end

BOSS1_HELPER_GET_HIT_SOUND_PLAYED = BOSS1_HELPER_GET_HIT_SOUND_PLAYED + 1
end

end

if boss.helper.hit_effect_start == false then

BOSS1_HELPER_GET_HIT_SOUND_PLAYED = 0
love.audio.stop(BOSS1_HELPER_GET_HIT_SOUND)

end
--





--sound for enemy1 die 
if enemys[1].X_TIME == true then

if ENEMY1_DIE_SOUND_PLAYED < 1 then

if GAME_PlAY == true then	
ENEMY1_DIE_SOUND:play()
end

ENEMY1_DIE_SOUND_PLAYED = ENEMY1_DIE_SOUND_PLAYED + 1
end

end

if enemys[1].X_TIME == false then

ENEMY1_DIE_SOUND_PLAYED = 0
love.audio.stop(ENEMY1_DIE_SOUND)

end
--


--sound for enemy2 die 
if enemys[2].X_TIME == true then

if ENEMY2_DIE_SOUND_PLAYED < 1 then

if GAME_PlAY == true then
ENEMY2_DIE_SOUND:play()
end

ENEMY2_DIE_SOUND_PLAYED = ENEMY2_DIE_SOUND_PLAYED + 1
end

end

if enemys[2].X_TIME == false then

ENEMY2_DIE_SOUND_PLAYED = 0
love.audio.stop(ENEMY2_DIE_SOUND)

end
--


--sound for boss.helper die
if boss.helper.X_TIME == true then

if BOSS1_HELPER_DIE_SOUND_PLAYED < 1 then

if GAME_PlAY == true then
BOSS1_HELPER_DIE_SOUND:play()
end

BOSS1_HELPER_DIE_SOUND_PLAYED = BOSS1_HELPER_DIE_SOUND_PLAYED + 1
end

end

if boss.helper.X_TIME == false then

BOSS1_HELPER_DIE_SOUND_PLAYED = 0
love.audio.stop(BOSS1_HELPER_DIE_SOUND)

end
--














--SOUNDS FOR ROBOT:::::

--sounds for guns :

--light gun
if shotFire == true and (should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false and 
PASSING_FINISHeD_GAME == 0 and
(enemys[1].isAlive == true or
enemys[2].isAlive == true ) or amuzeshi_gameplay == true) then

if LIGHT_GUN_SOUND_PLAYED < 1 then
LIGHT_GUN_SOUND:play()


LIGHT_GUN_SOUND_PLAYED = LIGHT_GUN_SOUND_PLAYED + 1
end

end

if shotFire == false and (scoore <= 5 or amuzeshi_gameplay == true) then
LIGHT_GUN_SOUND_PLAYED = 0
love.audio.stop(LIGHT_GUN_SOUND)
end
--


--hand gun
if shotFire == true and not((should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false) and 
enemys[1].isAlive == true or
enemys[2].isAlive == true ) and handle_SHOT_GUN == false and handle_HEAVY_GUN == false and handle_LAZER_GUN == false and not (handle_HEAVY_GUN == true) and amuzeshi_gameplay == false then
if HAND_GUN_SOUND_PLAYED < 1 then
HAND_GUN_SOUND:play()


HAND_GUN_SOUND_PLAYED = HAND_GUN_SOUND_PLAYED + 1
end

end

if shotFire == false and scoore > 5 and scoore <= 27  and handle_SHOT_GUN == false  then
HAND_GUN_SOUND_PLAYED = 0
love.audio.stop(HAND_GUN_SOUND)
end
--



--shot gun
if shotFire == true and handle_SHOT_GUN == true then

if SHOT_GUN_SOUND_PLAYED < 1 then
SHOT_GUN_SOUND:play()


SHOT_GUN_SOUND_PLAYED = SHOT_GUN_SOUND_PLAYED + 1
end

end

if shotFire == false and handle_SHOT_GUN == true then
SHOT_GUN_SOUND_PLAYED = 0
love.audio.stop(SHOT_GUN_SOUND)
end
--

--heavy gun
if shotFire == true and handle_HEAVY_GUN == true then

if HEAVY_GUN_SOUND_PLAYED < 1 then
HEAVY_GUN_SOUND:play()


HEAVY_GUN_SOUND_PLAYED = HEAVY_GUN_SOUND_PLAYED + 1
end

end

if shotFire == false and handle_HEAVY_GUN == true then
HEAVY_GUN_SOUND_PLAYED = 0
love.audio.stop(HEAVY_GUN_SOUND)
end
--

--lazer gun
if shotFire == true and handle_LAZER_GUN == true then

if LAZER_GUN_SOUND_PLAYED < 1 then
LAZER_GUN_SOUND:play()


LAZER_GUN_SOUND_PLAYED = LAZER_GUN_SOUND_PLAYED + 1
end

end

if shotFire == false and handle_LAZER_GUN == true then
LAZER_GUN_SOUND_PLAYED = 0
love.audio.stop(LAZER_GUN_SOUND)
end
--



--jumping
if jumping == true and GAME_PlAY == true then

if JUMP_SOUND_PLAYED < 1 then
JUMP_SOUND:play()
JUMP_SOUND_PLAYED = JUMP_SOUND_PLAYED + 1
end

end

if jumping == false then
JUMP_SOUND_PLAYED = 0
love.audio.stop(JUMP_SOUND)
end
--




--get hit in player get hit and player get tremble -> <-:::: function.lua



--sound for background shaking 
if GAME_PlAY == true and background2.y ~= 0 then
EARTHQ:play()

love.system.vibrate( 0.4 )

end

if GAME_PlAY == false then
love.audio.stop(EARTHQ)
end



else

for i = 1 , #list_of_audio_sources do
love.audio.stop(list_of_audio_sources[i])
end

end





end	--pause



--code for sound && music :: ends here


else

if studio_TIME <= 0 then
studio_bool = false
end

if play_music == 1 and gameover_explode_bool == false then

studio_music:play()

end

studio_TIME = studio_TIME - 1


end--studio_bool





if play_music == 1 and gameover_explode_bool == false then

--music for GAMEOVER&GAMESTART
if GAME_PlAY == false then
GAMEOVER_MUSIC_BOOLEAN = true
end

if GAMEOVER_MUSIC_BOOLEAN == true and GAME_PlAY == false then
GAMEOVER_MUSIC:play()
GAMEOVER_MUSIC_BOOLEAN = false
end

if GAMEOVER_MUSIC_BOOLEAN == false and GAME_PlAY == false and not GAMEOVER_MUSIC:isPlaying() then
GAMEOVER_MUSIC_BOOLEAN = true
end

if GAME_PlAY == true and GAMEOVER_MUSIC:isPlaying() then
love.audio.stop(GAMEOVER_MUSIC)
end

if studio_bool == true and GAMEOVER_MUSIC:isPlaying() then
love.audio.stop(GAMEOVER_MUSIC)
end	

else

love.audio.stop(GAMEOVER_MUSIC)	

end

if play_music == 0 then
love.audio.stop(menu_sound)
end







elseif loader.should_initial() then

loader.loading__all()

elseif loader.should_set() then

first_set()


end -- if should_start_the_game


end--end love.update() function 










function love.touchreleased( id, x, y, pressure )

if loader.should_start_the_game() then

if after_lost_choose == false then


if amuzeshi_gameplay == false and GAME_PlAY == false then

if x > 338/2 * scale_x and x < 493/2 * scale_x and y > 135/2 * scale_y and y < 210/2 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then


set()
GAME_PlAY = true



end

end


if x > 338/2 * scale_x and x < 493/2 * scale_x and y > 235/2 * scale_y and y < 310/2 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then


amuzeshi_gameplay = true
set() -- set amuzeshi ehtmalan beshe
GAME_PlAY = true


end

end


if x > 338/2 * scale_x and x < 493/2 * scale_x and y > 342/2 * scale_y and y < 417/2 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then


menu = SCORE_IMAGE
menu_pad = menu_pad_bazgasht


end

end

if x > 338/2 * scale_x and x < 493/2 * scale_x and y > 445/2 * scale_y and y < 520/2 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then



love.event.quit()




end

end

if x > 0 and x < 135/2 * scale_x and y > 0 and y < ((530/2)/3.3) * scale_y then

if (menu == SCORE_IMAGE or menu == amuzesh) and menu_pad == menu_pad_bazgasht then



menu_pad = menu_pad_asli 
menu_animation()



end

end


if x > 37.8 * scale_x and x < 117.8 * scale_x and y > 125.8 * scale_y and y < 170.8 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then

menu_pad = connection


end



end






if x > 160 * scale_x and x < 266 * scale_x and y > 65.5 * scale_y and y < 115.5 * scale_y then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == connection then


-- be safheye bazi dar myket boro
love.system.openURL("myket://details?id=com.undeniablessohrab.trylqgame")

end


end



if x > 138 * scale_x and x < 292 * scale_x and y > 135 * scale_y and y < 185 * scale_y then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == connection then


-- be safheye ersal nazarat dar myket boro
love.system.openURL("myket://comment?id=com.undeniablessohrab.trylqgame")



end


end



if x > 115 * scale_x and x < 320 * scale_x and y > 210 * scale_y and y < 260 * scale_y then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == connection then


-- be safheye ersal email boro
love.system.openURL("mailto:00sohrabiranpak00@gmail.com")
--""

end


end



if x > 0 and x < 62.5 * scale_x and y > 0 and y < 80 * scale_y then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == connection then


menu_pad = menu_pad_asli


end


end




--new for change_clothes:
if x > 292.2 * scale_x and x < 372.2 * scale_x and y > 125.8 * scale_y and y < 170.8 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then

menu_pad = change_clothes

player.img = love.graphics.newImage('character_1_1.png')

time_to_wait_helper_bool = true

end



end



--new for change_clothes:previous
if x > 15*scale_x and x < 70 * scale_x and y > 120*scale_y and y < 200 * scale_y then

if is_base_menu() and menu_pad == change_clothes then

if nooooeeee >= 1 then

nooooeeee = nooooeeee - 1

end

if nooooeeee_2 >= 1 then

nooooeeee_2 = nooooeeee_2 - 1

end


end



end



--new for change_clothes:next
if x > 330 * scale_x and x < 385 * scale_x and y > 120 * scale_y and y < 200 * scale_y then

if is_base_menu() and menu_pad == change_clothes and time_to_wait_helper_bool == false then

if nooooeeee <= 9 then

nooooeeee = nooooeeee + 1

end

if nooooeeee_2 <= 9 then

nooooeeee_2 = nooooeeee_2 + 1

end

end



end


--new for change_clothes:save
if x > 100 * scale_x and x < 300 * scale_x and y > 205 * scale_y and y < 275 * scale_y then

if is_base_menu() and menu_pad == change_clothes then

clothes_all.hat_id = nooooeeee
clothes_all.set_hat_id(clothes_all.hat_id)
clothes_all.set_hat()
clothes_all.belt_id = nooooeeee_2
clothes_all.set_belt_id(clothes_all.belt_id)
clothes_all.set_belt()

end



end


--new for change_clothes:back_to_menu
if x > 0 and x < 62.5 * scale_x and y > 0 and y < 80 * scale_y then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == change_clothes then


menu_pad = menu_pad_asli
nooooeeee = clothes_all.hat_id
nooooeeee_2 = clothes_all.belt_id

end


end







end


else-- after_lost_choose == true



if x > 0 and x < 380/2 * scale_x and y > 0 and y < 530/2 * scale_y then -- for restart

after_lost_choose = false
GAME_PlAY = true
set()




bullets = {}


boss.helper.EBullets = {}


enemys[1].EBullets = {} 


enemys[2].EBullets = {} 


boss.BBullets = {}


boss2.BBullets = {}


boss3.BBullets = {}


boss3.BBullets1 = {}


boss3.BBullets2 = {}



if play_img == play_m then

set_volume_zero()

elseif play_img == play_p then

set_volume()	

end


if not love.filesystem.exists("save.txt") then
jupiter = require "jupiter"
data = {_fileName = "save.txt", scoore}
success = jupiter.save(data)
else


jupiter = require "jupiter"
newData = jupiter.load("save.txt")
newData[#newData+1] = scoore

function zsort(object1, object2)
    return object1 > object2
end

table.sort( newData, zsort )

if #newData > 9 then
for i = 10 , #newData do	

table.remove(newData,i)

end
end

table.sort( newData, zsort )


success1 = jupiter.save(newData)


end 


--end




end


if x > 430/2 * scale_x and x < 800/2 * scale_x and y > 0 and y < 530/2 * scale_y then -- for  menu

love.audio.stop()	
amuzeshi_gameplay = false
SCORE_SAVE_BOOL = true
after_lost_choose = false
GAME_PlAY = false


end


end -- after_lost_choose == false


end-- if loader.should_start_the_game() then

end





function love.touchpressed( id, x, y, pressure )

if loader.should_start_the_game() == true then

if after_lost_choose == false then


--function love.mousepressed(x, y, button, istouch)
--function love.mousereleased(x, y, button, istouch)
if amuzeshi_gameplay == false then



if x > 0 and x < 80/2 * scale_x and y > 5/2 * scale_y and y < 93/2 * scale_y then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

gamepaused = not gamepaused

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 103/2 * scale_y and y < 191/2 * scale_y then
if GAME_PlAY == true and studio_bool == false and menu_pad ~= change_clothes and after_lost_choose == false then

if gameover_explode_bool == false then

if gamepaused == true then

if play_img == play_p then

play_img = play_m
play_img_a = play_m_a

set_volume_zero()

elseif play_img == play_m then

play_img = play_p	
play_img_a = play_p_a

set_volume()

if play_music == 0 then
play_music = 1
end

end

end

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 204/2 * scale_y and y < 292/2 * scale_y then
if GAME_PlAY == true and studio_bool == false and menu_pad ~= change_clothes and after_lost_choose == false then

if gameover_explode_bool == false then

if gamepaused == true then

set()




bullets = {}


boss.helper.EBullets = {}


enemys[1].EBullets = {} 


enemys[2].EBullets = {} 


boss.BBullets = {}


boss2.BBullets = {}


boss3.BBullets = {}


boss3.BBullets1 = {}


boss3.BBullets2 = {}





if play_img == play_m then

set_volume_zero()

elseif play_img == play_p then

set_volume()	

end




--end

if not love.filesystem.exists("save.txt") then
jupiter = require "jupiter"
data = {_fileName = "save.txt", scoore}
success = jupiter.save(data)
else


jupiter = require "jupiter"
newData = jupiter.load("save.txt")
newData[#newData+1] = scoore

function zsort(object1, object2)
    return object1 > object2
end

table.sort( newData, zsort )

if #newData > 9 then
for i = 10 , #newData do	

table.remove(newData,i)

end
end

table.sort( newData, zsort )

success1 = jupiter.save(newData)


end 







GAME_PlAY = true



end

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 302/2 * scale_y and y < 390/2 * scale_y then
if GAME_PlAY == true and studio_bool == false and menu_pad ~= change_clothes and after_lost_choose == false then

if gameover_explode_bool == false then

if gamepaused == true then
SCORE_SAVE_BOOL = true
love.audio.stop()	
GAME_PlAY = false


end

end

end
end




end --amuzeshi_gameplay == false



if amuzeshi_gameplay == true then








if x > 0 and x < 80/2 * scale_x and y > 5/2 * scale_y and y < 93/2 * scale_y then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

gamepaused = not gamepaused

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 103/2 * scale_y and y < 191/2 * scale_y then
if GAME_PlAY == true and studio_bool == false and menu_pad ~= change_clothes and after_lost_choose == false then

if gameover_explode_bool == false then

if gamepaused == true then

if play_img_a == play_p_a then

play_img_a = play_m_a
play_img = play_m

set_volume_zero()

elseif play_img_a == play_m_a then

play_img_a = play_p_a	
play_img = play_p

set_volume()

if play_music == 0 then
play_music = 1
end


end

end

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 204/2 * scale_y and y < 292/2 * scale_y then
if GAME_PlAY == true and studio_bool == false and menu_pad ~= change_clothes and after_lost_choose == false then

if gameover_explode_bool == false then

if gamepaused == true then


love.audio.stop()	
amuzeshi_gameplay = false
SCORE_SAVE_BOOL = false
GAME_PlAY = false


end

end

end
end





end --amuzeshi_gameplay == true





end -- after_lost_choose   ==   false


end-- if loader.should_start_the_game() == true then


end





--[[



--function love.mousepressed(x, y, button, istouch)
function love.mousereleased(x, y, button, istouch)



if loader.should_start_the_game() then


if studio_bool == false then	


if GAME_PlAY == false then



if x > 135/2 * scale_x and x < 395/2 * scale_x and y > 0 * scale_y and y < 135/2 * scale_y  then

if menu_pad ~= menu_pad_bazgasht and menu_pad ~= change_clothes then

play_music = 1

jupiter = require "jupiter"
newData = jupiter.load("music.txt")
newData[1] = 1
s = jupiter.save(newData)

set_volume()	

end	

end

if x > 405/2 * scale_x and x < 665/2 * scale_x and y > 0 * scale_y and y < 135/2 * scale_y  then

if menu_pad ~= menu_pad_bazgasht and menu_pad ~= change_clothes then

play_music = 0

jupiter = require "jupiter"
newData = jupiter.load("music.txt")
newData[1] = 0
s = jupiter.save(newData)

end

end 



end


end













if after_lost_choose == false then


if amuzeshi_gameplay == false and GAME_PlAY == false  then

if x > 338/2 * scale_x and x < 493/2 * scale_x and y > 135/2 * scale_y and y < 210/2 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then


set()
GAME_PlAY = true



end

end


if x > 338/2 * scale_x and x < 493/2 * scale_x and y > 235/2 * scale_y and y < 310/2 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then


amuzeshi_gameplay = true
set() -- set amuzeshi ehtmalan beshe
GAME_PlAY = true


end

end


if x > 338/2 * scale_x and x < 493/2 * scale_x and y > 342/2 * scale_y and y < 417/2 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then


menu = SCORE_IMAGE
menu_pad = menu_pad_bazgasht


end

end

if x > 338/2 * scale_x and x < 493/2 * scale_x and y > 445/2 * scale_y and y < 520/2 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then



love.event.quit()




end

end

if x > 0 and x < 135/2 * scale_x and y > 0 and y < ((530/2)/3.3) * scale_y then

if (menu == SCORE_IMAGE or menu == amuzesh) and menu_pad == menu_pad_bazgasht then



menu_pad = menu_pad_asli 
menu_animation()



end

end



if x > 37.8 * scale_x and x < 117.8 * scale_x and y > 125.8 * scale_y and y < 170.8 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then

menu_pad = connection


end



end





if x > 160 * scale_x and x < 266 * scale_x and y > 65.5 * scale_y and y < 115.5 * scale_y and button == 1 then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == connection then


-- be safheye bazi dar myket boro
love.system.openURL("http://myket://details?id=com.undeniablessohrab.trylqgame")


end


end



if x > 138 * scale_x and x < 292 * scale_x and y > 135 * scale_y and y < 185 * scale_y and button == 1 then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == connection then


-- be safheye ersal nazarat dar myket boro
love.system.openURL("http://myket://comment?id=com.undeniablessohrab.trylqgame")


end


end



if x > 115 * scale_x and x < 320 * scale_x and y > 210 * scale_y and y < 260 * scale_y and button == 1 then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == connection then


-- be safheye ersal email boro
love.system.openURL("https://mail.google.com/mail/?view=cm&fs=1&to=00sohrabiranpak00@gmail.com")


end


end



if x > 0 and x < 62.5 * scale_x and y > 0 and y < 80 * scale_y and button == 1 then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == connection then


menu_pad = menu_pad_asli


end


end





--new for change_clothes:
if x > 292.2 * scale_x and x < 372.2 * scale_x and y > 125.8 * scale_y and y < 170.8 * scale_y then

if is_base_menu() and menu_pad == menu_pad_asli then

menu_pad = change_clothes

time_to_wait_helper_bool = true

end



end



--new for change_clothes:previous
if x > 15*scale_x and x < 70 * scale_x and y > 120*scale_y and y < 200 * scale_y then

if is_base_menu() and menu_pad == change_clothes then

if nooooeeee >= 1 then

nooooeeee = nooooeeee - 1

end


end



end



--new for change_clothes:next
if x > 330 * scale_x and x < 385 * scale_x and y > 120 * scale_y and y < 200 * scale_y then

if is_base_menu() and menu_pad == change_clothes and time_to_wait_helper_bool == false then

if nooooeeee <= 9 then

nooooeeee = nooooeeee + 1

end


end



end


--new for change_clothes:save
if x > 100 * scale_x and x < 300 * scale_x and y > 205 * scale_y and y < 275 * scale_y then

if is_base_menu() and menu_pad == change_clothes then

clothes_all.hat_id = nooooeeee
clothes_all.set_hat_id(clothes_all.hat_id)
clothes_all.set_hat()

end



end


--new for change_clothes:back_to_menu
if x > 0 and x < 62.5 * scale_x and y > 0 and y < 80 * scale_y then

if GAME_PlAY == false and studio_bool == false and is_base_menu() and menu_pad == change_clothes then


menu_pad = menu_pad_asli
nooooeeee = clothes_all.hat_id

end


end









end



else-- after_lost_choose == true



if x > 0 and x < 380/2 * scale_x and y > 0 and y < 530/2 * scale_y then -- for restart

after_lost_choose = false
GAME_PlAY = true
set()




bullets = {}


boss.helper.EBullets = {}


enemys[1].EBullets = {} 


enemys[2].EBullets = {} 


boss.BBullets = {}


boss2.BBullets = {}


boss3.BBullets = {}


boss3.BBullets1 = {}


boss3.BBullets2 = {}



if play_img == play_m then

set_volume_zero()

elseif play_img == play_p then

set_volume()	

end


if not love.filesystem.exists("save.txt") then
jupiter = require "jupiter"
data = {_fileName = "save.txt", scoore}
success = jupiter.save(data)
else


jupiter = require "jupiter"
newData = jupiter.load("save.txt")
newData[#newData+1] = scoore

function zsort(object1, object2)
    return object1 > object2
end

table.sort( newData, zsort )

if #newData > 9 then
for i = 10 , #newData do	

table.remove(newData,i)

end
end

success1 = jupiter.save(newData)


end 


--end





end


if x > 430/2 * scale_x and x < 800/2 * scale_x and y > 0 and y < 530/2 * scale_y then -- for  menu

love.audio.stop()	
amuzeshi_gameplay = false
SCORE_SAVE_BOOL = true
after_lost_choose = false
GAME_PlAY = false

end



end -- after_lost_choose   ==  false


end -- if loader.should_start_the_game() then

end






function love.mousepressed(x, y, button, istouch)


if loader.should_start_the_game() then 


if after_lost_choose == false then

--function love.mousereleased(x, y, button, istouch)
if amuzeshi_gameplay == false then




if x > 0 and x < 80/2 * scale_x and y > 5/2 * scale_y and y < 93/2 * scale_y  and button == 1 then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

gamepaused = not gamepaused

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 103/2 * scale_y and y < 191/2 * scale_y  and button == 1 then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

if gamepaused == true then

if play_img == play_p then

play_img = play_m
play_img_a = play_m_a

set_volume_zero()

elseif play_img == play_m then

play_img = play_p	
play_img_a = play_p_a

set_volume()

if play_music == 0 then
play_music = 1
end

end

end

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 204/2 * scale_y and y < 292/2 * scale_y  and button == 1 then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

if gamepaused == true then

set()




bullets = {}


boss.helper.EBullets = {}


enemys[1].EBullets = {} 


enemys[2].EBullets = {} 


boss.BBullets = {}


boss2.BBullets = {}


boss3.BBullets = {}




if play_img == play_m then

set_volume_zero()

elseif play_img == play_p then

set_volume()	

end


if not love.filesystem.exists("save.txt") then
jupiter = require "jupiter"
data = {_fileName = "save.txt", scoore}
success = jupiter.save(data)
else


jupiter = require "jupiter"
newData = jupiter.load("save.txt")
newData[#newData+1] = scoore

function zsort(object1, object2)
    return object1 > object2
end

table.sort( newData, zsort )

if #newData > 9 then
for i = 10 , #newData do	

table.remove(newData,i)

end
end

success1 = jupiter.save(newData)


end 


--end


GAME_PlAY = true



end

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 302/2 * scale_y and y < 390/2 * scale_y  and button == 1 then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

if gamepaused == true then
SCORE_SAVE_BOOL = true
love.audio.stop()	
GAME_PlAY = false


end

end

end
end





-- for testing scores   ::        begin


if x > touchX_shoot and x < touchX_shoot + 400/2 * scale_x and y > touchY_shoot and y < touchY_shoot + 530/2 * scale_y then
    
if canshoot == true and AMMO > 0 then --and not (x > touchX_left and x < touchX_left + 53 * scale_x and y > touchY_left and y < touchY_left + 57 * scale_y or x > touchX_down and x < touchX_down + 53 * scale_x and y > touchY_down and y < touchY_down + 57 * scale_y) then

shotFire = true
ducking = false
movingLeft = false

--light gun
if should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false and 
PASSING_FINISHeD_GAME == 0 and
(enemys[1].isAlive == true or
enemys[2].isAlive == true ) or amuzeshi_gameplay == true then
newbullet = {x = player.x + 125/2 * scale_x  , y = player.y + 16/2 * scale_y , visible = true , img = bulletImg}   
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end

--hand gun
if not((should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false) and 
enemys[1].isAlive == true or
enemys[2].isAlive == true ) and handle_SHOT_GUN == false and handle_HEAVY_GUN == false and handle_LAZER_GUN == false and not (handle_HEAVY_GUN == true) and amuzeshi_gameplay == false then
newbullet = {x = player.x + 135/2 * scale_x  , y = player.y + 16/2 * scale_y , visible = true , img = bulletImg}   
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end	

--shot gun
if handle_SHOT_GUN == true and AMMO >=2 and amuzeshi_gameplay == false then
newbullet = {x = player.x + 90/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_SHOT_GUN}
newbullet1 = {x = player.x + 150/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_SHOT_GUN}
table.insert(bullets,newbullet)
table.insert(bullets,newbullet1)
--Code for AMMO

AMMO = AMMO - 2

--Code for AMMO
shootTime = 0
end

--heavy gun
if handle_HEAVY_GUN == true and amuzeshi_gameplay == false then
newbullet = {x = player.x + 103/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_HEAVY_GUN}	
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end

--lazer gun
if handle_LAZER_GUN == true and AMMO >=5 and amuzeshi_gameplay == false then
newbullet = {x = player.x + 108/2 * scale_x  , y = player.y + 34/2 * scale_y , visible = true , img = bullet_LAZER_GUN}	
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 5

--Code for AMMO
shootTime = 0


end

end
end


-- for testing scores  ::     end



end --amuzeshi_gameplay == false



if amuzeshi_gameplay == true then








if x > 0 and x < 80/2 * scale_x and y > 5/2 * scale_y and y < 93/2 * scale_y  and button == 1 then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

gamepaused = not gamepaused

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 103/2 * scale_y and y < 191/2 * scale_y  and button == 1 then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

if gamepaused == true then

if play_img_a == play_p_a then

play_img_a = play_m_a
play_img = play_m

set_volume_zero()

elseif play_img_a == play_m_a then

play_img_a = play_p_a	
play_img = play_p

set_volume()

if play_music == 0 then
play_music = 1
end

end

end

end

end
end


if x > 0 and x < 80/2 * scale_x and y > 204/2 * scale_y and y < 292/2 * scale_y  and button == 1 then
if GAME_PlAY == true and studio_bool == false then

if gameover_explode_bool == false then

if gamepaused == true then


love.audio.stop()	
amuzeshi_gameplay = false
SCORE_SAVE_BOOL = false
GAME_PlAY = false


end

end

end
end


if x > touchX_shoot and x < touchX_shoot + 400/2 * scale_x and y > touchY_shoot and y < touchY_shoot + 530/2 * scale_y then
    
if canshoot == true and AMMO > 0 then --and not (x > touchX_left and x < touchX_left + 53 * scale_x and y > touchY_left and y < touchY_left + 57 * scale_y or x > touchX_down and x < touchX_down + 53 * scale_x and y > touchY_down and y < touchY_down + 57 * scale_y) then

shotFire = true
ducking = false
movingLeft = false


--light gun
if should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false and 
PASSING_FINISHeD_GAME == 0 and
(enemys[1].isAlive == true or
enemys[2].isAlive == true ) or amuzeshi_gameplay == true then
newbullet = {x = player.x + 125/2 * scale_x  , y = player.y + 16/2 * scale_y , visible = true , img = bulletImg}   
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end

--hand gun
if not((should_summon_boss1 == true and
should_summon_boss2 == false and
should_summon_boss3 == false and
boss1_finished == false and
boss2_finished == false and
boss3_finished == false) and 
enemys[1].isAlive == true or
enemys[2].isAlive == true ) and handle_SHOT_GUN == false and handle_HEAVY_GUN == false and handle_LAZER_GUN == false and not (handle_HEAVY_GUN == true) and amuzeshi_gameplay == false then
newbullet = {x = player.x + 135/2 * scale_x  , y = player.y + 16/2 * scale_y , visible = true , img = bulletImg}   
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end	

--shot gun
if handle_SHOT_GUN == true and AMMO >=2 and amuzeshi_gameplay == false then
newbullet = {x = player.x + 90/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_SHOT_GUN}
newbullet1 = {x = player.x + 150/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_SHOT_GUN}
table.insert(bullets,newbullet)
table.insert(bullets,newbullet1)
--Code for AMMO

AMMO = AMMO - 2

--Code for AMMO
shootTime = 0
end

--heavy gun
if handle_HEAVY_GUN == true and amuzeshi_gameplay == false then
newbullet = {x = player.x + 103/2 * scale_x  , y = player.y + 31/2 * scale_y , visible = true , img = bullet_HEAVY_GUN}	
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 1

--Code for AMMO
shootTime = 0
end

--lazer gun
if handle_LAZER_GUN == true and AMMO >=5 and amuzeshi_gameplay == false then
newbullet = {x = player.x + 108/2 * scale_x  , y = player.y + 34/2 * scale_y , visible = true , img = bullet_LAZER_GUN}	
table.insert(bullets,1,newbullet)
--Code for AMMO

AMMO = AMMO - 5

--Code for AMMO
shootTime = 0


end

end
end











end --amuzeshi_gameplay == true







end -- after_lost_choose  ==  false



end -- if loader.should_start_the_game() then 


end

--function love.touchreleased( id, x, y, pressure )


--]]



















function first_set()-- should move to main.lua

if loader.should_set() then

A_background = loader.A_background
AA_background = loader.AA_background
after_lost_choose_img = loader.after_lost_choose_img

amuzeshi_gameplay = false
after_lost_choose = false
gamepaused = false


gameover_explode_bool = false
gameover_explode_frame = 1
gameover_explode_framespeed = 0

gameover_explode = loader.gameover_explode

gameover_explode_to_show = gameover_explode[1]




--amuzeshi_gameplay == false
play_m = loader.play_m
play_p = loader.play_p
--end

--amuzeshi_gameplay == true
play_m_a = loader.play_m_a
play_p_a = loader.play_p_a
--end

play_img = play_p

play_img_a = play_p_a




stop_img = loader.stop_img

--ANIMATION FOR HAND HELP

hand_help = loader.hand_help
hand = hand_help[1]
hand_help_frame = 1
hand_help_framespeed = 0



--animation for menu
menu_anim = loader.menu_anim
menu_anim_frame = 1
menu_anim_framespeed = 0
menu = menu_anim[1]

--menu_pad:
connection = loader.connection
menu_pad_asli = loader.menu_pad_asli
menu_pad_bazgasht = loader.menu_pad_bazgasht


menu_pad = menu_pad_asli


timer_pad = 0

--studio at the begining::

studio_bool = true

studio_pic = loader.studio_pic
studio_music = loader.studio_music
studio_music:setVolume(1.0)
studio_TIME = 200



--bool to play or mute
play_music = 1 

if not love.filesystem.exists("music.txt") then

jupiter = require "jupiter"
data = {_fileName = "music.txt", 1}
success = jupiter.save(data)

else


jupiter = require "jupiter"
newData = jupiter.load("music.txt")
play_music = newData[1]
print(play_music)


end



--image for SCORES
SCORE_IMAGE = loader.SCORE_IMAGE

--image for amuzesh
amuzesh = loader.amuzesh

--bool to save score rightly
SCORE_SAVE_BOOL = true




--sound && music sources and booleans :: starts here(should copy to set_null file) 


--sound in menu
menu_sound = loader.menu_sound
menu_sound:setVolume(0.8)



--GAMEOVER
GAMEOVER_MUSIC = loader.GAMEOVER_MUSIC
GAMEOVER_MUSIC_BOOLEAN = false
GAMEOVER_MUSIC:setVolume(0.9)




--boss1 theme music
BOSS1_THEME_MUSIC = loader.BOSS1_THEME_MUSIC
BOSS1_THEME_MUSIC_BOOLEAN = false
BOSS1_THEME_MUSIC:setVolume(0.8)

--rain sound
RAIN_SOUND = loader.RAIN_SOUND
RAIN_SOUND_BOOLEAN = false
RAIN_SOUND:setVolume(0.5)

--lightening sound
LIGHTENING_SOUND = loader.LIGHTENING_SOUND
LIGHTENING_SOUND_BOOLEAN = false
LIGHTENING_SOUND:setVolume(0.6)


--boss1 wait
BOSS1_WAIT_SOUND = loader.BOSS1_WAIT_SOUND
BOSS1_WAIT_SOUND:setVolume(1)

--boss1 gethit
BOSS1_GETHIT_SOUND = loader.BOSS1_GETHIT_SOUND
BOSS1_GETHIT_SOUND:setVolume(1)

--boss1 attack
BOSS1_ATTACK_SOUND = loader.BOSS1_ATTACK_SOUND
BOSS1_ATTACK_SOUND:setVolume(0.3)

--boss1 die
BOSS1_DIE_SOUND = loader.BOSS1_DIE_SOUND
BOSS1_DIE_SOUND_PLAYED = 0
BOSS1_DIE_SOUND:setVolume(1)

--boss1 in flames
BOSS1_INFLAME_SOUND = loader.BOSS1_INFLAME_SOUND
BOSS1_INFLAME_SOUND:setVolume(1)


--boss2 theme music
BOSS2_THEME_MUSIC = loader.BOSS2_THEME_MUSIC
BOSS2_THEME_MUSIC_BOOLEAN = false
BOSS2_THEME_MUSIC:setVolume(0.7)
--

--wind sound
WIND_SOUND = loader.WIND_SOUND
WIND_SOUND_BOOLEAN = false
WIND_SOUND:setVolume(0.6)
--

--boss2 jumping sound
BOSS2_JUMPING_SOUND = loader.BOSS2_JUMPING_SOUND
BOSS2_JUMPING_SOUND:setVolume(1)
--

--boss2 attack sound
BOSS2_ATTACK_SOUND = loader.BOSS2_ATTACK_SOUND
BOSS2_ATTACK_SOUND:setVolume(1)
--

--boss2 gethit sound 
BOSS2_GEHIT_SOUND = loader.BOSS2_GEHIT_SOUND
BOSS2_GEHIT_SOUND:setVolume(1)
--

--boss2 die
BOSS2_DIE_SOUND = loader.BOSS2_DIE_SOUND
BOSS2_DIE_SOUND_PLAYED = 0
BOSS2_DIE_SOUND:setVolume(1)

--boss2 in flames
BOSS2_INFLAME_SOUND = loader.BOSS2_INFLAME_SOUND
BOSS2_INFLAME_SOUND:setVolume(1)





--boss3 theme music
BOSS3_THEME_MUSIC = loader.BOSS3_THEME_MUSIC
BOSS3_THEME_MUSIC_BOOLEAN = false
BOSS3_THEME_MUSIC:setVolume(0.7)


--boss3 to fire
BOSS3_TO_FIRE_SOUND = loader.BOSS3_TO_FIRE_SOUND
BOSS3_TO_FIRE_SOUND:setVolume(1)
--

--boss3 to creep
BOSS3_TO_CREEP_SOUND = loader.BOSS3_TO_CREEP_SOUND
BOSS3_TO_CREEP_SOUND:setVolume(1)
--

--boss3 to glad
BOSS3_TO_GLAD_SOUND = loader.BOSS3_TO_GLAD_SOUND
BOSS3_TO_GLAD_SOUND:setVolume(1)
--

--boss3 to giant
BOSS3_TO_GIANT_SOUND = loader.BOSS3_TO_GIANT_SOUND
BOSS3_TO_GIANT_SOUND:setVolume(1)
--

--boss3 to skel
BOSS3_TO_SKEL_SOUND = loader.BOSS3_TO_SKEL_SOUND
BOSS3_TO_SKEL_SOUND:setVolume(1)
--

--boss3 to light
BOSS3_TO_LIGHT_SOUND = loader.BOSS3_TO_LIGHT_SOUND
BOSS3_TO_LIGHT_SOUND:setVolume(1)
--

--boss3 wait
BOSS3_WAIT_SOUND = loader.BOSS3_WAIT_SOUND
BOSS3_WAIT_SOUND:setVolume(1)
--

--boss3 die
BOSS3_DIE_SOUND = loader.BOSS3_DIE_SOUND
BOSS3_DIE_SOUND_PLAYED = 0
BOSS3_DIE_SOUND:setVolume(1)
--

--boss3 in flames
BOSS3_INFLAME_SOUND = loader.BOSS3_INFLAME_SOUND
BOSS3_INFLAME_SOUND:setVolume(1)
--



--blood rain sound
BLOOD_RAIN_SOUND = loader.BLOOD_RAIN_SOUND
BLOOD_RAIN_SOUND_BOOLEAN = false
BLOOD_RAIN_SOUND:setVolume(0.5)


--water sound
WATER_SOUND = loader.WATER_SOUND
WATER_SOUND_BOOLEAN = false
WATER_SOUND:setVolume(0.5)



--music for CONGRATULATIONS
CONGRATULATIONS_SOUND = loader.CONGRATULATIONS_SOUND
CONGRATULATIONS_SOUND_BOOLEAN = false
CONGRATULATIONS_SOUND:setVolume(0.7)

--voice for CONGRATULATIONS
CONGRATULATIONS_VOICE_SOUND = loader.CONGRATULATIONS_VOICE_SOUND
CONGRATULATIONS_VOICE_SOUND_BOOLEAN = false
CONGRATULATIONS_VOICE_SOUND_PLAYED = 0 
CONGRATULATIONS_VOICE_SOUND:setVolume(1)





--sounds for CROWS
CROWS_SOUND = loader.CROWS_SOUND
CROWS_SOUND_BOOLEAN = false
CROWS_SOUND:setVolume(1)

--sound for get hit
ENEMY1_GET_HIT_SOUND = loader.ENEMY1_GET_HIT_SOUND
ENEMY1_GET_HIT_SOUND_PLAYED = 0
ENEMY1_GET_HIT_SOUND:setVolume(1)

ENEMY2_GET_HIT_SOUND = loader.ENEMY2_GET_HIT_SOUND
ENEMY2_GET_HIT_SOUND_PLAYED = 0
ENEMY2_GET_HIT_SOUND:setVolume(1)

BOSS1_HELPER_GET_HIT_SOUND = loader.BOSS1_HELPER_GET_HIT_SOUND
BOSS1_HELPER_GET_HIT_SOUND_PLAYED = 0
BOSS1_HELPER_GET_HIT_SOUND:setVolume(1)


--sound for die
ENEMY1_DIE_SOUND = loader.ENEMY1_DIE_SOUND
ENEMY1_DIE_SOUND_PLAYED = 0
ENEMY1_DIE_SOUND:setVolume(1)

ENEMY2_DIE_SOUND = loader.ENEMY2_DIE_SOUND
ENEMY2_DIE_SOUND_PLAYED = 0
ENEMY2_DIE_SOUND:setVolume(1)

BOSS1_HELPER_DIE_SOUND = loader.BOSS1_HELPER_DIE_SOUND
BOSS1_HELPER_DIE_SOUND_PLAYED = 0
BOSS1_HELPER_DIE_SOUND:setVolume(1)





--SOUNDS for ROBOT:::

--sounds for guns:
--light gun
LIGHT_GUN_SOUND = loader.LIGHT_GUN_SOUND
LIGHT_GUN_SOUND_PLAYED = 0
LIGHT_GUN_SOUND:setVolume(0.7)

--hand gun
HAND_GUN_SOUND = loader.HAND_GUN_SOUND
HAND_GUN_SOUND_PLAYED = 0
HAND_GUN_SOUND:setVolume(0.7)

--shot gun
SHOT_GUN_SOUND = loader.SHOT_GUN_SOUND
SHOT_GUN_SOUND_PLAYED = 0
SHOT_GUN_SOUND:setVolume(0.9)

--heavy gun
HEAVY_GUN_SOUND = loader.HEAVY_GUN_SOUND
HEAVY_GUN_SOUND_PLAYED = 0
HEAVY_GUN_SOUND:setVolume(0.7)

--lazer gun
LAZER_GUN_SOUND = loader.LAZER_GUN_SOUND
LAZER_GUN_SOUND_PLAYED = 0
LAZER_GUN_SOUND:setVolume(0.7)



--sound for jump
JUMP_SOUND = loader.JUMP_SOUND
JUMP_SOUND_PLAYED = 0
JUMP_SOUND:setVolume(0.7)


--sound for get hit and get tremble
GET_HIT_SOUND = loader.GET_HIT_SOUND
GET_HIT_SOUND:setVolume(1)






--sound for background shake
EARTHQ = loader.EARTHQ
EARTHQ:setVolume(1)







touch_pad_lefty = loader.touch_pad_lefty


touchX_up = 110/2 * scale_x + 53/2 * scale_x * 0.45
touchY_up = 322/2 * scale_y - 57/2.2 * scale_y
touch_up = nil

touchX_right = 178/2 * scale_x +  53/2 * scale_x * 1.35
touchY_right = 368/2 * scale_y - 57/2 * scale_y * 0.4
touch_right = nil

touchX_left = 42/2 * scale_x
touchY_left = 368/2 * scale_y - 57/2 * scale_y * 0.4
touch_left = nil

touchX_down = 110/2 * scale_x + 53/2 * scale_x * 0.45
touchY_down = 420/2 * scale_y + 57/2.2 * scale_y * 0.2
touch_down = nil

touchX_shoot = 400/2 * scale_x
touchY_shoot = 0 * scale_y
touch_shoot = nil

timer = 0

-- for give meaning to looping the game :: start the variable
PASSING_FINISHeD_GAME = 0


CONG_HANDLER = false



handle_SHOT_GUN = false
handle_HEAVY_GUN = false
handle_LAZER_GUN = false







if not love.filesystem.exists("checkpoint.txt") then
jupiter = require "jupiter"
data = {_fileName = "checkpoint.txt", 1}
success = jupiter.save(data)

checkpoint_saved = 1

else

jupiter = require "jupiter"
newData = jupiter.load("checkpoint.txt")	
checkpoint_saved = newData[1]

end	






if checkpoint_saved == 1 then

--BOSS1 MODE ::  THE STANDARD MODE	

should_summon_boss1 = true
should_summon_boss2 = false
should_summon_boss3 = false

boss1_finished = false
boss2_finished = false
boss3_finished = false

handle_SHOT_GUN = false
handle_HEAVY_GUN = false
handle_LAZER_GUN = false


elseif checkpoint_saved == 2 then

--BOSS2 MODE

should_summon_boss1 = false
should_summon_boss2 = true
should_summon_boss3 = false

boss1_finished = true
boss2_finished = false
boss3_finished = false

handle_SHOT_GUN = true
handle_HEAVY_GUN = false
handle_LAZER_GUN = false

elseif checkpoint_saved == 3 then

--BOSS3 MODE

should_summon_boss1 = false
should_summon_boss2 = false
should_summon_boss3 = true

boss1_finished = true
boss2_finished = true
boss3_finished = false

handle_HEAVY_GUN = true
handle_SHOT_GUN = false
handle_LAZER_GUN = false

end





bullets = {}	


player = {x = 100 * scale_x ,y = 365 * scale_y ,img = nil ,health = 5}


player_GOT_TREMBL = false
player_should_trembl = false

player_GOT_TREMBL1 = false
player_should_trembl1 = false

player_GOT_TREMBL2 = false
player_should_trembl2 = false

player_GOT_TREMBL3 = false
player_should_trembl3 = false

player_GOT_DRIL = false
player_should_dril = false






playerDockedImg = loader.playerDockedImg
playerDockedImgWithTwobattry = loader.playerDockedImgWithTwobattry
playerDockedImgWithOnebattry = loader.playerDockedImgWithOnebattry

playerJumping = loader.playerJumping
playerJumpingWithTwobattry = loader.playerJumpingWithTwobattry
playerJumpingWithOnebattry = loader.playerJumpingWithOnebattry

--HEADLEFT = loader.HEADLEFT
--HEADRIGHT = loader.HEADRIGHT
BELT = loader.BELT




playerStanding = loader.playerStanding
playerStanding_frameSpeed = 0
playerStanding_frame = 1



playerStandingWithTwobattry = loader.playerStandingWithTwobattry
playerStandingWithTwobattry_frameSpeed = 0
playerStandingWithTwobattry_frame = 1



playerStandingWithOnebattry = loader.playerStandingWithOnebattry
playerStandingWithOnebattry_frameSpeed = 0
playerStandingWithOnebattry_frame = 1



playerMovingRight = loader.playerMovingRight
playerMovingRight_frameSpeed = 0
playerMovingRight_frame = 1



playerMovingRightWithTwobattry = loader.playerMovingRightWithTwobattry
playerMovingRightWithTwobattry_frameSpeed = 0
playerMovingRightWithTwobattry_frame = 1



playerMovingRightWithOnebattry = loader.playerMovingRightWithOnebattry
playerMovingRightWithOnebattry_frameSpeed = 0
playerMovingRightWithOnebattry_frame = 1


playerMovingLeft = loader.playerMovingLeft
playerMovingLeft_frameSpeed = 0
playerMovingLeft_frame = 1



playerMovingLeftWithTwobattry = loader.playerMovingLeftWithTwobattry
playerMovingLeftWithTwobattry_frameSpeed = 0
playerMovingLeftWithTwobattry_frame = 1



playerMovingLeftWithOnebattry = loader.playerMovingLeftWithOnebattry
playerMovingLeftWithOnebattry_frameSpeed = 0
playerMovingLeftWithOnebattry_frame = 1



enemys = {}
enemys[1] = enemys_helicoopter:new()
enemys[1].x = 480 * scale_x
enemys[1].y = 360 * scale_y
enemys[1].isAlive = true
enemys[1].EBullets = {}
enemys[1].health = 3
enemys[1].goingUp = true 
enemys[1].goingDown = false
enemys[1].shouldAttack = false
enemys[1].attackSpeed = 0
enemys[1].X_TIME = false
enemys[1].TIMEFORDIE = 0
enemys[1].X_TIMEFORDIE = enemys[1].x
enemys[1].changeforpicture = love.math.random(1,3)
enemys[1].hit_effect_start = false
enemys[1].hit_effect_TIME = 0


if enemys[1].changeforpicture == 1 then
enemys[1].img = loader.enemys_changeforpicture1
enemys[1].helicoopter_frame = 1
elseif enemys[1].changeforpicture == 2 then
enemys[1].img = loader.enemys_changeforpicture2
enemys[1].helicoopter_frame = 5
elseif enemys[1].changeforpicture == 3 then
enemys[1].img = loader.enemys_changeforpicture3
enemys[1].helicoopter_frame = 9
end	



enemys[1].helicoopter = loader.enemys_helicoopter
enemys[1].helicoopter_frameSpeed = 0





enemys[2] = enemys_helicoopter:new()
enemys[2].x = 650 * scale_x
enemys[2].y = 120 * scale_y
enemys[2].isAlive = true
enemys[2].EBullets = {}
enemys[2].health = 3
enemys[2].goingUp = true 
enemys[2].goingDown = false
enemys[2].shouldAttack = false
enemys[2].attackSpeed = 0
enemys[2].X_TIME = false
enemys[2].TIMEFORDIE = 0
enemys[2].X_TIMEFORDIE = enemys[2].x

if enemys[1].changeforpicture == 1 then
enemys[2].changeforpicture = enemys[1].changeforpicture + 1
elseif enemys[1].changeforpicture == 2 then
enemys[2].changeforpicture = enemys[1].changeforpicture + 1
elseif enemys[1].changeforpicture == 3 then    
enemys[2].changeforpicture = enemys[1].changeforpicture - 1
end   

enemys[2].hit_effect_start = false
enemys[2].hit_effect_TIME = 0


if enemys[2].changeforpicture == 1 then
enemys[2].img = loader.enemys_changeforpicture1
enemys[2].helicoopter_frame = 1
elseif enemys[2].changeforpicture == 2 then
enemys[2].img = loader.enemys_changeforpicture2
enemys[2].helicoopter_frame = 5
elseif enemys[2].changeforpicture == 3 then
enemys[2].img = loader.enemys_changeforpicture3
enemys[2].helicoopter_frame = 9
end	

enemys[2].helicoopter = loader.enemys_helicoopter
enemys[2].helicoopter_frameSpeed = 0

CROWENEMY_SHOOT = loader.CROWENEMY_SHOOT
CROWENEMY_DIE = loader.CROWENEMY_DIE

CROWENEMYNUMBER2_SHOOT = loader.CROWENEMYNUMBER2_SHOOT
CROWENEMYNUMBER2_DIE = loader.CROWENEMYNUMBER2_DIE

CROWENEMYNUMBER3_SHOOT = loader.CROWENEMYNUMBER3_SHOOT
CROWENEMYNUMBER3_DIE = loader.CROWENEMYNUMBER3_DIE


bulletE1 = loader.bulletE1
bulletE2 = loader.bulletE2
bulletE3 = loader.bulletE3



boss = BOSS:new()

boss.x = 500 * scale_x
boss.y = 100 * scale_y
boss.isAlive = false
boss.health = 3
boss.shouldAttack = false
boss.attackSpeed = 0
boss.shouldgethit = false
boss.should_summon_helper = false

boss.BULLET_IMG_FRAMESPEED = 0
boss.BULLET_IMG_FRAME = 1
boss.BULLET_IMGS = loader.boss_BULLET_IMGS
boss.BULLET_IMG = loader.boss_BULLET_IMG

boss.BOSSIMAGES = loader.boss_BOSSIMAGES



BOSS_WALKING = loader.BOSS_WALKING
BOSS_WALKING_frame = 1
BOSS_WALKING_frameSpeed = 0
BOSS_WALKING_IMG = BOSS_WALKING[1]
BOSS_WALKING_X = 1300/2 * scale_x
BOSS_WALKING_Y = boss.y


boss_frameSpeed_ATTACK = 0
boss_frame_ATTACK = 1
boss_frameSpeed_GETHIT = 0
boss_frame_GETHIT = 1
boss_frameSpeed_WAIT = 0
boss_frame_WAIT = 1


 
BBullet = loader.BBullet
boss.img = nil
boss.t = 0
boss.t1 = 0

BOSS_DEAD = loader.BOSS_DEAD
BOSS_DEAD_timeforshow = 400
BOSS_DEAD_t = 0
BOSS_DEAD_shouldshow = false
BOSS_DEAD_X = boss.x
BOSS_DEAD_Y = boss.y



boss.helper = enemys_helicoopter:new()
boss.helper.x = 480 * scale_x
boss.helper.y = 360 * scale_y
boss.helper.isAlive = nil
boss.helper.EBullets = {}
boss.helper.health = 3
boss.helper.goingUp = true 
boss.helper.goingDown = false
boss.helper.shouldAttack = false
boss.helper.attackSpeed = 0
boss.helper.X_TIME = false
boss.helper.TIMEFORDIE = 0
boss.helper.X_TIMEFORDIE = enemys[1].x
boss.helper.img = nil
boss.helper.changeforpicture = love.math.random(1,3)
boss.helper.hit_effect_start = false
boss.helper.hit_effect_TIME = 0


boss.helper.helicoopter = loader.enemys_helicoopter
boss.helper.helicoopter_frameSpeed = 0

if boss.helper.changeforpicture == 1 then
boss.helper.img = loader.enemys_changeforpicture1
boss.helper.helicoopter_frame = 1
elseif boss.helper.changeforpicture == 2 then
boss.helper.img = loader.enemys_changeforpicture2
boss.helper.helicoopter_frame = 5
elseif boss.helper.changeforpicture == 3 then
boss.helper.img = loader.enemys_changeforpicture3
boss.helper.helicoopter_frame = 9
end	



boss2 = BOSS2:new()

boss2.x = 100 * scale_x
boss2.y = 100 * scale_y
boss2.isAlive = false
boss2.health = 3
boss2.shouldAttack = false
boss2.attackSpeed = 0
boss2.shouldgethit = false
boss2.SECOND_ATTACK = false
boss2_midTremble = false
boss2_downTremble = false
boss2_mid2Tremble = false
boss2_upTremble = true

boss2_midTremble_T = 0
boss2_downTremble_T = 0
boss2_mid2Tremble_T = 0
boss2_upTremble_T = 0
Tremble_Tlimit = 3





boss2.BULLET_IMG_FRAMESPEED = 0
boss2.BULLET_IMG_FRAME = 1
boss2.BULLET_IMGS = loader.boss2_BULLET_IMGS
boss2.BULLET_IMG = loader.boss2_BULLET_IMG


JAG = loader.JAG
JAG_NOT = loader.JAG_NOT




boss2.BOSSIMAGES = loader.boss2_BOSSIMAGES




BOSS2_WALKING = loader.BOSS2_WALKING
BOSS2_WALKING_frame = 1
BOSS2_WALKING_frameSpeed = 0
BOSS2_WALKING_IMG = BOSS2_WALKING[1]
BOSS2_WALKING_X = 1100/2 * scale_x
BOSS2_WALKING_Y = boss2.y

boss2_frameSpeed_ATTACK = 0
boss2_frame_ATTACK = 1
boss2_frameSpeed_GETHIT = 0
boss2_frame_GETHIT = 1
boss2_frameSpeed_WAIT = 0
boss2_frame_WAIT = 1


boss2.BBullets = {}
BBullet = loader.BBullet
boss2.img = nil
boss2.t = 0
boss2.t1 = 0

BOSS2_DEAD = loader.BOSS2_DEAD
BOSS2_DEAD_timeforshow = 400
BOSS2_DEAD_t = 0
BOSS2_DEAD_shouldshow = false
BOSS2_DEAD_X = boss2.x
BOSS2_DEAD_Y = boss2.y





boss3 = BOSS3:new()

boss3.FIRST_ATTACK = true
boss3.SECOND_ATTACK = false
boss3.THIRD_ATTACK = false
boss3.changeToLight = false
boss3.to_first = false
boss3.to_second = false
boss3.to_third = false
boss3.to_get = false
boss3.t = 0
boss3.t1 = 0
boss3.t2 = 0
boss3.t3 = 0
boss3.t4 = 0
boss3.t5 = 0



boss3.x = 500 * scale_x
boss3.y = 100 * scale_y
boss3.isAlive = false
boss3.health = 3


boss3.shouldAttack = false
boss3.attackSpeed = 0

boss3.shouldAttack1 = false
boss3.attackSpeed1 = 0




boss3.shouldgethit = false
boss3_midTremble = false
boss3_downTremble = false
boss3_mid2Tremble = false
boss3_upTremble = true

boss3_midTremble_T = 0
boss3_downTremble_T = 0
boss3_mid2Tremble_T = 0
boss3_upTremble_T = 0
Tremble_Tlimit_boss3 = 3


GOT_SKEL_ATTACK1 = false
GOT_SKEL_ATTACK2 = false

SHOULD_GET_SKEL_ATTACK = false

skeleton_position = love.math.random(1,2)
skeleton_end_of_move = false


--BOSS3_TO_FIRE BULLETS:

boss3.BULLET_IMG_FRAMESPEED = 0
boss3.BULLET_IMG_FRAME = 1
boss3.BULLET_IMGS = loader.boss3_BULLET_IMGS
boss3.BULLET_IMG = loader.boss3_BULLET_IMG



--BOSS3_TO_CREEP BULLETS:

boss3.BULLET1_IMG_FRAMESPEED = 0
boss3.BULLET1_IMG_FRAME = 1
boss3.BULLET1_IMGS = loader.boss3_BULLET1_IMGS
boss3.BULLET1_IMG = loader.boss3_BULLET1_IMG


boss3.BULLET1_2IMG_FRAMESPEED = 0
boss3.BULLET1_2IMG_FRAME = 1
boss3.BULLET1_2IMGS = loader.boss3_BULLET1_2IMGS
boss3.BULLET1_2IMG = loader.boss3_BULLET1_2IMG


--BOSS3_TO_GLAD BULLETS:

boss3.BULLET2_IMG_FRAMESPEED = 0
boss3.BULLET2_IMG_FRAME = 1
boss3.BULLET2_IMGS = loader.boss3_BULLET2_IMGS
boss3.BULLET2_IMG = loader.boss3_BULLET2_IMG

boss3.BOSSIMAGES = loader.boss3_BOSSIMAGES


BOSS3_WALKING = loader.BOSS3_WALKING
BOSS3_WALKING_frame = 1
BOSS3_WALKING_frameSpeed = 0
BOSS3_WALKING_IMG = BOSS3_WALKING[1]
BOSS3_WALKING_X = 1300/2 * scale_x
BOSS3_WALKING_Y = boss3.y



boss3_frameSpeed_GETHIT = 0
boss3_frame_GETHIT = 1


boss3_frameSpeed_TO_LIGHT = 0
boss3_frame_TO_LIGHT = 1


boss3_frameSpeed_TO_FIRE = 0
boss3_frame_TO_FIRE = 1


boss3_frameSpeed_TO_GLAD = 0
boss3_frame_TO_GLAD = 1


boss3_frameSpeed_TO_GOUL = 0
boss3_frame_TO_GOUL = 1


boss3_frameSpeed_TO_SKEL = 0
boss3_frame_TO_SKEL = 1


boss3_frameSpeed_TO_CREEP = 0
boss3_frame_TO_CREEP = 1


boss3.BBullets = {}
BBullet = loader.BBullet
boss3.img = nil
boss3.t = 0
boss3.t1 = 0

BOSS3_DEAD = loader.BOSS3_DEAD
BOSS3_DEAD_timeforshow = 400
BOSS3_DEAD_t = 0
BOSS3_DEAD_shouldshow = false
BOSS3_DEAD_X = boss3.x
BOSS3_DEAD_Y = boss3.y




-- blockJump Class starts :: here

blockJumpForHelis = 1
blockforfightingboss1 = 2
blockforfightingboss2 = 3
blockJump = {visible = nil , x = nil , y = nil , GROUND = nil , width = nil , height = nil , img = nil , onBlock = nil}



--constructor starts :: here
function blockJump:new( o )
o = o or {}
setmetatable(o , self)
self.__index = self 
return o
end
--constructor ends :: here



function blockJump:Update()
    if CheckCollision(rect2.x,rect2.y,rect2.w,rect2.h , self.x , self.y , self.width , self.height) then
 self.onBlock = true
else
 self.onBlock = false
end
end



BLOCKJUMPS = {}
BLOCKJUMPS[blockJumpForHelis] = blockJump:new()
BLOCKJUMPS[blockJumpForHelis].visible = true 
BLOCKJUMPS[blockJumpForHelis].x = 105 * scale_x 
BLOCKJUMPS[blockJumpForHelis].y = 312  * scale_y
BLOCKJUMPS[blockJumpForHelis].width = 100  * scale_x
BLOCKJUMPS[blockJumpForHelis].height = 30  * scale_y
BLOCKJUMPS[blockJumpForHelis].GROUND = 205 * scale_y
BLOCKJUMPS[blockJumpForHelis].onBlock = false




BLOCKJUMPFORFIGHTINGBOSS = loader.BLOCKJUMPFORFIGHTINGBOSS



BLOCKJUMPS[blockforfightingboss1] = blockJump:new()
BLOCKJUMPS[blockforfightingboss1].visible = true 
BLOCKJUMPS[blockforfightingboss1].x = 890  * scale_x
BLOCKJUMPS[blockforfightingboss1].y = 310  * scale_y
BLOCKJUMPS[blockforfightingboss1].width = 100  * scale_x
BLOCKJUMPS[blockforfightingboss1].height = 30  * scale_y
BLOCKJUMPS[blockforfightingboss1].GROUND = 205 * scale_y
BLOCKJUMPS[blockforfightingboss1].onBlock = false





BLOCKJUMPS[blockforfightingboss2] = blockJump:new()
BLOCKJUMPS[blockforfightingboss2].visible = true 
BLOCKJUMPS[blockforfightingboss2].x = 890 * scale_x
BLOCKJUMPS[blockforfightingboss2].y = 180  * scale_y
BLOCKJUMPS[blockforfightingboss2].width = 100  * scale_x
BLOCKJUMPS[blockforfightingboss2].height = 30  * scale_y
BLOCKJUMPS[blockforfightingboss2].GROUND = 75 * scale_y
BLOCKJUMPS[blockforfightingboss2].onBlock = false







HEADOFMAMOUTHAnimationStart = false
headofmamouth = loader.headofmamouth
headofmamouthMainX = 47 * scale_x
headofmamouthMainY = 322 * scale_y
headofmamouthX = headofmamouthMainX
headofmamouthY = headofmamouthMainY
HEADOFMAMOUTH = loader.HEADOFMAMOUTH
HEADOFMAMOUTH_framespeed = 0
HEADOFMAMOUTH_frame = 1

--the end!







-- gun IMAGES :: starts here

lightGun = loader.lightGun
lightGunMovingLeft = loader.lightGunMovingLeft
lightGunDucked = loader.lightGunDucked

HAND_GUN = loader.HAND_GUN
HAND_GUN_MOVINGLEFT = loader.HAND_GUN_MOVINGLEFT
HAND_GUN_DUCKED = loader.HAND_GUN_DUCKED 

SHOT_GUN = loader.SHOT_GUN
SHOT_GUN_MOVINGLEFT = loader.SHOT_GUN_MOVINGLEFT
SHOT_GUN_DUCKED = loader.SHOT_GUN_DUCKED

heavyGun = loader.heavyGun
heavyGunMovingLeft = loader.heavyGunMovingLeft
heavyGunDucked = loader.heavyGunDucked

LAZER_GUN = loader.LAZER_GUN
LAZER_GUN_MOVINGLEFT = loader.LAZER_GUN_MOVINGLEFT
LAZER_GUN_DUCKED = loader.LAZER_GUN_DUCKED

FINAL_GUN = loader.FINAL_GUN
FINAL_GUN_MOVINGLEFT = loader.FINAL_GUN_MOVINGLEFT
FINAL_GUN_DUCKED = loader.FINAL_GUN_DUCKED


--init for gun
player_guns = guns:new()
player_guns.img  = loader.player_guns_img



NUMBER0 = loader.NUMBER0
NUMBER1 = loader.NUMBER1
NUMBER2 = loader.NUMBER2
NUMBER3 = loader.NUMBER3
NUMBER4 = loader.NUMBER4
NUMBER5 = loader.NUMBER5
NUMBER6 = loader.NUMBER6
NUMBER7 = loader.NUMBER7
NUMBER8 = loader.NUMBER8
NUMBER9 = loader.NUMBER9


SCORE = {x , y , img , toshow}

function SCORE:SCORE_UPDATE_IMAGE()
if self.toshow == 0 then
self.img = NUMBER0
elseif self.toshow == 1 then
self.img = NUMBER1
elseif self.toshow == 2 then
self.img = NUMBER2
elseif self.toshow == 3 then
self.img = NUMBER3
elseif self.toshow == 4 then
self.img = NUMBER4
elseif self.toshow == 5 then
self.img = NUMBER5
elseif self.toshow == 6 then
self.img = NUMBER6
elseif self.toshow == 7 then
self.img = NUMBER7
elseif self.toshow == 8 then
self.img = NUMBER8
elseif self.toshow == 9 then
self.img = NUMBER9
end
end


function SCORE:new( o )
o = o or {}
setmetatable(o , self)
self.__index = self 
return o
end



SCORES = {}
SCORES[1] = SCORE:new()
SCORES[2] = SCORE:new()
SCORES[3] = SCORE:new()
SCORES[4] = SCORE:new()
SCORES[1].x = 310 * scale_x   SCORES[1].y = 0 SCORES[1].img = NUMBER0   SCORES[1].toshow = 0
SCORES[2].x = 350 * scale_x   SCORES[2].y = 0 SCORES[2].img = NUMBER0   SCORES[2].toshow = 0
SCORES[3].x = 390 * scale_x   SCORES[3].y = 0 SCORES[3].img = NUMBER0   SCORES[3].toshow = 0
SCORES[4].x = 430 * scale_x   SCORES[4].y = 0 SCORES[4].img = NUMBER0   SCORES[4].toshow = 0



--AMMO class :: starts here

AMMOTOSHOW = {}
AMMOTOSHOW[1] = SCORE:new()
AMMOTOSHOW[2] = SCORE:new()
AMMOTOSHOW[3] = SCORE:new()
AMMOTIME = SCORE:new()


AMMOTOSHOW[1].x = 90 * scale_x   AMMOTOSHOW[1].y = 495 * scale_y   AMMOTOSHOW[1].img = NUMBER1   AMMOTOSHOW[1].toshow = 5
AMMOTOSHOW[2].x = 50 * scale_x   AMMOTOSHOW[2].y = 495 * scale_y   AMMOTOSHOW[2].img = NUMBER5   AMMOTOSHOW[2].toshow = 1
AMMOTOSHOW[3].x = 10 * scale_x   AMMOTOSHOW[3].y = 495 * scale_y   AMMOTOSHOW[3].img = NUMBER0   AMMOTOSHOW[3].toshow = 0
AMMOTIME.x = 750 * scale_x       AMMOTIME.y = 495 * scale_y        AMMOTIME.img = NUMBER0        AMMOTIME.toshow = 9

CLOCK = loader.CLOCK
AMMO_BULLET_HANDGUN = loader.AMMO_BULLET_HANDGUN
AMMO_BULLET_SHOT_GUN = loader.AMMO_BULLET_SHOT_GUN
AMMO_BULLET_HEAVYGUN = loader.AMMO_BULLET_HEAVYGUN
AMMO_BULLET_LAZER_GUN = loader.AMMO_BULLET_LAZER_GUN
AMMO_BULLET = AMMO_BULLET_HANDGUN

--AMMO class :: ends here




--Animation clip for crow

Crow = loader.Crow
Crow_frameSpeed = 0
Crow_frame = 1


Crow1 = {x = 388 * scale_x , y = 24 * scale_y , img = love.graphics.newImage('crow1.png')} 

--the end!
-- Animation clip for FLYINGBIRD :: starts here


FLYINGBIRD = loader.FLYINGBIRD
FLYINGBIRD_frameSpeed = 0
FLYINGBIRD_frame = 1

flyingbird = {x = 1000 * scale_x , y = 35 * scale_y , img = FLYINGBIRD[1]}



GRASS = loader.GRASS

GRASSES = {x = 0 , y = 435 * scale_y , img = GRASS[1] , frameSpeed = 0 , frame = 1 , GRASS = GRASS}


GRASSES1 = {x = 800 * scale_x , y = 435 * scale_y , img = GRASS[1] , frameSpeed = 0 , frame = 1 , GRASS = GRASS}


GROUNDD = loader.GROUNDD
GROUNDD1 = loader.GROUNDD1
GROUND_TO_SHOW = {0 , 200 * scale_x , 400 * scale_x , 600 * scale_x , y = 495 * scale_y , img = GROUNDD}
GROUND1_TO_SHOW = {800 * scale_x , 1000 * scale_x , 1200 * scale_x , 1400 * scale_x , y = 495 * scale_y , img = GROUNDD1}

-- the end


--Animation for RAIN :: starts here



THERAIN = loader.THERAIN

THERAIN_RED = loader.THERAIN_RED

THERAIN_frameSpeed = 0
THERAIN_frame = 1

THERAIN_RED_frameSpeed = 0
THERAIN_RED_frame = 1

RAIN = { x = 0 , y = 0 , img = THERAIN[1]}
RAIN1 = { x = 800 * scale_x , y = 0 , img = THERAIN[1] }

RAIN_RED = { x = 0 , y = 0 , img = THERAIN_RED[1]}

-- the end





--Animation for WATER_DROP :: starts here



THEWATER_DROP = loader.THEWATER_DROP



THEWATER_DROP_RED = loader.THEWATER_DROP_RED



WATER_DROP_LB = {}
WATER_DROP_LB[1] = { x = 0 , y = 400 * scale_y , img = THEWATER_DROP[1] , frameSpeed = 0 , frame = 1}
WATER_DROP_LB[2] = { x = 40 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[5] , frameSpeed = 0 , frame = 5} 
WATER_DROP_LB[3] = { x = 80 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[19] , frameSpeed = 0 , frame = 19}
WATER_DROP_LB[4] = { x = 120 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[10] , frameSpeed = 0 , frame = 10}  
WATER_DROP_LB[5] = { x = 160 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[7] , frameSpeed = 0 , frame = 7}
WATER_DROP_LB[6] = { x = 200 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[15] , frameSpeed = 0 , frame = 15} 
WATER_DROP_LB[7] = { x = 240 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[18] , frameSpeed = 0 , frame = 18}
WATER_DROP_LB[8] = { x = 280 * scale_x , y = 300 * scale_y , img = THEWATER_DROP[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_LB[9] = { x = 320 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[8] , frameSpeed = 0 , frame = 8}
WATER_DROP_LB[10] = { x = 360 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[22] , frameSpeed = 0 , frame = 22} 
WATER_DROP_LB[11] = { x = 400 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[17] , frameSpeed = 0 , frame = 17}
WATER_DROP_LB[12] = { x = 440 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[17] , frameSpeed = 0 , frame = 20}
WATER_DROP_LB[13] = { x = 480 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[9] , frameSpeed = 0 , frame = 9}
WATER_DROP_LB[14] = { x = 540 * scale_x , y = 300 * scale_y , img = THEWATER_DROP[12] , frameSpeed = 0 , frame = 12} 
WATER_DROP_LB[15] = { x = 560 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[16] , frameSpeed = 0 , frame = 16}
WATER_DROP_LB[16] = { x = 600 * scale_x , y = 300 * scale_y , img = THEWATER_DROP[7] , frameSpeed = 0 , frame = 7} 
WATER_DROP_LB[17] = { x = 640 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[10] , frameSpeed = 0 , frame = 10}
WATER_DROP_LB[18] = { x = 680 * scale_x , y = 310 * scale_y , img = THEWATER_DROP[2] , frameSpeed = 0 , frame = 2} 
WATER_DROP_LB[19] = { x = 720 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[15] , frameSpeed = 0 , frame = 15}
WATER_DROP_LB[20] = { x = 780 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[24] , frameSpeed = 0 , frame = 24} 
WATER_DROP_LB[21] = { x = 40 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[27] , frameSpeed = 0 , frame = 27} 
WATER_DROP_LB[22] = { x = 120 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[14] , frameSpeed = 0 , frame = 14}
WATER_DROP_LB[23] = { x = 200 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[25] , frameSpeed = 0 , frame = 25} 
WATER_DROP_LB[24] = { x = 280 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[13] , frameSpeed = 0 , frame = 13}
WATER_DROP_LB[25] = { x = 360 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[23] , frameSpeed = 0 , frame = 23} 
WATER_DROP_LB[26] = { x = 440 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[11] , frameSpeed = 0 , frame = 11}
WATER_DROP_LB[27] = { x = 520 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[21] , frameSpeed = 0 , frame = 21} 
WATER_DROP_LB[28] = { x = 600 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[5] , frameSpeed = 0 , frame = 5}
WATER_DROP_LB[29] = { x = 680 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_LB[30] = { x = 760 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[6] , frameSpeed = 0 , frame = 6}



WATER_DROP_RB = {}
WATER_DROP_RB[1] = { x = 800 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[1] , frameSpeed = 0 , frame = 1}
WATER_DROP_RB[2] = { x = 840 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[5] , frameSpeed = 0 , frame = 4} 
WATER_DROP_RB[3] = { x = 880 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[19] , frameSpeed = 0 , frame = 19}
WATER_DROP_RB[4] = { x = 920 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[10] , frameSpeed = 0 , frame = 7}  
WATER_DROP_RB[5] = { x = 960 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[7] , frameSpeed = 0 , frame = 7}
WATER_DROP_RB[6] = { x = 1000 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[15] , frameSpeed = 0 , frame = 10} 
WATER_DROP_RB[7] = { x = 1040 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[18] , frameSpeed = 0 , frame = 18}
WATER_DROP_RB[8] = { x = 1080 * scale_x , y = 300 * scale_y , img = THEWATER_DROP[20] , frameSpeed = 0 , frame = 13} 
WATER_DROP_RB[9] = { x = 1120 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[8] , frameSpeed = 0 , frame = 8}
WATER_DROP_RB[10] = { x = 1160 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[22] , frameSpeed = 0 , frame = 16} 
WATER_DROP_RB[11] = { x = 1200 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[17] , frameSpeed = 0 , frame = 17}
WATER_DROP_RB[12] = { x = 1260 * scale_x , y = 300 * scale_y , img = THEWATER_DROP[17] , frameSpeed = 0 , frame = 19}
WATER_DROP_RB[13] = { x = 1280 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[9] , frameSpeed = 0 , frame = 9}
WATER_DROP_RB[14] = { x = 1340 * scale_x , y = 300 * scale_y , img = THEWATER_DROP[12] , frameSpeed = 0 , frame = 21} 
WATER_DROP_RB[15] = { x = 1360 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[16] , frameSpeed = 0 , frame = 16}
WATER_DROP_RB[16] = { x = 1400 * scale_x , y = 300 * scale_y , img = THEWATER_DROP[7] , frameSpeed = 0 , frame = 24} 
WATER_DROP_RB[17] = { x = 1440 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[10] , frameSpeed = 0 , frame = 10}
WATER_DROP_RB[18] = { x = 1480 * scale_x , y = 310 * scale_y , img = THEWATER_DROP[2] , frameSpeed = 0 , frame = 9} 
WATER_DROP_RB[19] = { x = 1520 * scale_x , y = 400 * scale_y , img = THEWATER_DROP[15] , frameSpeed = 0 , frame = 15}
WATER_DROP_RB[20] = { x = 1580 * scale_x , y = 290 * scale_y , img = THEWATER_DROP[24] , frameSpeed = 0 , frame = 5} 
WATER_DROP_RB[21] = { x = 840 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[27] , frameSpeed = 0 , frame = 27} 
WATER_DROP_RB[22] = { x = 920 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[14] , frameSpeed = 0 , frame = 14}
WATER_DROP_RB[23] = { x = 1000 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[25] , frameSpeed = 0 , frame = 25} 
WATER_DROP_RB[24] = { x = 1080 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[13] , frameSpeed = 0 , frame = 13}
WATER_DROP_RB[25] = { x = 1160 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[23] , frameSpeed = 0 , frame = 23} 
WATER_DROP_RB[26] = { x = 1240 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[11] , frameSpeed = 0 , frame = 11}
WATER_DROP_RB[27] = { x = 1320 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[21] , frameSpeed = 0 , frame = 21} 
WATER_DROP_RB[28] = { x = 1400 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[5] , frameSpeed = 0 , frame = 5}
WATER_DROP_RB[29] = { x = 1480 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_RB[30] = { x = 1520 * scale_x , y = 410 * scale_y , img = THEWATER_DROP[6] , frameSpeed = 0 , frame = 6}

WATER_DROP_LB_RED = {}
WATER_DROP_LB_RED[1] = { x = 0 , y = 400 * scale_y , img = THEWATER_DROP_RED[1] , frameSpeed = 0 , frame = 1}
WATER_DROP_LB_RED[2] = { x = 40 * scale_x , y = 290 * scale_y , img = THEWATER_DROP_RED[5] , frameSpeed = 0 , frame = 5} 
WATER_DROP_LB_RED[3] = { x = 80 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[19] , frameSpeed = 0 , frame = 19}
WATER_DROP_LB_RED[4] = { x = 120 * scale_x , y = 290 * scale_y , img = THEWATER_DROP_RED[10] , frameSpeed = 0 , frame = 10}  
WATER_DROP_LB_RED[5] = { x = 160 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[7] , frameSpeed = 0 , frame = 7}
WATER_DROP_LB_RED[6] = { x = 200 * scale_x , y = 290 * scale_y , img = THEWATER_DROP_RED[15] , frameSpeed = 0 , frame = 15} 
WATER_DROP_LB_RED[7] = { x = 240 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[18] , frameSpeed = 0 , frame = 18}
WATER_DROP_LB_RED[8] = { x = 280 * scale_x , y = 300 * scale_y , img = THEWATER_DROP_RED[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_LB_RED[9] = { x = 320 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[8] , frameSpeed = 0 , frame = 8}
WATER_DROP_LB_RED[10] = { x = 360 * scale_x , y = 290 * scale_y , img = THEWATER_DROP_RED[22] , frameSpeed = 0 , frame = 22} 
WATER_DROP_LB_RED[11] = { x = 400 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[17] , frameSpeed = 0 , frame = 17}
WATER_DROP_LB_RED[12] = { x = 440 * scale_x , y = 290 * scale_y , img = THEWATER_DROP_RED[17] , frameSpeed = 0 , frame = 20}
WATER_DROP_LB_RED[13] = { x = 480 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[9] , frameSpeed = 0 , frame = 9}
WATER_DROP_LB_RED[14] = { x = 540 * scale_x , y = 300 * scale_y , img = THEWATER_DROP_RED[12] , frameSpeed = 0 , frame = 12} 
WATER_DROP_LB_RED[15] = { x = 560 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[16] , frameSpeed = 0 , frame = 16}
WATER_DROP_LB_RED[16] = { x = 600 * scale_x , y = 300 * scale_y , img = THEWATER_DROP_RED[7] , frameSpeed = 0 , frame = 7} 
WATER_DROP_LB_RED[17] = { x = 640 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[10] , frameSpeed = 0 , frame = 10}
WATER_DROP_LB_RED[18] = { x = 680 * scale_x , y = 310 * scale_y , img = THEWATER_DROP_RED[2] , frameSpeed = 0 , frame = 2} 
WATER_DROP_LB_RED[19] = { x = 720 * scale_x , y = 400 * scale_y , img = THEWATER_DROP_RED[15] , frameSpeed = 0 , frame = 15}
WATER_DROP_LB_RED[20] = { x = 780 * scale_x , y = 290 * scale_y , img = THEWATER_DROP_RED[24] , frameSpeed = 0 , frame = 24} 
WATER_DROP_LB_RED[21] = { x = 40 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[27] , frameSpeed = 0 , frame = 27} 
WATER_DROP_LB_RED[22] = { x = 120 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[14] , frameSpeed = 0 , frame = 14}
WATER_DROP_LB_RED[23] = { x = 200 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[25] , frameSpeed = 0 , frame = 25} 
WATER_DROP_LB_RED[24] = { x = 280 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[13] , frameSpeed = 0 , frame = 13}
WATER_DROP_LB_RED[25] = { x = 360 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[23] , frameSpeed = 0 , frame = 23} 
WATER_DROP_LB_RED[26] = { x = 440 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[11] , frameSpeed = 0 , frame = 11}
WATER_DROP_LB_RED[27] = { x = 520 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[21] , frameSpeed = 0 , frame = 21} 
WATER_DROP_LB_RED[28] = { x = 600 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[5] , frameSpeed = 0 , frame = 5}
WATER_DROP_LB_RED[29] = { x = 680 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_LB_RED[30] = { x = 760 * scale_x , y = 410 * scale_y , img = THEWATER_DROP_RED[6] , frameSpeed = 0 , frame = 6}




-- the end








--Animation for lightning :: starts here



THELIGHTNING_R = loader.THELIGHTNING_R
THELIGHTNING_R_frameSpeed = 0
THELIGHTNING_R_frame = 1

LIGHTNING_R_1 = { x = 0 , y = -25 * scale_y , img = THELIGHTNING_R[1]}
LIGHTNING_R_2 = { x = 800 * scale_x , y = -25 * scale_y , img = THELIGHTNING_R[1] }



THELIGHTNING_L = loader.THELIGHTNING_L
THELIGHTNING_L_frameSpeed = 0
THELIGHTNING_L_frame = 1

LIGHTNING_L_1 = { x = 480 * scale_x , y = -25 * scale_y , img = THELIGHTNING_L[1]}
LIGHTNING_L_2 = { x = 1280 * scale_x , y = -25 * scale_y , img = THELIGHTNING_L[1] }

--end!



--Animation for WIND :: starts here



THEWIND = loader.THEWIND
THEWIND_frameSpeed = 0
THEWIND_frame = 1

WIND = { x = 0 , y = 0 , img = THEWIND[1]}
WIND1 = { x = 800 * scale_x , y = 0 , img = THEWIND[1] }

-- the end




--Animation for WIND :: starts here



THESUN = loader.THESUN
THESUN_frameSpeed = 0
THESUN_frame = 1

SUN = { x = 225 * scale_x , y = 0 , img = THESUN[1]}
SUN1 = { x = 1025 * scale_x , y = 0 , img = THESUN[1]}


-- the end



-- animation for FLOWERS1 & 2 :: starts here

theFLOWERS1 = loader.theFLOWERS1

theFLOWERS1_frameSpeed = 0
theFLOWERS1_frame = 1

FLOWERS1_1 = { x = 600 * scale_x , y = 270 * scale_y , img = theFLOWERS1[1]}
FLOWERS1_2 = { x = 1400 * scale_x , y = 270 * scale_y , img = theFLOWERS1[1] }




theFLOWERS2 = loader.theFLOWERS2
theFLOWERS2_frameSpeed = 0
theFLOWERS2_frame = 1

FLOWERS2_1 = { x = 600 * scale_x , y = 0 , img = theFLOWERS2[1]}
FLOWERS2_2 = { x = 1400 * scale_x , y = 0 , img = theFLOWERS2[1]}




theFLOWERS3 = loader.theFLOWERS3
theFLOWERS3_frameSpeed = 0
theFLOWERS3_frame = 1

FLOWERS3_1 = { x = 0 , y = 0 , img = theFLOWERS3[1]}
FLOWERS3_2 = { x = 800 * scale_x , y = 0 , img = theFLOWERS3[1]}





theFLOWERS4 = loader.theFLOWERS4
theFLOWERS4_frameSpeed = 0
theFLOWERS4_frame = 1

FLOWERS4_1 = { x = 0 , y = 270 * scale_y , img = theFLOWERS4[1]}
FLOWERS4_2 = { x = 800 * scale_x , y = 270 * scale_y , img = theFLOWERS4[1]}






THEFLAMES = loader.THEFLAMES

THEFLAMES_frameSpeed = 0
THEFLAMES_frame = 1

FLAMES_BOSS1 = { x = 480 * scale_x , y = 60 * scale_y , img = THEFLAMES[1]}
FLAMES_BOSS2 = { x = 380 * scale_x , y = 10 * scale_y , img = THEFLAMES[1]}
FLAMES_BOSS3 = { x = 480 * scale_x , y = 60 * scale_y , img = THEFLAMES[1]}


BACKGROUND3 = loader.BACKGROUND3
BACKGROUND3_frame = 1
BACKGROUND3_frameSpeed = 0
BACKGROUND3_IMG = love.graphics.newImage('background3 (1).png')

-- end!




-- CONGRATULATION variables and PICTURES ::: starts here


BLUE_CONG = loader.BLUE_CONG

GREEN_CONG = loader.GREEN_CONG

YELLOW_CONG = loader.YELLOW_CONG

PURPLE_CONG = loader.PURPLE_CONG

BLUE_CONG_FRAME = 1
BLUE_CONG_FRAME_SPEED = 0

GREEN_CONG_FRAME = 1
GREEN_CONG_FRAME_SPEED = 0

YELLOW_CONG_FRAME = 1
YELLOW_CONG_FRAME_SPEED = 0

PURPLE_CONG_FRAME = 1
PURPLE_CONG_FRAME_SPEED = 0



CONG1 = { x = 0 , y = 0 , img = PURPLE_CONG[1]}
CONG2 = { x = 200 * scale_x , y = 0 , img = BLUE_CONG[1]}
CONG3 = { x = 400 * scale_x , y = 0 , img = GREEN_CONG[1]}
CONG4 = { x = 590 * scale_x , y = 0 , img = YELLOW_CONG[1]}

CONG1_1 = { x = 800 * scale_x , y = 0 , img = PURPLE_CONG[1]}
CONG2_1 = { x = 1000 * scale_x , y = 0 , img = BLUE_CONG[1]}
CONG3_1 = { x = 1200 * scale_x , y = 0 , img = GREEN_CONG[1]}
CONG4_1 = { x = 1390 * scale_x , y = 0 , img = YELLOW_CONG[1]}


WHITE_FLYINGBIRD = loader.WHITE_FLYINGBIRD

WHITE_FLYINGBIRD_L = loader.WHITE_FLYINGBIRD_L

WHITE_FLYINGBIRD_frameSpeed = 0
WHITE_FLYINGBIRD_frame = 1

white_flyingbird1 = {x = 0 , y = 85 * scale_y , img = WHITE_FLYINGBIRD[1]}
white_flyingbird2 = {x = 440 * scale_x , y = 85 * scale_y , img = WHITE_FLYINGBIRD_L[1]}

white_flyingbird3 = {x = 800 * scale_x , y = 85 * scale_y , img = WHITE_FLYINGBIRD[1]}
white_flyingbird4 = {x = 1240 * scale_x , y = 85 * scale_y , img = WHITE_FLYINGBIRD_L[1]}

WINGS_CONG = loader.WINGS_CONG

wing1_congs = {x = 0 , y = 0 , img = WINGS_CONG} 
wing2_congs = {x = 800 * scale_x , y = 0 , img = WINGS_CONG} 


CONGRATULATION = loader.CONGRATULATION


shotFireImg = loader.shotFireImg

fire = loader.fire

bulletImg = loader.bulletImg

bullet_LAZER_GUN = loader.bullet_LAZER_GUN

bullet_SHOT_GUN = loader.bullet_SHOT_GUN

bullet_HEAVY_GUN = loader.bullet_HEAVY_GUN

player.img = loader.player_img


backgroundimg = loader.backgroundimg


change_clothes = loader.change_clothes



background1 = {x = 0 , y = 0 , img = nil}
background2 = {x = 800 * scale_x , y = 0 , img = nil}
background1.img = backgroundimg
background2.img = backgroundimg

deadline = loader.deadline

ATTACK_HELP = loader.ATTACK_HELP

hit_effect = loader.hit_effect

GAME_PlAY = false

scoore = 0


AMMO = 50
AMMO_TIME = 0


movingRight = false
movingLeft = false
standing = false
jumping = false
ducking = false

timeLimit = 0.15

jumped = false

speed = 4
bulletspeed = 10
canshoot = true
shootTime = 75
shotFire = false

MAINGROUND = 340 * scale_y
GROUND = MAINGROUND 
gravity = 93
gravityT = 1
JumpTime = 1
Jumptiming = 0

pass = 0
pass1 = 0
passing = true
--boss is isAlive
GAME_PlAY_CHANGE = 0




amuzeshi_gameplay_enemy_1_time_to_reborn = 80
amuzeshi_gameplay_enemy_2_time_to_reborn = 80




--init : end!

--list of all audio and sounds except explotion in gameover state
list_of_audio_sources = {}
list_of_audio_sources[1] = studio_music
list_of_audio_sources[2] = menu_sound
list_of_audio_sources[3] = GAMEOVER_MUSIC
list_of_audio_sources[4] = BOSS1_THEME_MUSIC
list_of_audio_sources[5] = RAIN_SOUND
list_of_audio_sources[6] = LIGHTENING_SOUND
list_of_audio_sources[7] = BOSS1_WAIT_SOUND
list_of_audio_sources[8] = BOSS1_GETHIT_SOUND
list_of_audio_sources[9] = BOSS1_ATTACK_SOUND
list_of_audio_sources[10] = BOSS1_DIE_SOUND
list_of_audio_sources[11] = BOSS1_INFLAME_SOUND
list_of_audio_sources[12] = BOSS2_THEME_MUSIC
list_of_audio_sources[13] = WIND_SOUND
list_of_audio_sources[14] = BOSS2_JUMPING_SOUND 
list_of_audio_sources[15] = BOSS2_GEHIT_SOUND
list_of_audio_sources[16] = BOSS2_DIE_SOUND
list_of_audio_sources[17] = BOSS2_INFLAME_SOUND
list_of_audio_sources[18] = BOSS3_THEME_MUSIC
list_of_audio_sources[19] = BOSS3_TO_FIRE_SOUND
list_of_audio_sources[20] = BOSS3_TO_CREEP_SOUND
list_of_audio_sources[21] = BOSS3_TO_GLAD_SOUND
list_of_audio_sources[22] = BOSS3_TO_SKEL_SOUND
list_of_audio_sources[23] = BOSS3_TO_LIGHT_SOUND 
list_of_audio_sources[24] = BOSS3_WAIT_SOUND
list_of_audio_sources[25] = BOSS3_DIE_SOUND
list_of_audio_sources[26] = BOSS3_INFLAME_SOUND
list_of_audio_sources[27] = BLOOD_RAIN_SOUND
list_of_audio_sources[28] = WATER_SOUND
list_of_audio_sources[29] = CONGRATULATIONS_SOUND
list_of_audio_sources[30] = CONGRATULATIONS_VOICE_SOUND
list_of_audio_sources[31] = CROWS_SOUND
list_of_audio_sources[32] = ENEMY1_GET_HIT_SOUND
list_of_audio_sources[33] = ENEMY2_GET_HIT_SOUND
list_of_audio_sources[34] = BOSS1_HELPER_GET_HIT_SOUND
list_of_audio_sources[35] = ENEMY1_DIE_SOUND
list_of_audio_sources[36] = ENEMY2_DIE_SOUND
list_of_audio_sources[37] = BOSS1_HELPER_DIE_SOUND
list_of_audio_sources[38] = LIGHT_GUN_SOUND
list_of_audio_sources[39] = HAND_GUN_SOUND
list_of_audio_sources[40] = SHOT_GUN_SOUND
list_of_audio_sources[41] = HEAVY_GUN_SOUND
list_of_audio_sources[42] = LAZER_GUN_SOUND
list_of_audio_sources[43] = JUMP_SOUND
list_of_audio_sources[44] = GET_HIT_SOUND 
list_of_audio_sources[45] = EARTHQ
list_of_audio_sources[46] = BOSS2_ATTACK_SOUND



explotion_gameover = loader.explotion_gameover
explotion_gameover:setVolume(1.0)
explotion_gameover_once = 0





loader.loading = true

end-- if 

end-- end of function



