
function loading_all()

local self = {}

self.initial = false
self.loading = true

self.bools_to_help_loading = {}
self.bools_to_help_loading[1] = false
self.bools_to_help_loading[2] = true
self.bools_to_help_loading[3] = true
self.bools_to_help_loading[4] = true
self.bools_to_help_loading[5] = true
self.bools_to_help_loading[6] = true
self.bools_to_help_loading[7] = true
self.bools_to_help_loading[8] = true
self.bools_to_help_loading[9] = true
self.bools_to_help_loading[10] = true
self.bools_to_help_loading[11] = true
self.bools_to_help_loading[12] = true
self.bools_to_help_loading[13] = true
self.bools_to_help_loading[14] = true
self.bools_to_help_loading[15] = true
self.bools_to_help_loading[16] = true
self.bools_to_help_loading[17] = true
self.bools_to_help_loading[18] = true
self.bools_to_help_loading[19] = true
self.bools_to_help_loading[20] = true
self.bools_to_help_loading[21] = true
self.bools_to_help_loading[22] = true
self.bools_to_help_loading[23] = true
self.bools_to_help_loading[24] = true
self.bools_to_help_loading[25] = true
self.bools_to_help_loading[26] = true
self.bools_to_help_loading[27] = true
self.bools_to_help_loading[28] = true
self.bools_to_help_loading[29] = true
self.bools_to_help_loading[30] = true
self.bools_to_help_loading[31] = true
self.bools_to_help_loading[32] = true
self.bools_to_help_loading[33] = true
self.bools_to_help_loading[34] = true
self.bools_to_help_loading[35] = true
self.bools_to_help_loading[36] = true
self.bools_to_help_loading[37] = true
self.bools_to_help_loading[38] = true
self.bools_to_help_loading[39] = true
self.bools_to_help_loading[40] = true
self.bools_to_help_loading[41] = true
self.bools_to_help_loading[42] = true
self.bools_to_help_loading[43] = true
self.bools_to_help_loading[44] = true
self.bools_to_help_loading[45] = true
self.bools_to_help_loading[46] = true
self.bools_to_help_loading[47] = true
self.bools_to_help_loading[48] = true
self.bools_to_help_loading[49] = true
self.bools_to_help_loading[50] = true
self.bools_to_help_loading[51] = true
self.bools_to_help_loading[52] = true
self.bools_to_help_loading[53] = true
self.bools_to_help_loading[54] = true
self.bools_to_help_loading[55] = true
self.bools_to_help_loading[56] = true
self.bools_to_help_loading[57] = true
self.bools_to_help_loading[58] = true
self.bools_to_help_loading[59] = true
self.bools_to_help_loading[60] = true
self.bools_to_help_loading[61] = true
self.bools_to_help_loading[62] = true
self.bools_to_help_loading[63] = true
self.bools_to_help_loading[64] = true
self.bools_to_help_loading[65] = true
self.bools_to_help_loading[66] = true
self.bools_to_help_loading[67] = true
self.bools_to_help_loading[68] = true
self.bools_to_help_loading[69] = true
self.bools_to_help_loading[70] = true
self.bools_to_help_loading[71] = true
self.bools_to_help_loading[72] = true
self.bools_to_help_loading[73] = true
self.bools_to_help_loading[74] = true
self.bools_to_help_loading[75] = true
self.bools_to_help_loading[76] = true
self.bools_to_help_loading[77] = true
self.bools_to_help_loading[78] = true
self.bools_to_help_loading[79] = true
self.bools_to_help_loading[80] = true
self.bools_to_help_loading[81] = true
self.bools_to_help_loading[82] = true
self.bools_to_help_loading[83] = true
self.bools_to_help_loading[84] = true
self.bools_to_help_loading[85] = true
self.bools_to_help_loading[86] = true
self.bools_to_help_loading[87] = true
self.bools_to_help_loading[88] = true
self.bools_to_help_loading[89] = true
self.bools_to_help_loading[90] = true
self.bools_to_help_loading[91] = true
self.bools_to_help_loading[92] = true
self.bools_to_help_loading[93] = true
self.bools_to_help_loading[94] = true
self.bools_to_help_loading[95] = true
self.bools_to_help_loading[96] = true
self.bools_to_help_loading[97] = true
self.bools_to_help_loading[98] = true
self.bools_to_help_loading[99] = true
self.bools_to_help_loading[100] = true

self.bools_to_help_loading2 = {}

self.bools_to_help_loading2[1] = true
self.bools_to_help_loading2[2] = true
self.bools_to_help_loading2[3] = true
self.bools_to_help_loading2[4] = true
self.bools_to_help_loading2[5] = true
self.bools_to_help_loading2[6] = true
self.bools_to_help_loading2[7] = true
self.bools_to_help_loading2[8] = true
self.bools_to_help_loading2[9] = true
self.bools_to_help_loading2[10] = true
self.bools_to_help_loading2[11] = true
self.bools_to_help_loading2[12] = true
self.bools_to_help_loading2[13] = true
self.bools_to_help_loading2[14] = true
self.bools_to_help_loading2[15] = true
self.bools_to_help_loading2[16] = true
self.bools_to_help_loading2[17] = true
self.bools_to_help_loading2[18] = true
self.bools_to_help_loading2[19] = true
self.bools_to_help_loading2[20] = true
self.bools_to_help_loading2[21] = true
self.bools_to_help_loading2[22] = true
self.bools_to_help_loading2[23] = true
self.bools_to_help_loading2[24] = true
self.bools_to_help_loading2[25] = true
self.bools_to_help_loading2[26] = true



self.should_initial = function()

return (self.initial == false and self.loading == true)

end

self.should_set = function()

return (self.initial == true and self.loading == false)

end


self.should_start_the_game = function()

return (self.initial == true and self.loading == true)

end




self.loading__all = function()

if self.should_initial() then

--print("loading")
--
if self.bools_to_help_loading[1] == false then

self.A_background = love.graphics.newImage("background_amuzeshi.png")
self.AA_background = love.graphics.newImage("jayegah_paresh.png")
self.after_lost_choose_img = love.graphics.newImage("after_lose.png")
self.gameover_explode = {}
self.gameover_explode[1] = love.graphics.newImage('explode (1).png')
self.gameover_explode[2] = love.graphics.newImage('explode (2).png')
self.gameover_explode[3] = love.graphics.newImage('explode (3).png')
self.gameover_explode[4] = love.graphics.newImage('explode (4).png')
self.gameover_explode[5] = love.graphics.newImage('explode (5).png')
self.gameover_explode[6] = love.graphics.newImage('explode (6).png')
self.gameover_explode[7] = love.graphics.newImage('explode (7).png')
self.gameover_explode[8] = love.graphics.newImage('explode (8).png')


self.bools_to_help_loading[1] = true 
self.bools_to_help_loading[2] = false



elseif self.bools_to_help_loading[2] == false then

self.gameover_explode[9] = love.graphics.newImage('explode (9).png')
self.gameover_explode[10] = love.graphics.newImage('explode (10).png')
self.gameover_explode[11] = love.graphics.newImage('explode (11).png')
self.gameover_explode[12] = love.graphics.newImage('explode (12).png')
self.gameover_explode[13] = love.graphics.newImage('explode (13).png')
self.gameover_explode[14] = love.graphics.newImage('explode (14).png')
self.gameover_explode[15] = love.graphics.newImage('explode (15).png')
self.gameover_explode[16] = love.graphics.newImage('explode (16).png')
self.gameover_explode[17] = love.graphics.newImage('explode (17).png')
self.gameover_explode[18] = love.graphics.newImage('explode (18).png')
self.gameover_explode[19] = love.graphics.newImage('explode (19).png')
self.gameover_explode[20] = love.graphics.newImage('explode (20).png')
self.gameover_explode[21] = love.graphics.newImage('explode (21).png')


self.bools_to_help_loading[2] = true 
self.bools_to_help_loading[3] = false
--

elseif self.bools_to_help_loading[3] == false then

self.gameover_explode[22] = love.graphics.newImage('explode (22).png')
self.gameover_explode[23] = love.graphics.newImage('explode (23).png')
self.gameover_explode[24] = love.graphics.newImage('explode (24).png')
self.gameover_explode[25] = love.graphics.newImage('explode (25).png')
self.gameover_explode[26] = love.graphics.newImage('explode (26).png')
self.gameover_explode[27] = love.graphics.newImage('explode (27).png')
self.gameover_explode[28] = love.graphics.newImage('explode (28).png')
self.gameover_explode[29] = love.graphics.newImage('explode (28).png')
self.gameover_explode[30] = love.graphics.newImage('explode (28).png')
self.gameover_explode[31] = love.graphics.newImage('explode (28).png')
self.gameover_explode[32] = love.graphics.newImage('explode (28).png')
self.gameover_explode[33] = love.graphics.newImage('explode (28).png')


self.bools_to_help_loading[3] = true 
self.bools_to_help_loading[4] = false


elseif self.bools_to_help_loading[4] == false then


self.bools_to_help_loading[4] = true 
self.bools_to_help_loading[5] = false

--
elseif self.bools_to_help_loading[5] == false then



self.gameover_explode_to_show = self.gameover_explode[1]



self.bools_to_help_loading[5] = true 
self.bools_to_help_loading[6] = false


elseif self.bools_to_help_loading[6] == false then

self.play_m = love.graphics.newImage("play_m.png")
self.play_p = love.graphics.newImage("play.png")

--amuzeshi_gameplay == true
self.play_m_a = love.graphics.newImage("play_a_m.png")
self.play_p_a = love.graphics.newImage("play_a.png")
--end

self.play_img = play_p

self.play_img_a = play_p_a




self.stop_img = love.graphics.newImage("stop.png")

--ANIMATION FOR HAND HELP

self.hand_help = {}
self.hand_help[1] = love.graphics.newImage("hand_help.png")
self.hand_help[2] = love.graphics.newImage("hand_help1.png")
self.hand = self.hand_help[1]


self.bools_to_help_loading[6] = true 
self.bools_to_help_loading[7] = false

--
elseif self.bools_to_help_loading[7] == false then

self.menu_anim = {}
self.menu_anim[1] = love.graphics.newImage("menu_anim (1).png")
self.menu_anim[2] = love.graphics.newImage("menu_anim (2).png")
self.menu_anim[3] = love.graphics.newImage("menu_anim (3).png")
self.menu_anim[4] = love.graphics.newImage("menu_anim (4).png")
self.menu_anim[5] = love.graphics.newImage("menu_anim (5).png")
self.menu_anim[6] = love.graphics.newImage("menu_anim (6).png")
self.menu_anim[7] = love.graphics.newImage("menu_anim (7).png")
self.menu_anim[8] = love.graphics.newImage("menu_anim (8).png")
self.menu_anim[9] = love.graphics.newImage("menu_anim (9).png")
self.menu_anim[10] = love.graphics.newImage("menu_anim (10).png")


self.bools_to_help_loading[7] = true 
self.bools_to_help_loading[8] = false


elseif self.bools_to_help_loading[8] == false then

--animation for menu
self.menu = self.menu_anim[1]


self.bools_to_help_loading[8] = true 
self.bools_to_help_loading[9] = false

elseif self.bools_to_help_loading[9] == false then

self.studio_pic = love.graphics.newImage("studio.png")
self.studio_music = love.audio.newSource('studio.mp3', 'stream')


self.SCORE_IMAGE = love.graphics.newImage("scores.png")

self.amuzesh = love.graphics.newImage("amuzesh.png")

self.menu_sound = love.audio.newSource("lightening.mp3" , 'stream')

self.GAMEOVER_MUSIC = love.audio.newSource('GAMEOVER.mp3', 'stream')


self.BOSS1_THEME_MUSIC = love.audio.newSource('boss1.mp3', 'stream')

self.RAIN_SOUND = love.audio.newSource('rain.mp3', 'stream')

self.LIGHTENING_SOUND = love.audio.newSource('lightening.mp3', 'stream')

self.BOSS1_WAIT_SOUND = love.audio.newSource('boss1_gethit.mp3', 'stream')

--boss1 gethit
self.BOSS1_GETHIT_SOUND = love.audio.newSource('boss1_wait.mp3', 'stream')


self.bools_to_help_loading[9] = true 
self.bools_to_help_loading[10] = false

elseif self.bools_to_help_loading[10] == false then

--menu_pad:
self.connection = love.graphics.newImage("connection.png")
self.menu_pad_asli = love.graphics.newImage("menu_pad.png")
self.menu_pad_bazgasht = love.graphics.newImage("bazgasht.png")
self.menu_pad = menu_pad_asli



--boss1 attack
self.BOSS1_ATTACK_SOUND = love.audio.newSource('boss1_attack.mp3', 'stream')

self.BOSS1_DIE_SOUND = love.audio.newSource('boss1_die.mp3', 'stream')

self.BOSS1_INFLAME_SOUND = love.audio.newSource('buening.mp3', 'stream')


self.bools_to_help_loading[10] = true 
self.bools_to_help_loading[11] = false


--elseif self.bools_to_help_loading[11] == false then

self.BOSS2_THEME_MUSIC = love.audio.newSource('boss2.mp3', 'stream')

self.WIND_SOUND = love.audio.newSource('wind.mp3', 'stream')

self.BOSS2_JUMPING_SOUND = love.audio.newSource('boss2_jumping.mp3', 'stream')

self.BOSS2_ATTACK_SOUND = love.audio.newSource('boss2_attack.mp3', 'stream')

self.BOSS2_GEHIT_SOUND = love.audio.newSource('boss2_gethit.mp3', 'stream')

self.BOSS2_DIE_SOUND = love.audio.newSource('boss2_die.mp3', 'stream')


self.BOSS2_INFLAME_SOUND = love.audio.newSource('buening.mp3', 'stream')

self.BOSS3_THEME_MUSIC = love.audio.newSource('boss3.mp3', 'stream')

self.BOSS3_TO_FIRE_SOUND = love.audio.newSource('boss3_to_fire.mp3', 'stream')

self.BOSS3_TO_CREEP_SOUND = love.audio.newSource('boss3_to_creep.mp3', 'stream')


self.bools_to_help_loading[11] = true 
self.bools_to_help_loading[12] = false


elseif self.bools_to_help_loading[12] == false then

self.BOSS3_TO_GLAD_SOUND = love.audio.newSource('boss3_to_glad.mp3', 'stream')

self.BOSS3_TO_GIANT_SOUND = love.audio.newSource('boss3_to_giant.mp3', 'stream')

self.BOSS3_TO_SKEL_SOUND = love.audio.newSource('boss3_to_skel.mp3', 'stream')

self.BOSS3_TO_LIGHT_SOUND = love.audio.newSource('boss3_to_light.mp3', 'stream')

self.BOSS3_WAIT_SOUND = love.audio.newSource('boss3_wait.mp3', 'stream')

self.BOSS3_DIE_SOUND = love.audio.newSource('boss3_die.mp3', 'stream')

self.BOSS3_INFLAME_SOUND = love.audio.newSource('buening.mp3', 'stream')

self.BLOOD_RAIN_SOUND = love.audio.newSource('rain.mp3', 'stream')

self.WATER_SOUND = love.audio.newSource('water.mp3', 'stream')

self.CONGRATULATIONS_SOUND = love.audio.newSource('congratulations.mp3', 'stream')

self.CONGRATULATIONS_VOICE_SOUND = love.audio.newSource('congratulations_voice.mp3', 'stream')


self.bools_to_help_loading[12] = true 
self.bools_to_help_loading[13] = false

--
elseif self.bools_to_help_loading[13] == false then

self.CROWS_SOUND = love.audio.newSource('CROWS.mp3', 'stream')

self.ENEMY1_GET_HIT_SOUND = love.audio.newSource('crow_get_hit.mp3', 'stream')

self.ENEMY2_GET_HIT_SOUND = love.audio.newSource('crow_get_hit.mp3', 'stream')

self.BOSS1_HELPER_GET_HIT_SOUND = love.audio.newSource('crow_get_hit.mp3', 'stream')

self.ENEMY1_DIE_SOUND = love.audio.newSource('crow_die.mp3', 'stream')

self.ENEMY2_DIE_SOUND = love.audio.newSource('crow_die.mp3', 'stream')

self.BOSS1_HELPER_DIE_SOUND = love.audio.newSource('crow_die.mp3', 'stream')

self.LIGHT_GUN_SOUND = love.audio.newSource('HAND_GUN.mp3', 'stream')

self.HAND_GUN_SOUND = love.audio.newSource('REVOLVER.mp3', 'stream')
--shot gun
self.SHOT_GUN_SOUND = love.audio.newSource('SHOT_GUN.mp3', 'stream')
--heavy gun
self.HEAVY_GUN_SOUND = love.audio.newSource('SHOT_GUN.mp3', 'stream')
--lazer gun

self.bools_to_help_loading[13] = true 
self.bools_to_help_loading[14] = false


elseif self.bools_to_help_loading[14] == false then

self.LAZER_GUN_SOUND = love.audio.newSource('LAZER_GUN.mp3', 'stream')
--sound for jump
self.JUMP_SOUND = love.audio.newSource('jump.mp3', 'stream')

self.GET_HIT_SOUND = love.audio.newSource('robot_get_hit.mp3', 'stream')
--sound for background shake
self.EARTHQ = love.audio.newSource('earthQ.mp3', 'stream')

self.touch_pad_lefty = love.graphics.newImage('touch_pad_lefty.png')

self.playerDockedImg = love.graphics.newImage('character_down_1.png')
self.playerDockedImgWithTwobattry = love.graphics.newImage('character_down_1bb.png')
self.playerDockedImgWithOnebattry = love.graphics.newImage('character_down_1b.png') 

self.playerJumping = love.graphics.newImage('jump_1.png')
self.playerJumpingWithTwobattry = love.graphics.newImage('jump_1bb.png')
self.playerJumpingWithOnebattry = love.graphics.newImage('jump_1b.png')


self.bools_to_help_loading[14] = true 
self.bools_to_help_loading[15] = false


--elseif self.bools_to_help_loading[15] == false then

--self.HEADLEFT = love.graphics.newImage('headleft.png')
--self.HEADRIGHT = love.graphics.newImage('headright.png')
self.BELT = love.graphics.newImage('belt.png')

self.playerStanding = {}
self.playerStanding[1] = love.graphics.newImage('character_1_1.png')
self.playerStanding[2] = love.graphics.newImage('character_2.png')
self.playerStanding[3] = love.graphics.newImage('character_3.png')
self.playerStanding[4] = love.graphics.newImage('character_4.png')
self.playerStanding[5] = love.graphics.newImage('charcter_5.png')


self.bools_to_help_loading[15] = true 
self.bools_to_help_loading[16] = false



elseif self.bools_to_help_loading[16] == false then

self.playerStandingWithTwobattry = {}
self.playerStandingWithTwobattry[1] = love.graphics.newImage('character_1_1bb.png')
self.playerStandingWithTwobattry[2] = love.graphics.newImage('character_2bb.png')
self.playerStandingWithTwobattry[3] = love.graphics.newImage('character_3bb.png')
self.playerStandingWithTwobattry[4] = love.graphics.newImage('character_4bb.png')
self.playerStandingWithTwobattry[5] = love.graphics.newImage('charcter_5bb.png')

self.playerStandingWithOnebattry = {}
self.playerStandingWithOnebattry[1] = love.graphics.newImage('character_1_1b.png')
self.playerStandingWithOnebattry[2] = love.graphics.newImage('character_2b.png')
self.playerStandingWithOnebattry[3] = love.graphics.newImage('character_3b.png')
self.playerStandingWithOnebattry[4] = love.graphics.newImage('character_4b.png')
self.playerStandingWithOnebattry[5] = love.graphics.newImage('charcter_5b.png')


self.bools_to_help_loading[16] = true 
self.bools_to_help_loading[17] = false


--elseif self.bools_to_help_loading[17] == false then

self.playerMovingRight = {}
self.playerMovingRight[1] = love.graphics.newImage('0.png')
self.playerMovingRight[2] = love.graphics.newImage('1.1.png')
self.playerMovingRight[3] = love.graphics.newImage('1.png')
self.playerMovingRight[4] = love.graphics.newImage('2.png')
self.playerMovingRight[5] = love.graphics.newImage('3.png')
self.playerMovingRight[6] = love.graphics.newImage('4.0.png')
self.playerMovingRight[7] = love.graphics.newImage('4.1.png')
self.playerMovingRight[8] = love.graphics.newImage('5.png')
self.playerMovingRight[9] = love.graphics.newImage('6.png')
self.playerMovingRight[10] = love.graphics.newImage('7.png')
self.playerMovingRight[11] = love.graphics.newImage('8.png')
self.playerMovingRight[12] = love.graphics.newImage('9.png')


self.bools_to_help_loading[17] = true 
self.bools_to_help_loading[18] = false


elseif self.bools_to_help_loading[18] == false then

self.playerMovingRightWithTwobattry = {}
self.playerMovingRightWithTwobattry[1] = love.graphics.newImage('0bb.png')
self.playerMovingRightWithTwobattry[2] = love.graphics.newImage('1.1bb.png')
self.playerMovingRightWithTwobattry[3] = love.graphics.newImage('1bb.png')
self.playerMovingRightWithTwobattry[4] = love.graphics.newImage('2bb.png')
self.playerMovingRightWithTwobattry[5] = love.graphics.newImage('3bb.png')
self.playerMovingRightWithTwobattry[6] = love.graphics.newImage('4.0bb.png')
self.playerMovingRightWithTwobattry[7] = love.graphics.newImage('4.1bb.png')
self.playerMovingRightWithTwobattry[8] = love.graphics.newImage('5bb.png')
self.playerMovingRightWithTwobattry[9] = love.graphics.newImage('6bb.png')
self.playerMovingRightWithTwobattry[10] = love.graphics.newImage('7bb.png')
self.playerMovingRightWithTwobattry[11] = love.graphics.newImage('8bb.png')
self.playerMovingRightWithTwobattry[12] = love.graphics.newImage('9bb.png')


self.bools_to_help_loading[18] = true 
self.bools_to_help_loading[19] = false

elseif self.bools_to_help_loading[19] == false then

self.playerMovingRightWithOnebattry = {}
self.playerMovingRightWithOnebattry[1] = love.graphics.newImage('0b.png')
self.playerMovingRightWithOnebattry[2] = love.graphics.newImage('1.1b.png')
self.playerMovingRightWithOnebattry[3] = love.graphics.newImage('1b.png')
self.playerMovingRightWithOnebattry[4] = love.graphics.newImage('2b.png')
self.playerMovingRightWithOnebattry[5] = love.graphics.newImage('3b.png')
self.playerMovingRightWithOnebattry[6] = love.graphics.newImage('4.0b.png')
self.playerMovingRightWithOnebattry[7] = love.graphics.newImage('4.1b.png')
self.playerMovingRightWithOnebattry[8] = love.graphics.newImage('5b.png')
self.playerMovingRightWithOnebattry[9] = love.graphics.newImage('6b.png')
self.playerMovingRightWithOnebattry[10] = love.graphics.newImage('7b.png')
self.playerMovingRightWithOnebattry[11] = love.graphics.newImage('8b.png')
self.playerMovingRightWithOnebattry[12] = love.graphics.newImage('9b.png')


self.bools_to_help_loading[19] = true 
self.bools_to_help_loading[20] = false


elseif self.bools_to_help_loading[20] == false then

self.playerMovingLeft = {}
self.playerMovingLeft[1] = love.graphics.newImage('l0.png')
self.playerMovingLeft[2] = love.graphics.newImage('l1.1.png')
self.playerMovingLeft[3] = love.graphics.newImage('l1.png')
self.playerMovingLeft[4] = love.graphics.newImage('l2.png')
self.playerMovingLeft[5] = love.graphics.newImage('l3.png')
self.playerMovingLeft[6] = love.graphics.newImage('l4.png')
self.playerMovingLeft[7] = love.graphics.newImage('l5.png')
self.playerMovingLeft[8] = love.graphics.newImage('l6.png')
self.playerMovingLeft[9] = love.graphics.newImage('l7.png')
self.playerMovingLeft[10] = love.graphics.newImage('l8.png')
self.playerMovingLeft[11] = love.graphics.newImage('l9.png')
self.playerMovingLeft[12] = love.graphics.newImage('l10.png')



self.bools_to_help_loading[20] = true 
self.bools_to_help_loading[21] = false


--elseif self.bools_to_help_loading[21] == false then

self.playerMovingLeftWithTwobattry = {}
self.playerMovingLeftWithTwobattry[1] = love.graphics.newImage('l0bb.png')
self.playerMovingLeftWithTwobattry[2] = love.graphics.newImage('l1.1bb.png')
self.playerMovingLeftWithTwobattry[3] = love.graphics.newImage('l1bb.png')
self.playerMovingLeftWithTwobattry[4] = love.graphics.newImage('l2bb.png')
self.playerMovingLeftWithTwobattry[5] = love.graphics.newImage('l3bb.png')
self.playerMovingLeftWithTwobattry[6] = love.graphics.newImage('l4bb.png')
self.playerMovingLeftWithTwobattry[7] = love.graphics.newImage('l5bb.png')
self.playerMovingLeftWithTwobattry[8] = love.graphics.newImage('l6bb.png')
self.playerMovingLeftWithTwobattry[9] = love.graphics.newImage('l7bb.png')
self.playerMovingLeftWithTwobattry[10] = love.graphics.newImage('l8bb.png')
self.playerMovingLeftWithTwobattry[11] = love.graphics.newImage('l9bb.png')
self.playerMovingLeftWithTwobattry[12] = love.graphics.newImage('l10bb.png')



self.bools_to_help_loading[21] = true 
self.bools_to_help_loading[22] = false


elseif self.bools_to_help_loading[22] == false then

self.playerMovingLeftWithOnebattry = {}
self.playerMovingLeftWithOnebattry[1] = love.graphics.newImage('l0b.png')
self.playerMovingLeftWithOnebattry[2] = love.graphics.newImage('l1.1b.png')
self.playerMovingLeftWithOnebattry[3] = love.graphics.newImage('l1b.png')
self.playerMovingLeftWithOnebattry[4] = love.graphics.newImage('l2b.png')
self.playerMovingLeftWithOnebattry[5] = love.graphics.newImage('l3b.png')
self.playerMovingLeftWithOnebattry[6] = love.graphics.newImage('l4b.png')
self.playerMovingLeftWithOnebattry[7] = love.graphics.newImage('l5b.png')
self.playerMovingLeftWithOnebattry[8] = love.graphics.newImage('l6b.png')
self.playerMovingLeftWithOnebattry[9] = love.graphics.newImage('l7b.png')
self.playerMovingLeftWithOnebattry[10] = love.graphics.newImage('l8b.png')
self.playerMovingLeftWithOnebattry[11] = love.graphics.newImage('l9b.png')
self.playerMovingLeftWithOnebattry[12] = love.graphics.newImage('l10b.png')




self.bools_to_help_loading[22] = true 
self.bools_to_help_loading[23] = false

--
elseif self.bools_to_help_loading[23] == false then

self.enemys_changeforpicture1 = love.graphics.newImage('crowenemy1.png')
self.enemys_changeforpicture2 = love.graphics.newImage('crowenemynumber2_1.png')
self.enemys_changeforpicture3 = love.graphics.newImage('crowenemynumber3_1.png')



self.enemys_helicoopter = {}
self.enemys_helicoopter[1] = love.graphics.newImage('crowenemy1.png')
self.enemys_helicoopter[2] = love.graphics.newImage('crowenemy2.png')
self.enemys_helicoopter[3] = love.graphics.newImage('crowenemy3.png')
self.enemys_helicoopter[4] = love.graphics.newImage('crowenemy4.png')
self.enemys_helicoopter[5] = love.graphics.newImage('crowenemynumber2_1.png')
self.enemys_helicoopter[6] = love.graphics.newImage('crowenemynumber2_2.png')
self.enemys_helicoopter[7] = love.graphics.newImage('crowenemynumber2_3.png')
self.enemys_helicoopter[8] = love.graphics.newImage('crowenemynumber2_4.png')


self.bools_to_help_loading[23] = true 
self.bools_to_help_loading[24] = false


elseif self.bools_to_help_loading[24] == false then


self.enemys_helicoopter[9] = love.graphics.newImage('crowenemynumber3_1.png')
self.enemys_helicoopter[10] = love.graphics.newImage('crowenemynumber3_2.png')
self.enemys_helicoopter[11] = love.graphics.newImage('crowenemynumber3_3.png')
self.enemys_helicoopter[12] = love.graphics.newImage('crowenemynumber3_4.png')



self.CROWENEMY_SHOOT = love.graphics.newImage('crowenemy_shoot.png')
self.CROWENEMY_DIE = love.graphics.newImage('crowenemy_die.png')

self.CROWENEMYNUMBER2_SHOOT = love.graphics.newImage('crowenemynumber2_shoot.png')
self.CROWENEMYNUMBER2_DIE = love.graphics.newImage('crowenemynumber2_die.png')

self.CROWENEMYNUMBER3_SHOOT = love.graphics.newImage('crowenemynumber3_shoot.png')
self.CROWENEMYNUMBER3_DIE = love.graphics.newImage('crowenemynumber3_die.png')


self.bools_to_help_loading[24] = true 
self.bools_to_help_loading[25] = false


--elseif self.bools_to_help_loading[25] == false then

self.bulletE1 = love.graphics.newImage('bullet_ee1.png')
self.bulletE2 = love.graphics.newImage('bullet_ee2.png')
self.bulletE3 = love.graphics.newImage('bullet_ee3.png')


self.boss_BULLET_IMG = love.graphics.newImage('boss_bullet.png')
self.boss_BULLET_IMGS = {}
self.boss_BULLET_IMGS[1] = love.graphics.newImage('boss_bullet.png')
self.boss_BULLET_IMGS[2] = love.graphics.newImage('boss_bullet1.png')
self.boss_BULLET_IMGS[3] = love.graphics.newImage('boss_bullet2.png')
self.boss_BULLET_IMGS[4] = love.graphics.newImage('boss_bullet3.png')
self.boss_BULLET_IMGS[5] = love.graphics.newImage('boss_bullet4.png')
self.boss_BULLET_IMGS[6] = love.graphics.newImage('boss_bullet5.png')
self.boss_BULLET_IMGS[7] = love.graphics.newImage('boss_bullet6.png')
self.boss_BULLET_IMGS[8] = love.graphics.newImage('boss_bullet7.png')


self.bools_to_help_loading[25] = true 
self.bools_to_help_loading[26] = false



elseif self.bools_to_help_loading[26] == false then

self.boss_BULLET_IMGS[9] = love.graphics.newImage('boss_bullet8.png')
self.boss_BULLET_IMGS[10] = love.graphics.newImage('boss_bullet9.png')
self.boss_BULLET_IMGS[11] = love.graphics.newImage('boss_bullet10.png')
self.boss_BULLET_IMGS[12] = love.graphics.newImage('boss_bullet11.png')
self.boss_BULLET_IMGS[13] = love.graphics.newImage('boss_bullet12.png')
self.boss_BULLET_IMGS[14] = love.graphics.newImage('boss_bullet13.png')


self.bools_to_help_loading[26] = true 
self.bools_to_help_loading[27] = false


--elseif self.bools_to_help_loading[27] == false then



self.boss_BOSSIMAGES = { BOSS_ATTACK = {} , BOSS_GETHIT = {} , BOSS_WAIT = {} }
self.boss_BOSSIMAGES.BOSS_ATTACK[1] = love.graphics.newImage('boss_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[2] = love.graphics.newImage('boss1_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[3] = love.graphics.newImage('boss2_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[4] = love.graphics.newImage('boss3_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[5] = love.graphics.newImage('boss4_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[6] = love.graphics.newImage('boss5_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[7] = love.graphics.newImage('boss6_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[8] = love.graphics.newImage('boss7_attack.png')


self.bools_to_help_loading[27] = true 
self.bools_to_help_loading[28] = false


elseif self.bools_to_help_loading[28] == false then

self.boss_BOSSIMAGES.BOSS_ATTACK[9] = love.graphics.newImage('boss8_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[10] = love.graphics.newImage('boss9_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[11] = love.graphics.newImage('boss10_attack.png')
self.boss_BOSSIMAGES.BOSS_ATTACK[12] = love.graphics.newImage('boss11_attack.png')

self.bools_to_help_loading[28] = true 
self.bools_to_help_loading[29] = false

elseif self.bools_to_help_loading[29] == false then

self.BOSS_WALKING = {}
self.BOSS_WALKING[1] = love.graphics.newImage('boss_walking.png')
self.BOSS_WALKING[2] = love.graphics.newImage('boss1_walking.png')
self.BOSS_WALKING[3] = love.graphics.newImage('boss2_walking.png')
self.BOSS_WALKING[4] = love.graphics.newImage('boss3_walking.png')
self.BOSS_WALKING[5] = love.graphics.newImage('boss4_walking.png')
self.BOSS_WALKING[6] = love.graphics.newImage('boss5_walking.png')
self.BOSS_WALKING[7] = love.graphics.newImage('boss6_walking.png')
self.BOSS_WALKING[8] = love.graphics.newImage('boss7_walking.png')
self.BOSS_WALKING[9] = love.graphics.newImage('boss8_walking.png')
self.BOSS_WALKING[10] = love.graphics.newImage('boss9_walking.png')
self.BOSS_WALKING[11] = love.graphics.newImage('boss10_walking.png')
self.BOSS_WALKING[12] = love.graphics.newImage('boss11_walking.png')



self.bools_to_help_loading[29] = true 
self.bools_to_help_loading[30] = false

elseif self.bools_to_help_loading[30] == false then

self.boss_BOSSIMAGES.BOSS_WAIT[1] = love.graphics.newImage('boss.png')
self.boss_BOSSIMAGES.BOSS_WAIT[2] = love.graphics.newImage('boss1.png')
self.boss_BOSSIMAGES.BOSS_WAIT[3] = love.graphics.newImage('boss2.png')
self.boss_BOSSIMAGES.BOSS_WAIT[4] = love.graphics.newImage('boss3.png')
self.boss_BOSSIMAGES.BOSS_WAIT[5] = love.graphics.newImage('boss4.png')
self.boss_BOSSIMAGES.BOSS_WAIT[6] = love.graphics.newImage('boss6.png')
self.boss_BOSSIMAGES.BOSS_WAIT[7] = love.graphics.newImage('boss7.png')
self.boss_BOSSIMAGES.BOSS_WAIT[8] = love.graphics.newImage('boss8.png')
self.boss_BOSSIMAGES.BOSS_WAIT[9] = love.graphics.newImage('boss9.png')
self.boss_BOSSIMAGES.BOSS_WAIT[10] = love.graphics.newImage('boss10.png')
self.boss_BOSSIMAGES.BOSS_WAIT[11] = love.graphics.newImage('boss11.png')


self.bools_to_help_loading[30] = true 
self.bools_to_help_loading[31] = false


--elseif self.bools_to_help_loading[31] == false then

self.boss_BOSSIMAGES.BOSS_GETHIT[1] = love.graphics.newImage('boss_shouldgethit.png')
self.boss_BOSSIMAGES.BOSS_GETHIT[2] = love.graphics.newImage('boss1_shouldgethit.png')

self.BBullet = love.graphics.newImage('bbullet.png')
self.BOSS_DEAD = love.graphics.newImage('boss_dead.png')

self.boss2_BULLET_IMGS = {}
self.boss2_BULLET_IMG = love.graphics.newImage('boss_bullet.png')
self.boss2_BULLET_IMGS[1] = love.graphics.newImage('boss2_bullet (1).png')
self.boss2_BULLET_IMGS[2] = love.graphics.newImage('boss2_bullet (2).png')
self.boss2_BULLET_IMGS[3] = love.graphics.newImage('boss2_bullet (3).png')
self.boss2_BULLET_IMGS[4] = love.graphics.newImage('boss2_bullet (4).png')

self.bools_to_help_loading[31] = true 
self.bools_to_help_loading[32] = false


elseif self.bools_to_help_loading[32] == false then

self.JAG = love.graphics.newImage('jag.png')
self.JAG_NOT = love.graphics.newImage('jag_not.png')
self.boss2_BOSSIMAGES = { BOSS_ATTACK = {} , BOSS_GETHIT = {} , BOSS_WAIT = {} }
self.boss2_BOSSIMAGES.BOSS_ATTACK[1] = love.graphics.newImage('boss_attack (1).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[2] = love.graphics.newImage('boss_attack (2).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[3] = love.graphics.newImage('boss_attack (3).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[4] = love.graphics.newImage('boss_attack (4).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[5] = love.graphics.newImage('boss_attack (5).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[6] = love.graphics.newImage('boss_attack (6).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[7] = love.graphics.newImage('boss_attack (7).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[8] = love.graphics.newImage('boss_attack (8).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[9] = love.graphics.newImage('boss_attack (9).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[10] = love.graphics.newImage('boss_attack (10).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[11] = love.graphics.newImage('boss_attack (11).png')


self.bools_to_help_loading[32] = true 
self.bools_to_help_loading[33] = false

--
elseif self.bools_to_help_loading[33] == false then

self.boss2_BOSSIMAGES.BOSS_ATTACK[12] = love.graphics.newImage('boss_attack (12).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[13] = love.graphics.newImage('boss_attack (13).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[14] = love.graphics.newImage('boss_attack (14).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[15] = love.graphics.newImage('boss_attack (15).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[16] = love.graphics.newImage('boss_attack (16).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[17] = love.graphics.newImage('boss_attack (17).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[18] = love.graphics.newImage('boss_attack (18).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[19] = love.graphics.newImage('boss_attack (19).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[20] = love.graphics.newImage('boss_attack (20).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[21] = love.graphics.newImage('boss_attack (21).png')


self.bools_to_help_loading[33] = true 
self.bools_to_help_loading[34] = false


elseif self.bools_to_help_loading[34] == false then

self.boss2_BOSSIMAGES.BOSS_ATTACK[22] = love.graphics.newImage('boss_attack (22).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[23] = love.graphics.newImage('boss_attack (23).png')
self.boss2_BOSSIMAGES.BOSS_ATTACK[24] = love.graphics.newImage('boss_attack (24).png')


self.bools_to_help_loading[34] = true 
self.bools_to_help_loading[35] = false


--elseif self.bools_to_help_loading[35] == false then


self.bools_to_help_loading[35] = true 
self.bools_to_help_loading[36] = false



elseif self.bools_to_help_loading[36] == false then


self.BOSS2_WALKING = {}
self.BOSS2_WALKING[1] = love.graphics.newImage('boss2_walk (1).png')
self.BOSS2_WALKING[2] = love.graphics.newImage('boss2_walk (2).png')
self.BOSS2_WALKING[3] = love.graphics.newImage('boss2_walk (3).png')
self.BOSS2_WALKING[4] = love.graphics.newImage('boss2_walk (4).png')
self.BOSS2_WALKING[5] = love.graphics.newImage('boss2_walk (5).png')
self.BOSS2_WALKING[6] = love.graphics.newImage('boss2_walk (6).png')
self.BOSS2_WALKING[7] = love.graphics.newImage('boss2_walk (7).png')

self.bools_to_help_loading[36] = true 
self.bools_to_help_loading[37] = false


--elseif self.bools_to_help_loading[37] == false then

self.boss2_BOSSIMAGES.BOSS_WAIT[1] = love.graphics.newImage('boss2_jumping (1).png')
self.boss2_BOSSIMAGES.BOSS_WAIT[2] = love.graphics.newImage('boss2_jumping (2).png')
self.boss2_BOSSIMAGES.BOSS_WAIT[3] = love.graphics.newImage('boss2_jumping (3).png')
self.boss2_BOSSIMAGES.BOSS_WAIT[4] = love.graphics.newImage('boss2_jumping (4).png')


self.bools_to_help_loading[37] = true 
self.bools_to_help_loading[38] = false


elseif self.bools_to_help_loading[38] == false then

self.boss2_BOSSIMAGES.BOSS_WAIT[5] = love.graphics.newImage('boss2_jumping (5).png')
self.boss2_BOSSIMAGES.BOSS_WAIT[6] = love.graphics.newImage('boss2_jumping (6).png')
self.boss2_BOSSIMAGES.BOSS_WAIT[7] = love.graphics.newImage('boss2_jumping (7).png')
self.boss2_BOSSIMAGES.BOSS_WAIT[8] = love.graphics.newImage('boss2_jumping (8).png')
self.boss2_BOSSIMAGES.BOSS_WAIT[9] = love.graphics.newImage('boss2_jumping (9).png')
self.boss2_BOSSIMAGES.BOSS_WAIT[10] = love.graphics.newImage('boss2_jumping (10).png')


self.bools_to_help_loading[38] = true 
self.bools_to_help_loading[39] = false

elseif self.bools_to_help_loading[39] == false then

self.boss2_BOSSIMAGES.BOSS_GETHIT[1] = love.graphics.newImage('boss2_wait1.png')
self.boss2_BOSSIMAGES.BOSS_GETHIT[2] = love.graphics.newImage('boss2_wait2.png')
self.boss2_BOSSIMAGES.BOSS_GETHIT[3] = love.graphics.newImage('boss2_wait3.png')
self.boss2_BOSSIMAGES.BOSS_GETHIT[4] = love.graphics.newImage('boss2_wait4.png')

self.BBullet = love.graphics.newImage('bbullet.png')


self.bools_to_help_loading[39] = true 
self.bools_to_help_loading[40] = false


elseif self.bools_to_help_loading[40] == false then

self.BOSS2_DEAD = love.graphics.newImage('boss2_wait4.png')

self.boss3_BULLET_IMGS = {}
self.boss3_BULLET_IMG = love.graphics.newImage('boss3_to_fire_bullet (1).png')

self.boss3_BULLET_IMGS[1] = love.graphics.newImage('boss3_to_fire_bullet (1).png')
self.boss3_BULLET_IMGS[2] = love.graphics.newImage('boss3_to_fire_bullet (2).png')
self.boss3_BULLET_IMGS[3] = love.graphics.newImage('boss3_to_fire_bullet (3).png')
self.boss3_BULLET_IMGS[4] = love.graphics.newImage('boss3_to_fire_bullet (4).png')
self.boss3_BULLET_IMGS[5] = love.graphics.newImage('boss3_to_fire_bullet (5).png')
self.boss3_BULLET_IMGS[6] = love.graphics.newImage('boss3_to_fire_bullet (6).png')
self.boss3_BULLET_IMGS[7] = love.graphics.newImage('boss3_to_fire_bullet (7).png')
self.boss3_BULLET_IMGS[8] = love.graphics.newImage('boss3_to_fire_bullet (8).png')
self.boss3_BULLET_IMGS[9] = love.graphics.newImage('boss3_to_fire_bullet (9).png')


self.bools_to_help_loading[40] = true 
self.bools_to_help_loading[41] = false


--elseif self.bools_to_help_loading[41] == false then

self.boss3_BULLET_IMGS[10] = love.graphics.newImage('boss3_to_fire_bullet (10).png')
self.boss3_BULLET_IMGS[11] = love.graphics.newImage('boss3_to_fire_bullet (11).png')
self.boss3_BULLET_IMGS[12] = love.graphics.newImage('boss3_to_fire_bullet (12).png')
self.boss3_BULLET_IMGS[13] = love.graphics.newImage('boss3_to_fire_bullet (13).png')
self.boss3_BULLET_IMGS[14] = love.graphics.newImage('boss3_to_fire_bullet (14).png')
self.boss3_BULLET_IMGS[15] = love.graphics.newImage('boss3_to_fire_bullet (15).png')
self.boss3_BULLET_IMGS[16] = love.graphics.newImage('boss3_to_fire_bullet (16).png')
self.boss3_BULLET_IMGS[17] = love.graphics.newImage('boss3_to_fire_bullet (17).png')


self.bools_to_help_loading[41] = true 
self.bools_to_help_loading[42] = false


elseif self.bools_to_help_loading[42] == false then


self.bools_to_help_loading[42] = true 
self.bools_to_help_loading[43] = false

--
elseif self.bools_to_help_loading[43] == false then

self.boss3_BULLET1_IMGS = {}
self.boss3_BULLET1_IMG = love.graphics.newImage('boss3_to_creep_bullet (1).png')

self.boss3_BULLET1_IMGS[1] = love.graphics.newImage('boss3_to_creep_bullet (1).png')
self.boss3_BULLET1_IMGS[2] = love.graphics.newImage('boss3_to_creep_bullet (2).png')
self.boss3_BULLET1_IMGS[3] = love.graphics.newImage('boss3_to_creep_bullet (3).png')
self.boss3_BULLET1_IMGS[4] = love.graphics.newImage('boss3_to_creep_bullet (4).png')
self.boss3_BULLET1_IMGS[5] = love.graphics.newImage('boss3_to_creep_bullet (5).png')
self.boss3_BULLET1_IMGS[6] = love.graphics.newImage('boss3_to_creep_bullet (6).png')

self.boss3_BULLET1_2IMGS = {}
self.boss3_BULLET1_2IMG = love.graphics.newImage('boss3_to_creep_bullet_goingright (1).png')


self.bools_to_help_loading[43] = true 
self.bools_to_help_loading[44] = false


elseif self.bools_to_help_loading[44] == false then

self.boss3_BULLET1_2IMGS[1] = love.graphics.newImage('boss3_to_creep_bullet_goingright (1).png')
self.boss3_BULLET1_2IMGS[2] = love.graphics.newImage('boss3_to_creep_bullet_goingright (2).png')
self.boss3_BULLET1_2IMGS[3] = love.graphics.newImage('boss3_to_creep_bullet_goingright (3).png')
self.boss3_BULLET1_2IMGS[4] = love.graphics.newImage('boss3_to_creep_bullet_goingright (4).png')
self.boss3_BULLET1_2IMGS[5] = love.graphics.newImage('boss3_to_creep_bullet_goingright (5).png')
self.boss3_BULLET1_2IMGS[6] = love.graphics.newImage('boss3_to_creep_bullet_goingright (6).png')


self.boss3_BULLET2_IMGS = {}
self.boss3_BULLET2_IMG = love.graphics.newImage('boss3_to_glad_bullet (1).png')

self.boss3_BULLET2_IMGS[1] = love.graphics.newImage('boss3_to_glad_bullet (1).png')
self.boss3_BULLET2_IMGS[2] = love.graphics.newImage('boss3_to_glad_bullet (2).png')
self.boss3_BULLET2_IMGS[3] = love.graphics.newImage('boss3_to_glad_bullet (3).png')


self.bools_to_help_loading[44] = true 
self.bools_to_help_loading[45] = false


--elseif self.bools_to_help_loading[45] == false then

self.boss3_BULLET2_IMGS[4] = love.graphics.newImage('boss3_to_glad_bullet (4).png')


self.boss3_BOSSIMAGES = { BOSS_GETHIT = {} , BOSS3_TO_LIGHT = {} , BOSS3_TO_FIRE = {} , BOSS3_TO_GLAD = {} , BOSS3_TO_GOUL = {} , BOSS3_TO_SKEL = {} , BOSS3_TO_CREEP = {} }

self.boss3_BOSSIMAGES.BOSS_GETHIT[1] = love.graphics.newImage('boss3_wait (1).png')
self.boss3_BOSSIMAGES.BOSS_GETHIT[2] = love.graphics.newImage('boss3_wait (2).png')
self.boss3_BOSSIMAGES.BOSS_GETHIT[3] = love.graphics.newImage('boss3_wait (3).png')
self.boss3_BOSSIMAGES.BOSS_GETHIT[4] = love.graphics.newImage('boss3_wait (4).png')
self.boss3_BOSSIMAGES.BOSS_GETHIT[5] = love.graphics.newImage('boss3_wait (5).png')


self.bools_to_help_loading[45] = true 
self.bools_to_help_loading[46] = false



elseif self.bools_to_help_loading[46] == false then

self.boss3_BOSSIMAGES.BOSS_GETHIT[6] = love.graphics.newImage('boss3_wait (6).png')
self.boss3_BOSSIMAGES.BOSS_GETHIT[7] = love.graphics.newImage('boss3_wait (7).png')
self.boss3_BOSSIMAGES.BOSS_GETHIT[8] = love.graphics.newImage('boss3_wait (8).png')


self.bools_to_help_loading[46] = true 
self.bools_to_help_loading[47] = false


--elseif self.bools_to_help_loading[47] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_LIGHT[1] = love.graphics.newImage('boss3_to_light (1).png')
self.boss3_BOSSIMAGES.BOSS3_TO_LIGHT[2] = love.graphics.newImage('boss3_to_light (2).png')
self.boss3_BOSSIMAGES.BOSS3_TO_LIGHT[3] = love.graphics.newImage('boss3_to_light (3).png')
self.boss3_BOSSIMAGES.BOSS3_TO_LIGHT[4] = love.graphics.newImage('boss3_to_light (4).png')

self.bools_to_help_loading[47] = true 
self.bools_to_help_loading[48] = false


elseif self.bools_to_help_loading[48] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[1] = love.graphics.newImage('boss3_to_fire (1).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[2] = love.graphics.newImage('boss3_to_fire (2).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[3] = love.graphics.newImage('boss3_to_fire (3).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[4] = love.graphics.newImage('boss3_to_fire (4).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[5] = love.graphics.newImage('boss3_to_fire (5).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[6] = love.graphics.newImage('boss3_to_fire (6).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[7] = love.graphics.newImage('boss3_to_fire (7).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[8] = love.graphics.newImage('boss3_to_fire (8).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[9] = love.graphics.newImage('boss3_to_fire (9).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[10] = love.graphics.newImage('boss3_to_fire (10).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[11] = love.graphics.newImage('boss3_to_fire (11).png')


self.bools_to_help_loading[48] = true 
self.bools_to_help_loading[49] = false

elseif self.bools_to_help_loading[49] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[12] = love.graphics.newImage('boss3_to_fire (12).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[13] = love.graphics.newImage('boss3_to_fire (13).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[14] = love.graphics.newImage('boss3_to_fire (14).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[15] = love.graphics.newImage('boss3_to_fire (15).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[16] = love.graphics.newImage('boss3_to_fire (16).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[17] = love.graphics.newImage('boss3_to_fire (17).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[18] = love.graphics.newImage('boss3_to_fire (18).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[19] = love.graphics.newImage('boss3_to_fire (19).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[20] = love.graphics.newImage('boss3_to_fire (20).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[21] = love.graphics.newImage('boss3_to_fire (21).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[22] = love.graphics.newImage('boss3_to_fire (22).png')


self.bools_to_help_loading[49] = true 
self.bools_to_help_loading[50] = false


--elseif self.bools_to_help_loading[51] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[23] = love.graphics.newImage('boss3_to_fire (23).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[24] = love.graphics.newImage('boss3_to_fire (24).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[25] = love.graphics.newImage('boss3_to_fire (25).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[26] = love.graphics.newImage('boss3_to_fire (26).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[27] = love.graphics.newImage('boss3_to_fire (27).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[28] = love.graphics.newImage('boss3_to_fire (28).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[29] = love.graphics.newImage('boss3_to_fire (29).png')
self.boss3_BOSSIMAGES.BOSS3_TO_FIRE[30] = love.graphics.newImage('boss3_to_fire (30).png')

self.bools_to_help_loading[51] = true 
self.bools_to_help_loading[52] = false



elseif self.bools_to_help_loading[52] == false then

self.bools_to_help_loading[52] = true 
self.bools_to_help_loading[53] = false

--
elseif self.bools_to_help_loading[53] == false then


self.bools_to_help_loading[53] = true 
self.bools_to_help_loading[54] = false


elseif self.bools_to_help_loading[54] == false then



self.bools_to_help_loading[54] = true 
self.bools_to_help_loading[55] = false


--elseif self.bools_to_help_loading[55] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[1] = love.graphics.newImage('boss3_to_glad (1).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[2] = love.graphics.newImage('boss3_to_glad (2).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[3] = love.graphics.newImage('boss3_to_glad (3).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[4] = love.graphics.newImage('boss3_to_glad (4).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[5] = love.graphics.newImage('boss3_to_glad (5).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[6] = love.graphics.newImage('boss3_to_glad (6).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[7] = love.graphics.newImage('boss3_to_glad (7).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[8] = love.graphics.newImage('boss3_to_glad (8).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[9] = love.graphics.newImage('boss3_to_glad (9).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[10] = love.graphics.newImage('boss3_to_glad (10).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[11] = love.graphics.newImage('boss3_to_glad (11).png')


self.bools_to_help_loading[55] = true 
self.bools_to_help_loading[56] = false


elseif self.bools_to_help_loading[56] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[12] = love.graphics.newImage('boss3_to_glad (12).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[13] = love.graphics.newImage('boss3_to_glad (13).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[14] = love.graphics.newImage('boss3_to_glad (14).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[15] = love.graphics.newImage('boss3_to_glad (15).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[16] = love.graphics.newImage('boss3_to_glad (16).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[17] = love.graphics.newImage('boss3_to_glad (17).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[18] = love.graphics.newImage('boss3_to_glad (18).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[19] = love.graphics.newImage('boss3_to_glad (19).png')


self.bools_to_help_loading[56] = true 
self.bools_to_help_loading[57] = false


--elseif self.bools_to_help_loading[57] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[20] = love.graphics.newImage('boss3_to_glad (20).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[21] = love.graphics.newImage('boss3_to_glad (21).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[22] = love.graphics.newImage('boss3_to_glad (22).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[23] = love.graphics.newImage('boss3_to_glad (23).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[24] = love.graphics.newImage('boss3_to_glad (24).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[25] = love.graphics.newImage('boss3_to_glad (25).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[26] = love.graphics.newImage('boss3_to_glad (26).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[27] = love.graphics.newImage('boss3_to_glad (27).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[28] = love.graphics.newImage('boss3_to_glad (28).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[29] = love.graphics.newImage('boss3_to_glad (29).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[30] = love.graphics.newImage('boss3_to_glad (30).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[31] = love.graphics.newImage('boss3_to_glad (31).png')


self.bools_to_help_loading[57] = true 
self.bools_to_help_loading[58] = false


elseif self.bools_to_help_loading[58] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[32] = love.graphics.newImage('boss3_to_glad (32).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[33] = love.graphics.newImage('boss3_to_glad (33).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[34] = love.graphics.newImage('boss3_to_glad (34).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GLAD[35] = love.graphics.newImage('boss3_to_glad (35).png')


self.bools_to_help_loading[58] = true 
self.bools_to_help_loading[59] = false

elseif self.bools_to_help_loading[59] == false then



self.bools_to_help_loading[59] = true 
self.bools_to_help_loading[60] = false

elseif self.bools_to_help_loading[60] == false then



self.bools_to_help_loading[60] = true 
self.bools_to_help_loading[61] = false


--elseif self.bools_to_help_loading[61] == false then


self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[1] = love.graphics.newImage('boss3_to_goul (1).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[2] = love.graphics.newImage('boss3_to_goul (2).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[3] = love.graphics.newImage('boss3_to_goul (3).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[4] = love.graphics.newImage('boss3_to_goul (4).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[5] = love.graphics.newImage('boss3_to_goul (5).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[6] = love.graphics.newImage('boss3_to_goul (6).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[7] = love.graphics.newImage('boss3_to_goul (7).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[8] = love.graphics.newImage('boss3_to_goul (8).png')


self.bools_to_help_loading[61] = true 
self.bools_to_help_loading[62] = false



elseif self.bools_to_help_loading[62] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[9] = love.graphics.newImage('boss3_to_goul (9).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[10] = love.graphics.newImage('boss3_to_goul (10).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[11] = love.graphics.newImage('boss3_to_goul (11).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[12] = love.graphics.newImage('boss3_to_goul (12).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[13] = love.graphics.newImage('boss3_to_goul (13).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[14] = love.graphics.newImage('boss3_to_goul (14).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[15] = love.graphics.newImage('boss3_to_goul (15).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[16] = love.graphics.newImage('boss3_to_goul (16).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[17] = love.graphics.newImage('boss3_to_goul (17).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[18] = love.graphics.newImage('boss3_to_goul (18).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[19] = love.graphics.newImage('boss3_to_goul (19).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[20] = love.graphics.newImage('boss3_to_goul (20).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[21] = love.graphics.newImage('boss3_to_goul (21).png')


self.bools_to_help_loading[62] = true 
self.bools_to_help_loading[63] = false

--
elseif self.bools_to_help_loading[63] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[22] = love.graphics.newImage('boss3_to_goul (22).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[23] = love.graphics.newImage('boss3_to_goul (23).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[24] = love.graphics.newImage('boss3_to_goul (24).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[25] = love.graphics.newImage('boss3_to_goul (25).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[26] = love.graphics.newImage('boss3_to_goul (26).png')
self.boss3_BOSSIMAGES.BOSS3_TO_GOUL[27] = love.graphics.newImage('boss3_to_goul (27).png')


self.bools_to_help_loading[63] = true 
self.bools_to_help_loading[64] = false


elseif self.bools_to_help_loading[64] == false then


self.bools_to_help_loading[64] = true 
self.bools_to_help_loading[65] = false


--elseif self.bools_to_help_loading[65] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[1] = love.graphics.newImage('boss3_to_skel (1).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[2] = love.graphics.newImage('boss3_to_skel (2).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[3] = love.graphics.newImage('boss3_to_skel (3).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[4] = love.graphics.newImage('boss3_to_skel (4).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[5] = love.graphics.newImage('boss3_to_skel (5).png')


self.bools_to_help_loading[65] = true 
self.bools_to_help_loading[66] = false


elseif self.bools_to_help_loading[66] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[6] = love.graphics.newImage('boss3_to_skel (6).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[7] = love.graphics.newImage('boss3_to_skel (7).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[8] = love.graphics.newImage('boss3_to_skel (8).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[9] = love.graphics.newImage('boss3_to_skel (9).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[10] = love.graphics.newImage('boss3_to_skel (10).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[11] = love.graphics.newImage('boss3_to_skel (11).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[12] = love.graphics.newImage('boss3_to_skel (12).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[13] = love.graphics.newImage('boss3_to_skel (13).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[14] = love.graphics.newImage('boss3_to_skel (14).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[15] = love.graphics.newImage('boss3_to_skel (15).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[16] = love.graphics.newImage('boss3_to_skel (16).png')


self.bools_to_help_loading[66] = true 
self.bools_to_help_loading[67] = false


--elseif self.bools_to_help_loading[67] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[17] = love.graphics.newImage('boss3_to_skel (17).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[18] = love.graphics.newImage('boss3_to_skel (18).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[19] = love.graphics.newImage('boss3_to_skel (19).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[20] = love.graphics.newImage('boss3_to_skel (20).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[21] = love.graphics.newImage('boss3_to_skel (21).png')
self.boss3_BOSSIMAGES.BOSS3_TO_SKEL[22] = love.graphics.newImage('boss3_to_skel (22).png')


self.bools_to_help_loading[67] = true 
self.bools_to_help_loading[68] = false


elseif self.bools_to_help_loading[68] == false then



self.bools_to_help_loading[68] = true 
self.bools_to_help_loading[69] = false

elseif self.bools_to_help_loading[69] == false then


self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[1] = love.graphics.newImage('boss3_to_creep (1).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[2] = love.graphics.newImage('boss3_to_creep (2).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[3] = love.graphics.newImage('boss3_to_creep (3).png')


self.bools_to_help_loading[69] = true 
self.bools_to_help_loading[70] = false

elseif self.bools_to_help_loading[70] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[4] = love.graphics.newImage('boss3_to_creep (4).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[5] = love.graphics.newImage('boss3_to_creep (5).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[6] = love.graphics.newImage('boss3_to_creep (6).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[7] = love.graphics.newImage('boss3_to_creep (7).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[8] = love.graphics.newImage('boss3_to_creep (8).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[9] = love.graphics.newImage('boss3_to_creep (9).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[10] = love.graphics.newImage('boss3_to_creep (10).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[11] = love.graphics.newImage('boss3_to_creep (11).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[12] = love.graphics.newImage('boss3_to_creep (12).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[13] = love.graphics.newImage('boss3_to_creep (13).png')


self.bools_to_help_loading[70] = true 
self.bools_to_help_loading[71] = false


--elseif self.bools_to_help_loading[71] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[14] = love.graphics.newImage('boss3_to_creep (14).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[15] = love.graphics.newImage('boss3_to_creep (15).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[16] = love.graphics.newImage('boss3_to_creep (16).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[17] = love.graphics.newImage('boss3_to_creep (17).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[18] = love.graphics.newImage('boss3_to_creep (18).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[19] = love.graphics.newImage('boss3_to_creep (19).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[20] = love.graphics.newImage('boss3_to_creep (20).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[21] = love.graphics.newImage('boss3_to_creep (21).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[22] = love.graphics.newImage('boss3_to_creep (22).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[23] = love.graphics.newImage('boss3_to_creep (23).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[24] = love.graphics.newImage('boss3_to_creep (24).png')


self.bools_to_help_loading[71] = true 
self.bools_to_help_loading[72] = false


elseif self.bools_to_help_loading[72] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[25] = love.graphics.newImage('boss3_to_creep (25).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[26] = love.graphics.newImage('boss3_to_creep (26).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[27] = love.graphics.newImage('boss3_to_creep (27).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[28] = love.graphics.newImage('boss3_to_creep (28).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[29] = love.graphics.newImage('boss3_to_creep (29).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[30] = love.graphics.newImage('boss3_to_creep (30).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[31] = love.graphics.newImage('boss3_to_creep (31).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[32] = love.graphics.newImage('boss3_to_creep (32).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[33] = love.graphics.newImage('boss3_to_creep (33).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[34] = love.graphics.newImage('boss3_to_creep (34).png')
self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[35] = love.graphics.newImage('boss3_to_creep (35).png')


self.bools_to_help_loading[72] = true 
self.bools_to_help_loading[73] = false

--
elseif self.bools_to_help_loading[73] == false then

self.boss3_BOSSIMAGES.BOSS3_TO_CREEP[36] = love.graphics.newImage('boss3_to_creep (36).png')

self.bools_to_help_loading[73] = true 
self.bools_to_help_loading[74] = false


elseif self.bools_to_help_loading[74] == false then


self.bools_to_help_loading[74] = true 
self.bools_to_help_loading[75] = false


--elseif self.bools_to_help_loading[75] == false then


self.bools_to_help_loading[75] = true 
self.bools_to_help_loading[76] = false



elseif self.bools_to_help_loading[76] == false then

self.BOSS3_WALKING = {}
self.BOSS3_WALKING[1] = love.graphics.newImage('boss3_walk (1).png')
self.BOSS3_WALKING[2] = love.graphics.newImage('boss3_walk (2).png')
self.BOSS3_WALKING[3] = love.graphics.newImage('boss3_walk (3).png')
self.BOSS3_WALKING[4] = love.graphics.newImage('boss3_walk (4).png')
self.BOSS3_WALKING[5] = love.graphics.newImage('boss3_walk (5).png')
self.BOSS3_WALKING[6] = love.graphics.newImage('boss3_walk (6).png')
self.BOSS3_WALKING[7] = love.graphics.newImage('boss3_walk (7).png')


self.bools_to_help_loading[76] = true 
self.bools_to_help_loading[77] = false


--elseif self.bools_to_help_loading[77] == false then

self.BBullet = love.graphics.newImage('bbullet.png')
self.BOSS3_DEAD = love.graphics.newImage('boss3_dead.png')
self.BLOCKJUMPFORFIGHTINGBOSS = love.graphics.newImage('blockjumpforfightingboss.png')
self.headofmamouth = love.graphics.newImage('the-head-of-mamouth.png')
self.HEADOFMAMOUTH = {}
self.HEADOFMAMOUTH[1]  = love.graphics.newImage('the-head-of-mamouth.png')


self.bools_to_help_loading[77] = true 
self.bools_to_help_loading[78] = false


elseif self.bools_to_help_loading[78] == false then

self.HEADOFMAMOUTH[2]  = love.graphics.newImage('the-head-of-mamouth.png')
self.HEADOFMAMOUTH[3]  = love.graphics.newImage('the-head-of-mamouth1.png')
self.HEADOFMAMOUTH[4]  = love.graphics.newImage('the-head-of-mamouth2.png')
self.HEADOFMAMOUTH[5]  = love.graphics.newImage('the-head-of-mamouth3.png')
self.HEADOFMAMOUTH[6]  = love.graphics.newImage('the-head-of-mamouth4.png')

self.lightGun = love.graphics.newImage('lightgun.png') 
self.lightGunMovingLeft = love.graphics.newImage('lightgunmovingleft.png')
self.lightGunDucked = love.graphics.newImage('lightgunducked.png')

self.HAND_GUN = love.graphics.newImage('hand_gun.png')
self.HAND_GUN_MOVINGLEFT = love.graphics.newImage('hand_gun_movingleft.png')
self.HAND_GUN_DUCKED = love.graphics.newImage('hand_gun_ducked.png')


self.bools_to_help_loading[78] = true 
self.bools_to_help_loading[79] = false

elseif self.bools_to_help_loading[79] == false then

self.SHOT_GUN = love.graphics.newImage('shot_gun.png')
self.SHOT_GUN_MOVINGLEFT = love.graphics.newImage('shot_gun_movingleft.png')
self.SHOT_GUN_DUCKED = love.graphics.newImage('shot_gun_ducked.png')

self.heavyGun = love.graphics.newImage('heavygun.png')
self.heavyGunMovingLeft = love.graphics.newImage('heavygunmovingleft.png')
self.heavyGunDucked = love.graphics.newImage('heavygunducked.png')

self.LAZER_GUN = love.graphics.newImage('lazer_gun.png')
self.LAZER_GUN_MOVINGLEFT = love.graphics.newImage('lazer_gun_movingleft.png')
self.LAZER_GUN_DUCKED = love.graphics.newImage('lazer_gun_ducked.png')


self.bools_to_help_loading[79] = true 
self.bools_to_help_loading[80] = false

elseif self.bools_to_help_loading[80] == false then

self.FINAL_GUN = love.graphics.newImage('final_gun.png')
self.FINAL_GUN_MOVINGLEFT = love.graphics.newImage('final_gun_movingleft.png')
self.FINAL_GUN_DUCKED = love.graphics.newImage('final_gun_ducked.png')

self.player_guns_img  = love.graphics.newImage('lightgun.png')

self.NUMBER0 = love.graphics.newImage('number0.png')
self.NUMBER1 = love.graphics.newImage('number1.png')
self.NUMBER2 = love.graphics.newImage('number2.png')
self.NUMBER3 = love.graphics.newImage('number3.png')
self.NUMBER4 = love.graphics.newImage('number4.png')
self.NUMBER5 = love.graphics.newImage('number5.png')
self.NUMBER6 = love.graphics.newImage('number6.png')


self.bools_to_help_loading[80] = true 
self.bools_to_help_loading[81] = false


--elseif self.bools_to_help_loading[81] == false then

self.NUMBER7 = love.graphics.newImage('number7.png')
self.NUMBER8 = love.graphics.newImage('number8.png')
self.NUMBER9 = love.graphics.newImage('number9.png')

self.CLOCK = love.graphics.newImage('clock.png')
self.AMMO_BULLET_HANDGUN = love.graphics.newImage('ammo_bullet_handgun.png')
self.AMMO_BULLET_SHOT_GUN = love.graphics.newImage('ammo_bullet_shot_gun.png')
self.AMMO_BULLET_HEAVYGUN = love.graphics.newImage('ammo_bullet_heavygun.png')
self.AMMO_BULLET_LAZER_GUN = love.graphics.newImage('ammo_bullet_lazer_gun.png')
self.AMMO_BULLET = AMMO_BULLET_HANDGUN

self.Crow = {}
self.Crow[1] = love.graphics.newImage('crow1.png')
self.Crow[2] = love.graphics.newImage('crow2.png')


self.bools_to_help_loading[81] = true 
self.bools_to_help_loading[82] = false


elseif self.bools_to_help_loading[82] == false then


self.Crow[3] = love.graphics.newImage('crow3.png')
self.Crow[4] = love.graphics.newImage('crow4.png')
self.Crow[5] = love.graphics.newImage('crow5.png')


self.FLYINGBIRD = {}
self.FLYINGBIRD[1] = love.graphics.newImage('flyingbird1.png')
self.FLYINGBIRD[2] = love.graphics.newImage('flyingbird2.png')
self.FLYINGBIRD[3] = love.graphics.newImage('flyingbird3.png')
self.FLYINGBIRD[4] = love.graphics.newImage('flyingbird4.png')
self.FLYINGBIRD[5] = love.graphics.newImage('flyingbird5.png')
self.FLYINGBIRD[6] = love.graphics.newImage('flyingbird6.png')
self.FLYINGBIRD[7] = love.graphics.newImage('flyingbird7.png')
self.FLYINGBIRD[8] = love.graphics.newImage('flyingbird8.png')
self.FLYINGBIRD[9] = love.graphics.newImage('flyingbird9.png')


self.bools_to_help_loading[82] = true 
self.bools_to_help_loading[83] = false

--
elseif self.bools_to_help_loading[83] == false then


self.FLYINGBIRD[10] = love.graphics.newImage('flyingbird10.png')
self.FLYINGBIRD[11] = love.graphics.newImage('flyingbird11.png')


self.GRASS = {}
self.GRASS[1] = love.graphics.newImage('grass_real.png')
self.GRASS[2] = love.graphics.newImage('grass1_real.png')
self.GRASS[3] = love.graphics.newImage('grass2_real.png')
self.GRASS[4] = love.graphics.newImage('grass3_real.png')


self.bools_to_help_loading[83] = true 
self.bools_to_help_loading[84] = false


elseif self.bools_to_help_loading[84] == false then

self.GROUNDD = love.graphics.newImage('ground.png')
self.GROUNDD1 = love.graphics.newImage('ground1.png')


self.THERAIN = {}
self.THERAIN[1] = love.graphics.newImage('rain.png')
self.THERAIN[2] = love.graphics.newImage('rain1.png')
self.THERAIN[3] = love.graphics.newImage('rain2.png')
self.THERAIN[4] = love.graphics.newImage('rain3.png')
self.THERAIN[5] = love.graphics.newImage('rain4.png')
self.THERAIN[6] = love.graphics.newImage('rain5.png')
self.THERAIN[7] = love.graphics.newImage('rain6.png')
self.THERAIN[8] = love.graphics.newImage('rain7.png')


self.bools_to_help_loading[84] = true 
self.bools_to_help_loading[85] = false


--elseif self.bools_to_help_loading[85] == false then

self.THERAIN_RED = {}
self.THERAIN_RED[1] = love.graphics.newImage('rain_red(1).png')
self.THERAIN_RED[2] = love.graphics.newImage('rain_red(2).png')
self.THERAIN_RED[3] = love.graphics.newImage('rain_red(3).png')
self.THERAIN_RED[4] = love.graphics.newImage('rain_red(4).png')
self.THERAIN_RED[5] = love.graphics.newImage('rain_red(5).png')
self.THERAIN_RED[6] = love.graphics.newImage('rain_red(6).png')
self.THERAIN_RED[7] = love.graphics.newImage('rain_red(7).png')
self.THERAIN_RED[8] = love.graphics.newImage('rain_red(8).png')


self.bools_to_help_loading[85] = true 
self.bools_to_help_loading[86] = false



elseif self.bools_to_help_loading[86] == false then


self.THEWATER_DROP = {}
self.THEWATER_DROP[1] = love.graphics.newImage('water_drop.png')
self.THEWATER_DROP[2] = love.graphics.newImage('water_drop1.png')
self.THEWATER_DROP[3] = love.graphics.newImage('water_drop2.png')
self.THEWATER_DROP[4] = love.graphics.newImage('water_drop3.png')
self.THEWATER_DROP[5] = love.graphics.newImage('water_drop4.png')
self.THEWATER_DROP[6] = love.graphics.newImage('water_drop5.png')
self.THEWATER_DROP[7] = love.graphics.newImage('water_drop6.png')
self.THEWATER_DROP[8] = love.graphics.newImage('water_drop7.png')
self.THEWATER_DROP[9] = love.graphics.newImage('water_drop8.png')
self.THEWATER_DROP[10] = love.graphics.newImage('water_drop9.png')


self.bools_to_help_loading[86] = true 
self.bools_to_help_loading[87] = false


--elseif self.bools_to_help_loading[87] == false then

self.THEWATER_DROP[11] = love.graphics.newImage('water_drop10.png')
self.THEWATER_DROP[12] = love.graphics.newImage('water_drop11.png')
self.THEWATER_DROP[13] = love.graphics.newImage('water_drop12.png')
self.THEWATER_DROP[14] = love.graphics.newImage('water_drop13.png')
self.THEWATER_DROP[15] = love.graphics.newImage('water_drop14.png')
self.THEWATER_DROP[16] = love.graphics.newImage('water_drop15.png')
self.THEWATER_DROP[17] = love.graphics.newImage('water_drop16.png')
self.THEWATER_DROP[18] = love.graphics.newImage('water_drop17.png')
self.THEWATER_DROP[19] = love.graphics.newImage('water_drop18.png')
self.THEWATER_DROP[20] = love.graphics.newImage('water_drop19.png')
self.THEWATER_DROP[21] = love.graphics.newImage('water_drop20.png')


self.bools_to_help_loading[87] = true 
self.bools_to_help_loading[88] = false


elseif self.bools_to_help_loading[88] == false then


self.THEWATER_DROP[24] = love.graphics.newImage('water_drop23.png')
self.THEWATER_DROP[25] = love.graphics.newImage('water_drop24.png')
self.THEWATER_DROP[26] = love.graphics.newImage('water_drop25.png')
self.THEWATER_DROP[27] = love.graphics.newImage('water_drop26.png')

self.THEWATER_DROP_RED = {}
self.THEWATER_DROP_RED[1] = love.graphics.newImage('water_drop_red(1).png')
self.THEWATER_DROP_RED[2] = love.graphics.newImage('water_drop_red(2).png')
self.THEWATER_DROP_RED[3] = love.graphics.newImage('water_drop_red(3).png')
self.THEWATER_DROP_RED[4] = love.graphics.newImage('water_drop_red(4).png')
self.THEWATER_DROP_RED[5] = love.graphics.newImage('water_drop_red(5).png')


self.bools_to_help_loading[88] = true 
self.bools_to_help_loading[89] = false

elseif self.bools_to_help_loading[89] == false then

self.THEWATER_DROP[22] = love.graphics.newImage('water_drop21.png')
self.THEWATER_DROP[23] = love.graphics.newImage('water_drop22.png')
self.THEWATER_DROP_RED[6] = love.graphics.newImage('water_drop_red(6).png')
self.THEWATER_DROP_RED[7] = love.graphics.newImage('water_drop_red(7).png')
self.THEWATER_DROP_RED[8] = love.graphics.newImage('water_drop_red(8).png')
self.THEWATER_DROP_RED[9] = love.graphics.newImage('water_drop_red(9).png')
self.THEWATER_DROP_RED[10] = love.graphics.newImage('water_drop_red(10).png')
self.THEWATER_DROP_RED[11] = love.graphics.newImage('water_drop_red(11).png')
self.THEWATER_DROP_RED[12] = love.graphics.newImage('water_drop_red(12).png')
self.THEWATER_DROP_RED[13] = love.graphics.newImage('water_drop_red(13).png')
self.THEWATER_DROP_RED[14] = love.graphics.newImage('water_drop_red(14).png')
self.THEWATER_DROP_RED[15] = love.graphics.newImage('water_drop_red(15).png')
self.THEWATER_DROP_RED[16] = love.graphics.newImage('water_drop_red(16).png')


self.bools_to_help_loading[89] = true 
self.bools_to_help_loading[90] = false

elseif self.bools_to_help_loading[90] == false then

self.THEWATER_DROP_RED[17] = love.graphics.newImage('water_drop_red(17).png')
self.THEWATER_DROP_RED[18] = love.graphics.newImage('water_drop_red(18).png')
self.THEWATER_DROP_RED[19] = love.graphics.newImage('water_drop_red(19).png')
self.THEWATER_DROP_RED[20] = love.graphics.newImage('water_drop_red(20).png')
self.THEWATER_DROP_RED[21] = love.graphics.newImage('water_drop_red(21).png')
self.THEWATER_DROP_RED[22] = love.graphics.newImage('water_drop_red(22).png')
self.THEWATER_DROP_RED[23] = love.graphics.newImage('water_drop_red(23).png')
self.THEWATER_DROP_RED[24] = love.graphics.newImage('water_drop_red(24).png')
self.THEWATER_DROP_RED[25] = love.graphics.newImage('water_drop_red(25).png')
self.THEWATER_DROP_RED[26] = love.graphics.newImage('water_drop_red(26).png')
self.THEWATER_DROP_RED[27] = love.graphics.newImage('water_drop_red(27).png')


self.bools_to_help_loading[90] = true 
self.bools_to_help_loading[91] = false


--elseif self.bools_to_help_loading[91] == false then

self.THELIGHTNING_R = {}
self.THELIGHTNING_R[1] = love.graphics.newImage('lightning_right (1).png')
self.THELIGHTNING_R[2] = love.graphics.newImage('lightning_right (2).png')
self.THELIGHTNING_R[3] = love.graphics.newImage('lightning_right (3).png')
self.THELIGHTNING_R[4] = love.graphics.newImage('lightning_right (4).png')
self.THELIGHTNING_R[5] = love.graphics.newImage('lightning_right (5).png')
self.THELIGHTNING_R[6] = love.graphics.newImage('lightning_right (6).png')


self.bools_to_help_loading[91] = true 
self.bools_to_help_loading[92] = false


elseif self.bools_to_help_loading[92] == false then



self.THELIGHTNING_L = {}
self.THELIGHTNING_L[1] = love.graphics.newImage('lightning_left (1).png')
self.THELIGHTNING_L[2] = love.graphics.newImage('lightning_left (2).png')
self.THELIGHTNING_L[3] = love.graphics.newImage('lightning_left (3).png')
self.THELIGHTNING_L[4] = love.graphics.newImage('lightning_left (4).png')
self.THELIGHTNING_L[5] = love.graphics.newImage('lightning_left (5).png')
self.THELIGHTNING_L[6] = love.graphics.newImage('lightning_left (6).png')


self.bools_to_help_loading[92] = true 
self.bools_to_help_loading[93] = false

--
elseif self.bools_to_help_loading[93] == false then

self.THEWIND = {}
self.THEWIND[1] = love.graphics.newImage('wind (1).png')
self.THEWIND[2] = love.graphics.newImage('wind (2).png')
self.THEWIND[3] = love.graphics.newImage('wind (3).png')
self.THEWIND[4] = love.graphics.newImage('wind (4).png')
self.THEWIND[5] = love.graphics.newImage('wind (5).png')
self.THEWIND[6] = love.graphics.newImage('wind (6).png')
self.THEWIND[7] = love.graphics.newImage('wind (7).png')
self.THEWIND[8] = love.graphics.newImage('wind (8).png')
self.THEWIND[9] = love.graphics.newImage('wind (9).png')


self.bools_to_help_loading[93] = true 
self.bools_to_help_loading[94] = false


elseif self.bools_to_help_loading[94] == false then

self.THEWIND[10] = love.graphics.newImage('wind (10).png')
self.THEWIND[11] = love.graphics.newImage('wind (11).png')
self.THEWIND[12] = love.graphics.newImage('wind (12).png')
self.THEWIND[13] = love.graphics.newImage('wind (13).png')
self.THEWIND[14] = love.graphics.newImage('wind (14).png')
self.THEWIND[15] = love.graphics.newImage('wind (15).png')
self.THEWIND[16] = love.graphics.newImage('wind (16).png')
self.THEWIND[17] = love.graphics.newImage('wind (17).png')
self.THEWIND[18] = love.graphics.newImage('wind (18).png')
self.THEWIND[19] = love.graphics.newImage('wind (19).png')
self.THEWIND[20] = love.graphics.newImage('wind (20).png')
self.THEWIND[21] = love.graphics.newImage('wind (21).png')
self.THEWIND[22] = love.graphics.newImage('wind (22).png')


self.bools_to_help_loading[94] = true 
self.bools_to_help_loading[95] = false


--elseif self.bools_to_help_loading[95] == false then

self.THEWIND[23] = love.graphics.newImage('wind (23).png')
self.THEWIND[24] = love.graphics.newImage('wind (24).png')
self.THEWIND[25] = love.graphics.newImage('wind (25).png')
self.THEWIND[26] = love.graphics.newImage('wind (26).png')
self.THEWIND[27] = love.graphics.newImage('wind (27).png')
self.THEWIND[28] = love.graphics.newImage('wind (28).png')
self.THEWIND[29] = love.graphics.newImage('wind (29).png')
self.THEWIND[30] = love.graphics.newImage('wind (30).png')


self.bools_to_help_loading[95] = true 
self.bools_to_help_loading[96] = false



elseif self.bools_to_help_loading[96] == false then


self.bools_to_help_loading[96] = true 
self.bools_to_help_loading[97] = false


--elseif self.bools_to_help_loading[97] == false then



self.bools_to_help_loading[97] = true 
self.bools_to_help_loading[98] = false


elseif self.bools_to_help_loading[98] == false then


self.THESUN = {}
self.THESUN[1] = love.graphics.newImage('thesun(1).png')
self.THESUN[2] = love.graphics.newImage('thesun(2).png')
self.THESUN[3] = love.graphics.newImage('thesun(3).png')
self.THESUN[4] = love.graphics.newImage('thesun(4).png')
self.THESUN[5] = love.graphics.newImage('thesun(5).png')
self.THESUN[6] = love.graphics.newImage('thesun(6).png')


self.bools_to_help_loading[98] = true 
self.bools_to_help_loading[99] = false

elseif self.bools_to_help_loading[99] == false then

self.theFLOWERS1 = {}
self.theFLOWERS1[1] = love.graphics.newImage('flowers1 (1).png')
self.theFLOWERS1[2] = love.graphics.newImage('flowers1 (2).png')
self.theFLOWERS1[3] = love.graphics.newImage('flowers1 (3).png')
self.theFLOWERS1[4] = love.graphics.newImage('flowers1 (4).png')
self.theFLOWERS1[5] = love.graphics.newImage('flowers1 (5).png')
self.theFLOWERS1[6] = love.graphics.newImage('flowers1 (6).png')
self.theFLOWERS1[7] = love.graphics.newImage('flowers1 (7).png')
self.theFLOWERS1[8] = love.graphics.newImage('flowers1 (8).png')
self.theFLOWERS1[9] = love.graphics.newImage('flowers1 (9).png')
self.theFLOWERS1[10] = love.graphics.newImage('flowers1 (10).png')


self.bools_to_help_loading[99] = true 
self.bools_to_help_loading[100] = false

elseif self.bools_to_help_loading[100] == false then

self.theFLOWERS1[11] = love.graphics.newImage('flowers1 (11).png')
self.theFLOWERS1[12] = love.graphics.newImage('flowers1 (12).png')
self.theFLOWERS1[13] = love.graphics.newImage('flowers1 (13).png')
self.theFLOWERS1[14] = love.graphics.newImage('flowers1 (14).png')
self.theFLOWERS1[15] = love.graphics.newImage('flowers1 (15).png')
self.theFLOWERS1[16] = love.graphics.newImage('flowers1 (16).png')
self.theFLOWERS1[17] = love.graphics.newImage('flowers1 (17).png')
self.theFLOWERS1[18] = love.graphics.newImage('flowers1 (18).png')
self.theFLOWERS1[19] = love.graphics.newImage('flowers1 (19).png')

self.bools_to_help_loading[100] = true 
self.bools_to_help_loading2[1] = false

--elseif self.bools_to_help_loading2[1] == false then



self.bools_to_help_loading2[1] = true 
self.bools_to_help_loading2[2] = false



elseif self.bools_to_help_loading2[2] == false then


self.theFLOWERS2 = {}
self.theFLOWERS2[1] = love.graphics.newImage('flowers2 (1).png')
self.theFLOWERS2[2] = love.graphics.newImage('flowers2 (2).png')
self.theFLOWERS2[3] = love.graphics.newImage('flowers2 (3).png')
self.theFLOWERS2[4] = love.graphics.newImage('flowers2 (4).png')
self.theFLOWERS2[5] = love.graphics.newImage('flowers2 (5).png')
self.theFLOWERS2[6] = love.graphics.newImage('flowers2 (6).png')


self.bools_to_help_loading2[2] = true 
self.bools_to_help_loading2[3] = false

--
elseif self.bools_to_help_loading2[3] == false then

self.theFLOWERS2[7] = love.graphics.newImage('flowers2 (7).png')
self.theFLOWERS2[8] = love.graphics.newImage('flowers2 (8).png')
self.theFLOWERS2[9] = love.graphics.newImage('flowers2 (9).png')
self.theFLOWERS2[10] = love.graphics.newImage('flowers2 (10).png')
self.theFLOWERS2[11] = love.graphics.newImage('flowers2 (11).png')
self.theFLOWERS2[12] = love.graphics.newImage('flowers2 (12).png')
self.theFLOWERS2[13] = love.graphics.newImage('flowers2 (13).png')
self.theFLOWERS2[14] = love.graphics.newImage('flowers2 (14).png')
self.theFLOWERS2[15] = love.graphics.newImage('flowers2 (15).png')
self.theFLOWERS2[16] = love.graphics.newImage('flowers2 (16).png')
self.theFLOWERS2[17] = love.graphics.newImage('flowers2 (17).png')
self.theFLOWERS2[18] = love.graphics.newImage('flowers2 (18).png')


self.bools_to_help_loading2[3] = true 
self.bools_to_help_loading2[4] = false


elseif self.bools_to_help_loading2[4] == false then

self.theFLOWERS2[19] = love.graphics.newImage('flowers2 (19).png')


self.bools_to_help_loading2[4] = true 
self.bools_to_help_loading2[5] = false


--elseif self.bools_to_help_loading2[5] == false then



self.theFLOWERS3 = {}
self.theFLOWERS3[1] = love.graphics.newImage('flowers3 (1).png')
self.theFLOWERS3[2] = love.graphics.newImage('flowers3 (2).png')


self.bools_to_help_loading2[5] = true 
self.bools_to_help_loading2[6] = false


elseif self.bools_to_help_loading2[6] == false then


self.theFLOWERS3[3] = love.graphics.newImage('flowers3 (3).png')
self.theFLOWERS3[4] = love.graphics.newImage('flowers3 (4).png')
self.theFLOWERS3[5] = love.graphics.newImage('flowers3 (5).png')
self.theFLOWERS3[6] = love.graphics.newImage('flowers3 (6).png')
self.theFLOWERS3[7] = love.graphics.newImage('flowers3 (7).png')
self.theFLOWERS3[8] = love.graphics.newImage('flowers3 (8).png')
self.theFLOWERS3[9] = love.graphics.newImage('flowers3 (9).png')
self.theFLOWERS3[10] = love.graphics.newImage('flowers3 (10).png')
self.theFLOWERS3[11] = love.graphics.newImage('flowers3 (11).png')
self.theFLOWERS3[12] = love.graphics.newImage('flowers3 (12).png')
self.theFLOWERS3[13] = love.graphics.newImage('flowers3 (13).png')


self.bools_to_help_loading2[6] = true 
self.bools_to_help_loading2[7] = false


--elseif self.bools_to_help_loading2[7] == false then

self.theFLOWERS3[14] = love.graphics.newImage('flowers3 (14).png')
self.theFLOWERS3[15] = love.graphics.newImage('flowers3 (15).png')
self.theFLOWERS3[16] = love.graphics.newImage('flowers3 (16).png')
self.theFLOWERS3[17] = love.graphics.newImage('flowers3 (17).png')
self.theFLOWERS3[18] = love.graphics.newImage('flowers3 (18).png')
self.theFLOWERS3[19] = love.graphics.newImage('flowers3 (19).png')

self.bools_to_help_loading2[7] = true 
self.bools_to_help_loading2[8] = false


elseif self.bools_to_help_loading2[8] == false then



self.bools_to_help_loading2[8] = true 
self.bools_to_help_loading2[9] = false

elseif self.bools_to_help_loading2[9] == false then


self.theFLOWERS4 = {}
self.theFLOWERS4[1] = love.graphics.newImage('flowers4 (1).png')
self.theFLOWERS4[2] = love.graphics.newImage('flowers4 (2).png')
self.theFLOWERS4[3] = love.graphics.newImage('flowers4 (3).png')
self.theFLOWERS4[4] = love.graphics.newImage('flowers4 (4).png')
self.theFLOWERS4[5] = love.graphics.newImage('flowers4 (5).png')
self.theFLOWERS4[6] = love.graphics.newImage('flowers4 (6).png')
self.theFLOWERS4[7] = love.graphics.newImage('flowers4 (7).png')
self.theFLOWERS4[8] = love.graphics.newImage('flowers4 (8).png')


self.bools_to_help_loading2[9] = true 
self.bools_to_help_loading2[10] = false

elseif self.bools_to_help_loading2[10] == false then

self.theFLOWERS4[9] = love.graphics.newImage('flowers4 (9).png')
self.theFLOWERS4[10] = love.graphics.newImage('flowers4 (10).png')
self.theFLOWERS4[11] = love.graphics.newImage('flowers4 (11).png')
self.theFLOWERS4[12] = love.graphics.newImage('flowers4 (12).png')
self.theFLOWERS4[13] = love.graphics.newImage('flowers4 (13).png')
self.theFLOWERS4[14] = love.graphics.newImage('flowers4 (14).png')
self.theFLOWERS4[15] = love.graphics.newImage('flowers4 (15).png')
self.theFLOWERS4[16] = love.graphics.newImage('flowers4 (16).png')
self.theFLOWERS4[17] = love.graphics.newImage('flowers4 (17).png')
self.theFLOWERS4[18] = love.graphics.newImage('flowers4 (18).png')
self.theFLOWERS4[19] = love.graphics.newImage('flowers4 (19).png')


self.bools_to_help_loading2[10] = true 
self.bools_to_help_loading2[11] = false


elseif self.bools_to_help_loading2[11] == false then
--

self.bools_to_help_loading2[11] = true 
self.bools_to_help_loading2[12] = false


elseif self.bools_to_help_loading2[12] == false then



self.THEFLAMES = {}
self.THEFLAMES[1] = love.graphics.newImage('flame (1).png')
self.THEFLAMES[2] = love.graphics.newImage('flame (2).png')
self.THEFLAMES[3] = love.graphics.newImage('flame (3).png')


self.bools_to_help_loading2[12] = true 
self.bools_to_help_loading2[13] = false


--elseif self.bools_to_help_loading2[13] == false then

self.THEFLAMES[4] = love.graphics.newImage('flame (4).png')
self.THEFLAMES[5] = love.graphics.newImage('flame (5).png')
self.THEFLAMES[6] = love.graphics.newImage('flame (6).png')
self.THEFLAMES[7] = love.graphics.newImage('flame (7).png')
self.THEFLAMES[8] = love.graphics.newImage('flame (8).png')
self.THEFLAMES[9] = love.graphics.newImage('flame (9).png')
self.THEFLAMES[10] = love.graphics.newImage('flame (10).png')
self.THEFLAMES[11] = love.graphics.newImage('flame (11).png')
self.THEFLAMES[12] = love.graphics.newImage('flame (12).png')
self.THEFLAMES[13] = love.graphics.newImage('flame (13).png')
self.THEFLAMES[14] = love.graphics.newImage('flame (14).png')


self.bools_to_help_loading2[13] = true 
self.bools_to_help_loading2[14] = false


elseif self.bools_to_help_loading2[14] == false then


self.THEFLAMES[15] = love.graphics.newImage('flame (15).png')
self.THEFLAMES[16] = love.graphics.newImage('flame (16).png')
self.THEFLAMES[17] = love.graphics.newImage('flame (17).png')

self.bools_to_help_loading2[14] = true 
self.bools_to_help_loading2[15] = false


--eelseif self.bools_to_help_loading2[15] == false then


self.BACKGROUND3 = {}
self.BACKGROUND3[1] = love.graphics.newImage('background3 (1).png')
self.BACKGROUND3[2] = love.graphics.newImage('background3 (2).png')


self.bools_to_help_loading2[15] = true 
self.bools_to_help_loading2[16] = false



elseif self.bools_to_help_loading2[16] == false then

self.BACKGROUND3[3] = love.graphics.newImage('background3 (3).png')
self.BACKGROUND3[4] = love.graphics.newImage('background3 (4).png')
self.BACKGROUND3[5] = love.graphics.newImage('background3 (5).png')
self.BACKGROUND3[6] = love.graphics.newImage('background3 (6).png')
self.BACKGROUND3[7] = love.graphics.newImage('background3 (7).png')
self.BACKGROUND3[8] = love.graphics.newImage('background3 (8).png')
self.BACKGROUND3[9] = love.graphics.newImage('background3 (9).png')
self.BACKGROUND3[10] = love.graphics.newImage('background3 (10).png')
self.BACKGROUND3[11] = love.graphics.newImage('background3 (11).png')
self.BACKGROUND3[12] = love.graphics.newImage('background3 (12).png')
self.BACKGROUND3[13] = love.graphics.newImage('background3 (13).png')


self.bools_to_help_loading2[16] = true 
self.bools_to_help_loading2[17] = false


--elseif self.bools_to_help_loading2[17] == false then

self.BACKGROUND3[14] = love.graphics.newImage('background3 (14).png')
self.BACKGROUND3[15] = love.graphics.newImage('background3 (15).png')
self.BACKGROUND3[16] = love.graphics.newImage('background3 (16).png')
self.BACKGROUND3[17] = love.graphics.newImage('background3 (17).png')
self.BACKGROUND3[18] = love.graphics.newImage('background3 (18).png')
self.BACKGROUND3[19] = love.graphics.newImage('background3 (19).png')


self.bools_to_help_loading2[17] = true 
self.bools_to_help_loading2[18] = false


elseif self.bools_to_help_loading2[18] == false then



self.bools_to_help_loading2[18] = true 
self.bools_to_help_loading2[19] = false

elseif self.bools_to_help_loading2[19] == false then


self.BACKGROUND3_IMG = love.graphics.newImage('background3 (1).png')

self.BLUE_CONG = {}
self.BLUE_CONG[1] = love.graphics.newImage('blue_cong (1).png')
self.BLUE_CONG[2] = love.graphics.newImage('blue_cong (2).png')
self.BLUE_CONG[3] = love.graphics.newImage('blue_cong (3).png')
self.BLUE_CONG[4] = love.graphics.newImage('blue_cong (4).png')


self.bools_to_help_loading2[19] = true 
self.bools_to_help_loading2[20] = false


elseif self.bools_to_help_loading2[20] == false then


self.GREEN_CONG = {}
self.GREEN_CONG[1] = love.graphics.newImage('green_cong (1).png')
self.GREEN_CONG[2] = love.graphics.newImage('green_cong (2).png')
self.GREEN_CONG[3] = love.graphics.newImage('green_cong (3).png')
self.GREEN_CONG[4] = love.graphics.newImage('green_cong (4).png')


self.bools_to_help_loading2[20] = true 
self.bools_to_help_loading2[21] = false


elseif self.bools_to_help_loading2[21] == false then
--
self.YELLOW_CONG = {}
self.YELLOW_CONG[1] = love.graphics.newImage('yellow_cong (1).png')
self.YELLOW_CONG[2] = love.graphics.newImage('yellow_cong (2).png')
self.YELLOW_CONG[3] = love.graphics.newImage('yellow_cong (3).png')
self.YELLOW_CONG[4] = love.graphics.newImage('yellow_cong (4).png')



self.bools_to_help_loading2[21] = true 
self.bools_to_help_loading2[22] = false


elseif self.bools_to_help_loading2[22] == false then

self.PURPLE_CONG = {}
self.PURPLE_CONG[1] = love.graphics.newImage('purple_cong (1).png')
self.PURPLE_CONG[2] = love.graphics.newImage('purple_cong (2).png')
self.PURPLE_CONG[3] = love.graphics.newImage('purple_cong (3).png')
self.PURPLE_CONG[4] = love.graphics.newImage('purple_cong (4).png')

self.bools_to_help_loading2[22] = true 
self.bools_to_help_loading2[23] = false


--elseif self.bools_to_help_loading2[23] == false then


self.WHITE_FLYINGBIRD = {}
self.WHITE_FLYINGBIRD[1] = love.graphics.newImage('white_flyingbird(1).png')
self.WHITE_FLYINGBIRD[2] = love.graphics.newImage('white_flyingbird(2).png')
self.WHITE_FLYINGBIRD[3] = love.graphics.newImage('white_flyingbird(3).png')
self.WHITE_FLYINGBIRD[4] = love.graphics.newImage('white_flyingbird(4).png')
self.WHITE_FLYINGBIRD[5] = love.graphics.newImage('white_flyingbird(5).png')
self.WHITE_FLYINGBIRD[6] = love.graphics.newImage('white_flyingbird(6).png')
self.WHITE_FLYINGBIRD[7] = love.graphics.newImage('white_flyingbird(7).png')
self.WHITE_FLYINGBIRD[8] = love.graphics.newImage('white_flyingbird(8).png')
self.WHITE_FLYINGBIRD[9] = love.graphics.newImage('white_flyingbird(9).png')
self.WHITE_FLYINGBIRD[10] = love.graphics.newImage('white_flyingbird(10).png')
self.WHITE_FLYINGBIRD[11] = love.graphics.newImage('white_flyingbird(11).png')


self.bools_to_help_loading2[23] = true 
self.bools_to_help_loading2[24] = false


elseif self.bools_to_help_loading2[24] == false then

self.WHITE_FLYINGBIRD_L = {}
self.WHITE_FLYINGBIRD_L[1] = love.graphics.newImage('white_flyingbird_l(1).png')
self.WHITE_FLYINGBIRD_L[2] = love.graphics.newImage('white_flyingbird_l(2).png')
self.WHITE_FLYINGBIRD_L[3] = love.graphics.newImage('white_flyingbird_l(3).png')
self.WHITE_FLYINGBIRD_L[4] = love.graphics.newImage('white_flyingbird_l(4).png')
self.WHITE_FLYINGBIRD_L[5] = love.graphics.newImage('white_flyingbird_l(5).png')
self.WHITE_FLYINGBIRD_L[6] = love.graphics.newImage('white_flyingbird_l(6).png')
self.WHITE_FLYINGBIRD_L[7] = love.graphics.newImage('white_flyingbird_l(7).png')
self.WHITE_FLYINGBIRD_L[8] = love.graphics.newImage('white_flyingbird_l(8).png')
self.WHITE_FLYINGBIRD_L[9] = love.graphics.newImage('white_flyingbird_l(9).png')
self.WHITE_FLYINGBIRD_L[10] = love.graphics.newImage('white_flyingbird_l(10).png')
self.WHITE_FLYINGBIRD_L[11] = love.graphics.newImage('white_flyingbird_l(11).png')


self.bools_to_help_loading2[24] = true 
self.bools_to_help_loading2[25] = false


--elseif self.bools_to_help_loading2[25] == false then

self.WINGS_CONG = love.graphics.newImage('wings_cong.png')

self.CONGRATULATION = love.graphics.newImage('congratulation.png')

self.shotFireImg = love.graphics.newImage('shotfire.png')

self.fire = love.graphics.newImage('fire.png')

self.bulletImg = love.graphics.newImage('handgunbullet.png')

self.bullet_LAZER_GUN = love.graphics.newImage('bullet_lazer_gun.png')

self.bullet_SHOT_GUN = love.graphics.newImage('bullet_shot_gun.png')

self.bullet_HEAVY_GUN = love.graphics.newImage('bullet_heavy_gun.png')


self.bools_to_help_loading2[25] = true 
self.bools_to_help_loading2[26] = false



elseif self.bools_to_help_loading2[26] == false then

self.player_img = love.graphics.newImage('character_1_1.png')

self.backgroundimg = love.graphics.newImage('thebackground.png')


self.deadline = love.graphics.newImage('deadline.png')

self.ATTACK_HELP = love.graphics.newImage('attack_help.png')

self.hit_effect = love.graphics.newImage('hit_effect.png')


self.explotion_gameover = love.audio.newSource('explotion_gameover.mp3', 'stream')

self.change_clothes = love.graphics.newImage("change_clothes.png")


self.bools_to_help_loading2[26] = true 
self.initial = true
self.loading = false

end--end of too many elseif'""'s and one if !

end-- end of initialing 


end-- end of loading function






return self



end