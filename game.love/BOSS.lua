require("enemys")
--BOSS CLASS :: starts here

BOSS = { x , y , img = nil , health = 3 , isAlive = true , isDead = false , shouldAttack = false , shouldgethit = false , BOSSIMAGES = {} , BBullets = {} , BULLET_IMG = nil , BULLET_IMGS = {} , BULLET_IMG_FRAMESPEED = 0 , BULLET_IMG_FRAME = 1 , attackSpeed = 0 , helper = nil , should_summon_helper = false , t = 0 , t1 = 0 }
BBullet = love.graphics.newImage('bbullet.png')
R = 0
R1 = 0
R2 = 0




function BOSS:new(o)
o = o or {}
setmetatable(o , self)
self.__index = self 
return o
end




function BOSS:die()    
self.y = self.y + 1820/2 * scale_y
if self.BBullets ~= nil then
self:attack_update()
end
end

function BOSS:reborn()
self.x = 500/2 * scale_x
self.y = 100/2 * scale_y
self.isAlive = true
self.health = 2

if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.health = self.health + 1
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.health = self.health + 2
        
        end

end




function BOSS:ShouldGetHit()

if self.helper.isAlive == false then

if self.t >= 760 then
	self.t = 0
self.shouldgethit = true
end
self.t = self.t + 1

if self.shouldgethit == true then
if self.t1 >= 200 then
self.t1 = 0
self.shouldgethit = false
end
self.t1  = self.t1 + 1
end

else
self.shouldgethit = false	
self.t = 0
self.t1 = 0
end

end


--[[
function BOSS:Apear()

end
--]]

--[[

in main lua after get hit make an enemy


--]]



function BOSS:attack()
if self.shouldAttack == true then	
--make  two  random bullets 
local nbullet = {x = self.x - 35/2 * scale_x , y = self.y + 150/2 * scale_y , visible = true }
local nbullet1 = {x = self.x - 35/2 * scale_x , y = self.y - 10/2 * scale_y , visible = true }
local nbullet2 = {x = self.x - 35/2 * scale_x , y = self.y + 270/2 * scale_y , visible = true }
local random = love.math.random(1,3)
if R >= 2 then
	random = 3
	R = 0
end
if R1 >= 2 then
	random = 1
	R1 = 0
end
if R2 >= 2 then
	random = 2
	R2 = 0
end	
if random == 1 then
if PASSING_FINISHeD_GAME > 0 then  
table.insert(self.BBullets,1,nbullet)
table.insert(self.BBullets,1,nbullet1)
R = R + 1
else
table.insert(self.BBullets,1,nbullet)
R = R + 1
end
elseif random == 2 then
if PASSING_FINISHeD_GAME > 0 then 
table.insert(self.BBullets,1,nbullet)
table.insert(self.BBullets,1,nbullet2)
R1 = R1 + 1
else
table.insert(self.BBullets,1,nbullet1)
R1 = R1 + 1
end
elseif random == 3 then
if PASSING_FINISHeD_GAME > 0 then 
table.insert(self.BBullets,1,nbullet1)
table.insert(self.BBullets,1,nbullet2)
R2 = R2 + 2
else
table.insert(self.BBullets,1,nbullet2)
R2 = R2 + 2
end
end

self.attackSpeed = 0
self.shouldAttack = false	
end
end


function BOSS:attack_update() 



if self.attackSpeed <= 1 then
    self.shouldAttack = false

   self.attackSpeed = self.attackSpeed + 0.0240 

end

if self.attackSpeed > 1 then
	self.shouldAttack = true
end


if #self.BBullets >= 1 then

for s = 1 ,#self.BBullets do
if self.BBullets[s].visible ~= false then 

   self.BBullets[s].x = self.BBullets[s].x - 2.2/2 * scale_x

end
end



for i = 1 , #self.BBullets do
if self.BBullets[i].x < 10/2 * scale_x then 
self.BBullets[i].visible = false
end
end

for i = 1 , #self.BBullets do
if self.BBullets[i] == nil then
break
elseif self.BBullets[i].visible == false then
table.remove(self.BBullets,i)  
end
end




for i = 1 , #self.BBullets do
if self.BBullets[i] == nil then
break
end
if movingRight == true and movingLeft == false and jumping == false and ducking == false then
testCollision1 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
--or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.BBullets[i].x , self.BBullets[i].y , 50 , 50) == true __shouldn't use
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true then	

table.remove(self.BBullets,i)

playerGETHIT()    

end
else
testCollision1 = false
end

if movingLeft == true and movingRight == false and jumping == false and ducking == false then
testCollision2 = true
if CheckCollision(rect6.x , rect6.y , rect6.w , rect6.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect7.x , rect7.y , rect7.w , rect7.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
or CheckCollision(rect8.x , rect8.y , rect8.w , rect8.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true then


if player.health == 1 then
GAME_PlAY = false
end

table.remove(self.BBullets,i)

playerGETHIT()      

end
else
testCollision2 = false
end

if jumping == true and ducking == false then
testCollision3 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
--or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.BBullets[i].x , self.BBullets[i].y , 50 , 50) == true __shouldn't use
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true then    


table.remove(self.BBullets,i) 

playerGETHIT()           

end
else
testCollision3 = false    
end

if ducking == true and movingRight == false and movingLeft == false and jumping == false then
testCollision4 = true
if CheckCollision(rect9.x , rect9.y , rect9.w , rect9.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect10.x , rect10.y , rect10.w , rect10.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
or CheckCollision(rect11.x , rect11.y , rect11.w , rect11.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true then

table.remove(self.BBullets,i)

playerGETHIT()      
  
  
end
else
testCollision4 = false
end



end       

end






end






function BOSS:update_getHit()
for i = 1 , #bullets do
if bullets[i] == nil or bullets == nil then
break    
else
if CheckCollision( self.x + 140/2 * scale_x , self.y + 170/2 * scale_y , 30/2 * scale_x , 180/2 * scale_y , bullets[i].x , bullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true and self.helper.isAlive == false then 
bullets[i].visible = false
scoore = scoore + 1

scoore_update()--function.lua

if self.health >=1 then
self.health = self.health - 1

self.should_summon_helper = true
boss_frame_ATTACK = 1
else
BOSS_DEAD_shouldshow = true	
self.isAlive = false    
passing = true
AMMO = AMMO + 3
self.should_summon_helper = false
should_summon_boss1 = false
boss1_finished = true
CONG_HANDLER = true

if player.health ~= 5 then    
player.health = player.health + 1
else
scoore = scoore + 5

scoore_update() --update scoore :: function.lua
end 


break    
end
end
end
end
end




function BOSS:BULLETIMG()

if self.BBullets ~= nil and self.BBullets[1] ~= nil then

if self.BULLET_IMG_FRAMESPEED >= 5 * 0.018 then
self.BULLET_IMG_FRAMESPEED = 0


if self.BULLET_IMG_FRAME < 13 then
    self.BULLET_IMG_FRAME = self.BULLET_IMG_FRAME + 1
else
    self.BULLET_IMG_FRAME = 1
end

else

self.BULLET_IMG_FRAMESPEED = self.BULLET_IMG_FRAMESPEED + 0.028/2

end


self.BULLET_IMG = self.BULLET_IMGS[self.BULLET_IMG_FRAME]


end

end



--BOSS CLASS :: ends here