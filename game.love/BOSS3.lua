require("enemys")
--BOSS CLASS :: starts here

BOSS3 = { x , y , img = nil , health = 3 , isAlive = true , isDead = false , shouldAttack = false , shouldAttack1 = false , shouldAttack1 = false , shouldgethit = false , BOSSIMAGES = {} , BBullets = {}  , BBullets1 = {} , BBullets2 = {} , BULLET_IMG = nil , BULLET_IMGS = {} , BULLET_IMG_FRAMESPEED = 0 , BULLET_IMG_FRAME = 1 , BULLET1_IMG = nil , BULLET1_IMGS = {} , BULLET1_IMG_FRAMESPEED = 0 , BULLET1_IMG_FRAME = 1 , BULLET1_2IMG = nil , BULLET1_2IMGS = {} , BULLET1_2IMG_FRAMESPEED = 0 , BULLET1_2IMG_FRAME = 1 , BULLET2_IMG = nil , BULLET2_IMGS = {} , BULLET2_IMG_FRAMESPEED = 0 , BULLET2_IMG_FRAME = 1 ,  attackSpeed = 0 , attackSpeed1 = 0 , attackSpeed2 = 0 , FIRST_ATTACK = false , SECOND_ATTACK = false , THIRD_ATTACK = false , to_first = false , to_second = false , to_third = false , to_get = false , changeToLight = false , RANDOM_ATTACK = 0  , t = 0 , t1 = 0 , t2 = 0 , t3 = 0  , t4 = 0 , t5 = 0}
BBullet = love.graphics.newImage('bbullet.png')
R = 0
R1 = 0
R2 = 0

R_1 = 0
R_1_1 = 0
R_1_2 = 0

R_2 = 0
R_2_1 = 0
R_2_2 = 0



function BOSS3:new(o)
o = o or {}
setmetatable(o , self)
self.__index = self 
return o
end




function BOSS3:die()    
self.y = self.y + 1820/2 * scale_y
if self.BBullets ~= nil then
self:attack_update()
end
end

function BOSS3:reborn()
self.x = 500/2 * scale_x
self.y = 100/2 * scale_y
self.isAlive = true
self.health = 2 

if PASSING_FINISHeD_GAME <= 1 and PASSING_FINISHeD_GAME > 0 then
        
        self.health = self.health + 1
        
        elseif PASSING_FINISHeD_GAME > 1 then
        
        self.health = self.health + 2
        
        end

end

function BOSS3:RANDOMIZE()

self.RANDOM_ATTACK = love.math.random(1,5)

end


function BOSS3:CHANGE_TO_LIGHT()

if self.changeToLight == true then 
self.t5 = self.t5 + 1
end

if self.t5 >= 100 then
self.changeToLight = false
self.t5 = 0

boss3_frame_GETHIT = 1
boss3_frame_TO_LIGHT = 1
boss3_frame_TO_FIRE = 1
boss3_frame_TO_GLAD = 1
boss3_frame_TO_GOUL = 1
boss3_frame_TO_SKEL = 1
boss3_frame_TO_CREEP = 1


if self.to_first == true then
self.FIRST_ATTACK = true
self:RANDOMIZE()
self.to_first = false

elseif self.to_second == true then
self.SECOND_ATTACK = true	
self:RANDOMIZE()
self.to_second = false

elseif self.to_third == true then
self.THIRD_ATTACK = true	
self:RANDOMIZE()
self.to_third = false


elseif self.to_get == true then
self.shouldgethit = true
self.RANDOM_ATTACK = 0
self.to_get = false	


end

end

end

function BOSS3:FIRSTATTACK()

if self.FIRST_ATTACK == true then 
self.t2 = self.t2 + 1

if self.t2 >= 600 then
self.t2 = 0

boss3_frame_GETHIT = 1
boss3_frame_TO_LIGHT = 1
boss3_frame_TO_FIRE = 1
boss3_frame_TO_GLAD = 1
boss3_frame_TO_GOUL = 1
boss3_frame_TO_SKEL = 1
boss3_frame_TO_CREEP = 1

self.FIRST_ATTACK = false
self.SECOND_ATTACK = false
self.THIRD_ATTACK = false
self.shouldgethit = false
self.changeToLight = true
self.to_second = true
end

end

end


function BOSS3:SECONDATTACK()

if self.SECOND_ATTACK == true then 
self.t3 = self.t3 + 1

if self.t3 >= 600 then
self.t3 = 0

boss3_frame_GETHIT = 1
boss3_frame_TO_LIGHT = 1
boss3_frame_TO_FIRE = 1
boss3_frame_TO_GLAD = 1
boss3_frame_TO_GOUL = 1
boss3_frame_TO_SKEL = 1
boss3_frame_TO_CREEP = 1

self.FIRST_ATTACK = false
self.SECOND_ATTACK = false
self.THIRD_ATTACK = false
self.shouldgethit = false
self.changeToLight = true
self.to_third = true
end

end

end


function BOSS3:THIRDATTACK()

if self.THIRD_ATTACK == true then 
self.t4 = self.t4 + 1

if self.t4 >= 600 then
self.t4 = 0

boss3_frame_GETHIT = 1
boss3_frame_TO_LIGHT = 1
boss3_frame_TO_FIRE = 1
boss3_frame_TO_GLAD = 1
boss3_frame_TO_GOUL = 1
boss3_frame_TO_SKEL = 1
boss3_frame_TO_CREEP = 1

self.FIRST_ATTACK = false
self.SECOND_ATTACK = false
self.THIRD_ATTACK = false
self.shouldgethit = false
self.changeToLight = true
self.to_get = true
end

end

end



function BOSS3:GETHIT()

if self.shouldgethit == true then 
self.t1 = self.t1 + 1

if self.t1 >= 200 then
self.t1 = 0

boss3_frame_GETHIT = 1
boss3_frame_TO_LIGHT = 1
boss3_frame_TO_FIRE = 1
boss3_frame_TO_GLAD = 1
boss3_frame_TO_GOUL = 1
boss3_frame_TO_SKEL = 1
boss3_frame_TO_CREEP = 1

self.FIRST_ATTACK = false
self.SECOND_ATTACK = false
self.THIRD_ATTACK = false
self.shouldgethit = false
self.changeToLight = true
self.to_first = true
end

end

end



function BOSS3:ShouldGetHit()

self:CHANGE_TO_LIGHT()
self:FIRSTATTACK()
self:SECONDATTACK()
self:THIRDATTACK()

self:GETHIT()

end




function BOSS3:BOSS3_TO_FIRE_ATTACK()
if self.shouldAttack == true then	
--make  two  random bullets 
local nbullet = {x = self.x - 500/2 * scale_x , y = 0 , visible = true }
local nbullet1 = {x = self.x - 400/2 * scale_x , y = 0 , visible = true }
local nbullet2 = {x = self.x - 300/2 * scale_x , y = 0 , visible = true }
local random = love.math.random(1,3)
if R >= 2 then
	random = 3
	R = 0
end
if R1 >= 2 then
	random = 1
	R1 = 0
end
if R2 >= 2 then
	random = 2
	R2 = 0
end	
if random == 1 then
if PASSING_FINISHeD_GAME > 0 then  
table.insert(self.BBullets,1,nbullet)
table.insert(self.BBullets,1,nbullet1)
R = R + 1
else
table.insert(self.BBullets,1,nbullet)
R = R + 1
end
elseif random == 2 then
if PASSING_FINISHeD_GAME > 0 then 
table.insert(self.BBullets,1,nbullet)
table.insert(self.BBullets,1,nbullet2)
R1 = R1 + 1
else
table.insert(self.BBullets,1,nbullet1)
R1 = R1 + 1
end
elseif random == 3 then
if PASSING_FINISHeD_GAME > 0 then 
table.insert(self.BBullets,1,nbullet1)
table.insert(self.BBullets,1,nbullet2)
R2 = R2 + 2
else
table.insert(self.BBullets,1,nbullet2)
R2 = R2 + 2
end
end

self.attackSpeed = 0
self.shouldAttack = false	
end
end


function BOSS3:BOSS3_TO_FIRE_ATTACK_UPDATE() 



if self.attackSpeed <= 1 then
    self.shouldAttack = false

   self.attackSpeed = self.attackSpeed + 0.0130 

end

if self.attackSpeed > 1 then
	self.shouldAttack = true
end


if #self.BBullets >= 1 then

for s = 1 ,#self.BBullets do
if self.BBullets[s].visible ~= false then 

   self.BBullets[s].y = self.BBullets[s].y + 5.1/2 * scale_y

end
end



for i = 1 , #self.BBullets do
if self.BBullets[i].y > 400/2 * scale_y then 
self.BBullets[i].visible = false
end
end

for i = 1 , #self.BBullets do
if self.BBullets[i] == nil then
break
elseif self.BBullets[i].visible == false then
table.remove(self.BBullets,i)  
end
end




for i = 1 , #self.BBullets do
if self.BBullets[i] == nil then
break
end
if movingRight == true and movingLeft == false and jumping == false and ducking == false then
testCollision1 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true then	

table.remove(self.BBullets,i)

playerGETHIT()    

end
else
testCollision1 = false
end

if movingLeft == true and movingRight == false and jumping == false and ducking == false then
testCollision2 = true
if CheckCollision(rect6.x , rect6.y , rect6.w , rect6.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect7.x , rect7.y , rect7.w , rect7.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
or CheckCollision(rect8.x , rect8.y , rect8.w , rect8.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true then


if player.health == 1 then
GAME_PlAY = false
end

table.remove(self.BBullets,i)

playerGETHIT()      

end
else
testCollision2 = false
end

if jumping == true and ducking == false then
testCollision3 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true then    


table.remove(self.BBullets,i) 

playerGETHIT()           

end
else
testCollision3 = false    
end

if ducking == true and movingRight == false and movingLeft == false and jumping == false then
testCollision4 = true
if CheckCollision(rect9.x , rect9.y , rect9.w , rect9.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true 
or CheckCollision(rect10.x , rect10.y , rect10.w , rect10.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true
or CheckCollision(rect11.x , rect11.y , rect11.w , rect11.h , self.BBullets[i].x , self.BBullets[i].y , 50/2 * scale_x , 50/2 * scale_y) == true then

table.remove(self.BBullets,i)

playerGETHIT()      
  
  
end
else
testCollision4 = false
end



end       

end






end




function BOSS3:BOSS3_TO_CREEP_ATTACK()
if self.shouldAttack1 == true then	
--make  two  random bullets 
local nbullet = {x =  535/2 * scale_x , y = 220/2 * scale_y , visible = true , goingright = false , goingleft = true }
local nbullet1 = {x = 535/2 * scale_x , y = 60/2 * scale_y , visible = true , goingright = false , goingleft = true }
local nbullet2 = {x = 535/2 * scale_x , y = 360/2 * scale_y , visible = true , goingright = false , goingleft = true }
local random = love.math.random(1,3)
if R_1 >= 2 then
	random = 3
	R_1 = 0
end
if R_1_1 >= 2 then
	random = 1
	R_1_1 = 0
end
if R_1_2 >= 2 then
	random = 2
	R_1_2 = 0
end	
if random == 1 then
if PASSING_FINISHeD_GAME > 0 then  
table.insert(self.BBullets1,1,nbullet)
table.insert(self.BBullets1,1,nbullet1)
R_1 = R_1 + 1
else
table.insert(self.BBullets1,1,nbullet)
R_1 = R_1 + 1
end
elseif random == 2 then
if PASSING_FINISHeD_GAME > 0 then 
table.insert(self.BBullets1,1,nbullet)
table.insert(self.BBullets1,1,nbullet2)
R_1_1 = R_1_1 + 1
else
table.insert(self.BBullets1,1,nbullet1)
R_1_1 = R_1_1 + 1
end
elseif random == 3 then
if PASSING_FINISHeD_GAME > 0 then 
table.insert(self.BBullets1,1,nbullet1)
table.insert(self.BBullets1,1,nbullet2)
R_1_2 = R_1_2 + 2
else
table.insert(self.BBullets1,1,nbullet2)
R_1_2 = R_1_2 + 2
end
end

self.attackSpeed1 = 0
self.shouldAttack1 = false	
end
end


function BOSS3:BOSS3_TO_CREEP_ATTACK_UPDATE() 



if self.attackSpeed1 <= 1 then
    self.shouldAttack1 = false

   self.attackSpeed1 = self.attackSpeed1 + 0.0097 

end

if self.attackSpeed1 > 1 then
	self.shouldAttack1 = true
end


if #self.BBullets1 >= 1 then



for s = 1 ,#self.BBullets1 do
if self.BBullets1[s].visible ~= false then 
if self.BBullets1[s].goingleft == true and self.BBullets1[s].goingright == false then
   self.BBullets1[s].x = self.BBullets1[s].x - 3/2 * scale_x

elseif self.BBullets1[s].goingleft == false and self.BBullets1[s].goingright == true then
self.BBullets1[s].x = self.BBullets1[s].x + 3/2 * scale_x

end
end
end

for s = 1 ,#self.BBullets1 do
if self.BBullets1[s].visible ~= false then 
if self.BBullets1[s].goingleft == true and self.BBullets1[s].x < 10/2 * scale_x then

self.BBullets1[s].goingleft = false
self.BBullets1[s].goingright = true

end
end
end


for i = 1 , #self.BBullets1 do
if self.BBullets1[i].x > 540/2 * scale_x then 
self.BBullets1[i].visible = false
end
end




for i = 1 , #self.BBullets1 do
if self.BBullets1[i] == nil then
break
elseif self.BBullets1[i].visible == false then
table.remove(self.BBullets1,i)  
end
end




for i = 1 , #self.BBullets1 do
if self.BBullets1[i] == nil then
break
end
if movingRight == true and movingLeft == false and jumping == false and ducking == false then
testCollision1 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true
--or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.BBullets[i].x , self.BBullets[i].y , 50 , 50) == true __shouldn't use
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true then	

table.remove(self.BBullets1,i)

playerGETHIT()    

end
else
testCollision1 = false
end

if movingLeft == true and movingRight == false and jumping == false and ducking == false then
testCollision2 = true
if CheckCollision(rect6.x , rect6.y , rect6.w , rect6.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true 
or CheckCollision(rect7.x , rect7.y , rect7.w , rect7.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true
or CheckCollision(rect8.x , rect8.y , rect8.w , rect8.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true then


if player.health == 1 then
GAME_PlAY = false
end

table.remove(self.BBullets1,i)

playerGETHIT()      

end
else
testCollision2 = false
end

if jumping == true and ducking == false then
testCollision3 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true
--or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.BBullets[i].x , self.BBullets[i].y , 50 , 50) == true __shouldn't use
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true then    


table.remove(self.BBullets1,i) 

playerGETHIT()           

end
else
testCollision3 = false    
end

if ducking == true and movingRight == false and movingLeft == false and jumping == false then
testCollision4 = true
if CheckCollision(rect9.x , rect9.y , rect9.w , rect9.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true 
or CheckCollision(rect10.x , rect10.y , rect10.w , rect10.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true
or CheckCollision(rect11.x , rect11.y , rect11.w , rect11.h , self.BBullets1[i].x , self.BBullets1[i].y , 80/2 * scale_x , 80/2 * scale_y) == true then

table.remove(self.BBullets1,i)

playerGETHIT()      
  
  
end
else
testCollision4 = false
end



end       

end








end





function BOSS3:BOSS3_TO_GLAD_ATTACK()
if self.shouldAttack2 == true then	
--make  two  random bullets 
local nbullet = {x = 80/2 * scale_x , y = 0 , visible = true , goingright = false , goingleft = true }
local nbullet1 = {x = 300/2 * scale_x , y = 0 , visible = true , goingright = false , goingleft = true }
local nbullet2 = {x = 530/2 * scale_x , y = 0 , visible = true , goingright = false , goingleft = true }
local random = love.math.random(1,3)
if R_2 >= 2 then
	random = 3
	R_2 = 0
end
if R_2_1 >= 2 then
	random = 1
	R_2_1 = 0
end
if R_2_2 >= 2 then
	random = 2
	R_2_2 = 0
end	
if random == 1 then
if PASSING_FINISHeD_GAME > 0 then  
table.insert(self.BBullets2,1,nbullet)
table.insert(self.BBullets2,1,nbullet1)
R_2 = R_2 + 1
else
table.insert(self.BBullets2,1,nbullet)
R_2 = R_2 + 1
end
elseif random == 2 then
if PASSING_FINISHeD_GAME > 0 then 
table.insert(self.BBullets2,1,nbullet)
table.insert(self.BBullets2,1,nbullet2)
R_2_1 = R_2_1 + 1
else
table.insert(self.BBullets2,1,nbullet1)
R_2_1 = R_2_1 + 1
end
elseif random == 3 then
if PASSING_FINISHeD_GAME > 0 then 
table.insert(self.BBullets2,1,nbullet1)
table.insert(self.BBullets2,1,nbullet2)
R_2_2 = R_2_2 + 2
else
table.insert(self.BBullets2,1,nbullet2)
R_2_2 = R_2_2 + 2
end
end

self.attackSpeed2 = 0
self.shouldAttack2 = false	
end
end




function BOSS3:BOSS3_TO_GLAD_ATTACK_UPDATE() 



if self.attackSpeed2 <= 1 then
    self.shouldAttack2 = false

   self.attackSpeed2 = self.attackSpeed2 + 0.009 

end

if self.attackSpeed2 > 1 then
	self.shouldAttack2 = true
end


if #self.BBullets2 >= 1 then

for s = 1 ,#self.BBullets2 do
if self.BBullets2[s].visible ~= false then 

   self.BBullets2[s].y = self.BBullets2[s].y + 2.5/2 * scale_y
   self.BBullets2[s].x = self.BBullets2[s].x - 2.5/2 * scale_x

end
end



for i = 1 , #self.BBullets2 do
if self.BBullets2[i].y > 400/2 * scale_y then 
self.BBullets2[i].visible = false
end
end

for i = 1 , #self.BBullets2 do
if self.BBullets2[i] == nil then
break
elseif self.BBullets2[i].visible == false then
table.remove(self.BBullets2,i)  
end
end




for i = 1 , #self.BBullets2 do
if self.BBullets2[i] == nil then
break
end
if movingRight == true and movingLeft == false and jumping == false and ducking == false then
testCollision1 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true
--or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.BBullets2[i].x , self.BBullets2[i].y , 90 , 90) == true 
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true then	

table.remove(self.BBullets2,i)

playerGETHIT()    

end
else
testCollision1 = false
end

if movingLeft == true and movingRight == false and jumping == false and ducking == false then
testCollision2 = true
if CheckCollision(rect6.x , rect6.y , rect6.w , rect6.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true 
or CheckCollision(rect7.x , rect7.y , rect7.w , rect7.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true
or CheckCollision(rect8.x , rect8.y , rect8.w , rect8.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true then


if player.health == 1 then
GAME_PlAY = false
end

table.remove(self.BBullets2,i)

playerGETHIT()      

end
else
testCollision2 = false
end

if jumping == true and ducking == false then
testCollision3 = true
if CheckCollision(rect1.x , rect1.y , rect1.w , rect1.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true 
or CheckCollision(rect2.x , rect2.y , rect2.w , rect2.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true
--or CheckCollision(rect3.x , rect3.y , rect3.w , rect3.h , self.BBullets2[i].x , self.BBullets2[i].y , 90 , 90) == true
or CheckCollision(rect4.x , rect4.y , rect4.w , rect4.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true then    


table.remove(self.BBullets2,i) 

playerGETHIT()           

end
else
testCollision3 = false    
end

if ducking == true and movingRight == false and movingLeft == false and jumping == false then
testCollision4 = true
if CheckCollision(rect9.x , rect9.y , rect9.w , rect9.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true 
or CheckCollision(rect10.x , rect10.y , rect10.w , rect10.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true
or CheckCollision(rect11.x , rect11.y , rect11.w , rect11.h , self.BBullets2[i].x , self.BBullets2[i].y , 90/2 * scale_x , 90/2 * scale_y) == true then

table.remove(self.BBullets2,i)

playerGETHIT()      
  
  
end
else
testCollision4 = false
end



end       

end






end














function BOSS3:update_getHit()
for i = 1 , #bullets do
if bullets[i] == nil or bullets == nil then
break    
else
if CheckCollision( self.x + 50/2 * scale_x , self.y + 240/2 * scale_y , 110/2 * scale_x , 130/2 * scale_y , bullets[i].x , bullets[i].y , 20/2 * scale_x , 10/2 * scale_y) == true then 
bullets[i].visible = false
scoore = scoore + 1

scoore_update()--function.lua

if self.health >=1 then
self.health = self.health - 1

self.shouldgethit = false
self.to_first = true
self.changeToLight = true
self.t1 = 0

else
BOSS3_DEAD_shouldshow = true	
self.isAlive = false    
passing = true
AMMO = AMMO + 3
self.FIRST_ATTACK = false
should_summon_boss3 = false
boss3_finished = true
CONG_HANDLER = true

if player.health ~= 5 then    
player.health = player.health + 1
else
scoore = scoore + 5

scoore_update() --update scoore :: function.lua
end 

break    
end
end
end
end
end


--BULLETIMG for BOSS3_TO_FIRE_

function BOSS3:BULLETIMG()

if self.BBullets ~= nil and self.BBullets[1] ~= nil then

if self.BULLET_IMG_FRAMESPEED >= 5 * 0.018 then
self.BULLET_IMG_FRAMESPEED = 0


if self.BULLET_IMG_FRAME < 17 then
    self.BULLET_IMG_FRAME = self.BULLET_IMG_FRAME + 1
else
    self.BULLET_IMG_FRAME = 1
end

else

self.BULLET_IMG_FRAMESPEED = self.BULLET_IMG_FRAMESPEED + 0.05/2

end


self.BULLET_IMG = self.BULLET_IMGS[self.BULLET_IMG_FRAME]


end

end




--BULLETIMG for BOSS3_TO_CREEP

function BOSS3:BULLETIMG1()

if self.BBullets1 ~= nil and self.BBullets1[1] ~= nil then

if self.BULLET1_IMG_FRAMESPEED >= 5 * 0.018 then
self.BULLET1_IMG_FRAMESPEED = 0


if self.BULLET1_IMG_FRAME < 6 then
    self.BULLET1_IMG_FRAME = self.BULLET1_IMG_FRAME + 1
else
    self.BULLET1_IMG_FRAME = 1
end

else

self.BULLET1_IMG_FRAMESPEED = self.BULLET1_IMG_FRAMESPEED + 0.05

end


self.BULLET1_IMG = self.BULLET1_IMGS[self.BULLET1_IMG_FRAME]


end

end



function BOSS3:BULLETIMG1_2()

if self.BBullets1 ~= nil and self.BBullets1[1] ~= nil then

if self.BULLET1_2IMG_FRAMESPEED >= 5 * 0.018 then
self.BULLET1_2IMG_FRAMESPEED = 0


if self.BULLET1_2IMG_FRAME < 6 then
    self.BULLET1_2IMG_FRAME = self.BULLET1_2IMG_FRAME + 1
else
    self.BULLET1_2IMG_FRAME = 1
end

else

self.BULLET1_2IMG_FRAMESPEED = self.BULLET1_2IMG_FRAMESPEED + 0.05

end


self.BULLET1_2IMG = self.BULLET1_2IMGS[self.BULLET1_2IMG_FRAME]


end

end




--BULLETIMG for BOSS3_TO_FIRE_

function BOSS3:BULLETIMG2()

if self.BBullets2 ~= nil and self.BBullets2[1] ~= nil then

if self.BULLET2_IMG_FRAMESPEED >= 5 * 0.018 then
self.BULLET2_IMG_FRAMESPEED = 0


if self.BULLET2_IMG_FRAME < 4 then
    self.BULLET2_IMG_FRAME = self.BULLET2_IMG_FRAME + 1
else
    self.BULLET2_IMG_FRAME = 1
end

else

self.BULLET2_IMG_FRAMESPEED = self.BULLET2_IMG_FRAMESPEED + 0.05/2

end


self.BULLET2_IMG = self.BULLET2_IMGS[self.BULLET2_IMG_FRAME]


end

end


--BOSS CLASS :: ends here