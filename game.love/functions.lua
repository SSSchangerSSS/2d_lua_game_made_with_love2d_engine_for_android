
-- function  for player update_getHit :: starts here 
function playerGETHIT()

if player.health == 1 then 
gameover_explode_bool = true
gamepaused = true 

else

player.health = player.health - 1 

if play_music == 1 then
--sound
if GAME_PlAY == true then
GET_HIT_SOUND:play()
love.system.vibrate( 0.7 )
end
--

end

  
end


end  




--function for player update_getHit :: ends here
function playerGETTREMBL()

if player.health == 1 then 
gameover_explode_bool = true
gamepaused = true 

else

player.health = player.health - 1 

if play_music == 1 then
--sound
if GAME_PlAY == true then
GET_HIT_SOUND:play()
love.system.vibrate( 0.7 )
end
--

end

  
end


end






















--function for CHANGING the GAMEPLAY :: starts here

function easy_mode()


if enemys[1].isAlive == true and enemys[2].isAlive == true then

for i = 1 , #enemys[1].EBullets do
if enemys[1].EBullets[i].y <= 370/2 * scale_y and enemys[1].EBullets[i].y >= 100/2 * scale_y and  enemys[2].y <= 310/2 * scale_y and enemys[2].y >= 160/2 * scale_y then
enemys[2].shouldAttack = false
end
end

for i = 1 , #enemys[1].EBullets do
if enemys[1].EBullets[i].y <= 310/2 * scale_y and enemys[1].EBullets[i].y >= 160/2 * scale_y and  enemys[2].y <= 370/2 * scale_y and enemys[2].y >= 100/2 * scale_y then
enemys[2].shouldAttack = false
end
end

for i = 1 , #enemys[2].EBullets do
if enemys[2].EBullets[i].y <= 370/2 * scale_y and enemys[2].EBullets[i].y >= 100/2 * scale_y and  enemys[1].y <= 310/2 * scale_y and enemys[1].y >= 160/2 * scale_y then
enemys[1].shouldAttack = false
end
end

for i = 1 , #enemys[2].EBullets do
if enemys[2].EBullets[i].y <= 310/2 * scale_y and enemys[2].EBullets[i].y >= 160/2 * scale_y and  enemys[1].y <= 370/2 * scale_y and enemys[1].y >= 100/2 * scale_y then
enemys[1].shouldAttack = false
end
end

end

end



--function for CHANGING the GAMEPLAY :: ends here




--function for boxCollision check :: starts here ,,, x and y is for position .,. w and h is for width and height 



function CheckCollision(x1,y1,w1,h1, x2,y2,w2,h2)
 return x1 < x2+w2 and
 x2 < x1+w1 and
 y1 < y2+h2 and
 y2 < y1+h1
end



--function for boxCollision check :: ends here



-- player rectangles for CheckCollision :: starts here

function player_rectangles_update ()
    
rect1 = { x = player.x + 11/2 * scale_x , y = player.y + 32/2 * scale_y , w = 31/2 * scale_x , h = 50/2 * scale_y }

rect2 = { x = player.x + 17/2 * scale_x , y = player.y + 88/2 * scale_y , w = 24/2 * scale_x , h = 34/2 * scale_y }

rect3 = { x = player.x + 49/2 * scale_x , y = player.y + 34/2 * scale_y , w =  23/2 * scale_x , h = 16/2 * scale_y }

rect4 = { x = player.x + 20/2 * scale_x , y = player.y + 2/2 * scale_y , w = 15/2 * scale_x , h = 26/2 * scale_y }

rect5 = { x = player.x + 37/2 * scale_x , y = player.y + 84/2 * scale_y , w = 24/2 * scale_x , h = 40/2 * scale_y }

rect6 = { x = player.x + 47/2 * scale_x , y = player.y + 84/2 * scale_y , w = 24/2 * scale_x , h = 36/2 * scale_y }

rect7 = { x = player.x + 33/2 * scale_x , y = player.y + 34/2 * scale_y , w = 31/2 * scale_x , h = 50/2 * scale_y }

rect8 = { x = player.x + 44/2 * scale_x , y = player.y + 2/2 * scale_y , w = 15/2 * scale_x , h = 26/2 * scale_y }

rect9 = { x = player.x + 48/2 * scale_x , y = player.y + 89/2 * scale_y , w = 24/2 * scale_x , h = 36/2 * scale_y }

rect10 = { x = player.x + 49/2 * scale_x , y = player.y + 59/2 * scale_y , w = 16/2 * scale_x , h = 25/2 * scale_y }

rect11 = { x = player.x + 22/2 * scale_x , y = player.y + 45/2 * scale_y , w = 15/2 * scale_x , h = 24/2 * scale_y }




-- rect1 :: body_stand&&movingRight
 
-- rect2 :: legs_stand&&movingRight
    
-- rect3 :: hand_stand&&movingRight __ shouldn't use

-- rect4 :: head_stand&&movingRight

-- rect5 :: leg_jumped

-- rect6 :: legs_movingLeft

-- rect7 :: body_movingLeft

-- rect8 :: head_movingLeft

-- rect9 :: legs_ducked

-- rect10 :: hand_ducked

-- rect11 :: head_ducked

-- rect12 :: Block_usage




end

-- player rectangles for CheckCollision :: ends here




function GAME_PLAY_ENEMYS()



-- CHANGING GAMEPLAY :: starts here 

if enemys[1].isAlive == true or enemys[2].isAlive == true then
if headofmamouth == HEADOFMAMOUTH[6] then

if enemys[1].y <= 790/2 * scale_y and enemys[1].y >= 700/2 * scale_y and enemys[1].shouldAttack == true and enemys[2].y <= 310/2 * scale_y and enemys[2].y >= 160/2 * scale_y and enemys[2].shouldAttack == true then
enemys[2].shouldAttack = false
end

if enemys[2].y <= 790/2 * scale_y and enemys[2].y >= 700/2 * scale_y and enemys[2].shouldAttack == true and enemys[1].y <= 310/2 * scale_y and enemys[1].y >= 160/2 * scale_y and enemys[1].shouldAttack == true then
enemys[2].shouldAttack = false
end

easy_mode()    

else

for i = 1 , #enemys do

if enemys[i].isAlive == true and enemys[i].y < 200/2 * scale_y then 

enemys[i].shouldAttack = false

end
end
end



end

-- CHANGING GAMEPLAY :: ends here



end



function Enemys_Animation ()


--Animation for enemys_helicoopter :: starts here
for i = 1 , #enemys do


if enemys[i].helicoopter_frameSpeed >= 3.5 * 0.018 then
enemys[i].helicoopter_frameSpeed = 0

if enemys[i].changeforpicture == 1 then
if enemys[i].helicoopter_frame < 4 then
	enemys[i].helicoopter_frame = enemys[i].helicoopter_frame + 1
else
	enemys[i].helicoopter_frame = 1
end
end


if enemys[i].changeforpicture == 2 then
if enemys[i].helicoopter_frame < 8 and enemys[i].helicoopter_frame > 4 then
    enemys[i].helicoopter_frame = enemys[i].helicoopter_frame + 1
else
    enemys[i].helicoopter_frame = 5
end
end


if enemys[i].changeforpicture == 3 then
if enemys[i].helicoopter_frame < 12 and enemys[i].helicoopter_frame > 8 then
    enemys[i].helicoopter_frame = enemys[i].helicoopter_frame + 1
else
    enemys[i].helicoopter_frame = 9
end
end


else
	enemys[i].helicoopter_frameSpeed = enemys[i].helicoopter_frameSpeed + 0.028
end
enemys[i].img = enemys[i].helicoopter[enemys[i].helicoopter_frame]


end

--Animation for enemys_helicoopter :: ends here




--Animation for boss.helper :: starts here

if boss.helper.helicoopter_frameSpeed >= 5 * 0.018 then
boss.helper.helicoopter_frameSpeed = 0

if boss.helper.changeforpicture == 1 then
if boss.helper.helicoopter_frame < 4 then
	boss.helper.helicoopter_frame = boss.helper.helicoopter_frame + 1
else
	boss.helper.helicoopter_frame = 1
end
end


if boss.helper.changeforpicture == 2 then
if boss.helper.helicoopter_frame < 8 and boss.helper.helicoopter_frame > 4 then
    boss.helper.helicoopter_frame = boss.helper.helicoopter_frame + 1
else
    boss.helper.helicoopter_frame = 5
end
end


if boss.helper.changeforpicture == 3 then
if boss.helper.helicoopter_frame < 12 and boss.helper.helicoopter_frame > 8 then
    boss.helper.helicoopter_frame = boss.helper.helicoopter_frame + 1
else
    boss.helper.helicoopter_frame = 9
end
end


else
	boss.helper.helicoopter_frameSpeed = boss.helper.helicoopter_frameSpeed + 0.028
end
boss.helper.img = boss.helper.helicoopter[boss.helper.helicoopter_frame]


--Animation for boss.helper :: ends here






end




function scoore_update()

if scoore < 9999 then

SCORES[4].toshow = scoore % 10

SCORES[3].toshow = ((scoore % 100) - SCORES[4].toshow )/10

SCORES[2].toshow = ((scoore % 1000) - SCORES[3].toshow - SCORES[4].toshow)/100 

SCORES[1].toshow = ((scoore % 10000) - SCORES[2].toshow - SCORES[3].toshow - SCORES[4].toshow)/1000 

end

end


ENEMY1_HEALTHBAR_PICTURE = love.graphics.newImage('red_heart.png')
ENEMY2_HEALTHBAR_PICTURE = love.graphics.newImage('blue_heart.png')
ENEMY3_HEALTHBAR_PICTURE = love.graphics.newImage('yellow_heart.png')




function DRAW_HEALTH_BAR_ENEMY(changeforpicture , enemy_health , enemy_isalive , enemy_x , enemy_y)

if changeforpicture == 1 then

if enemy_health == 1 and enemy_isalive == true then

love.graphics.draw(ENEMY1_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end

if enemy_health == 2 then

love.graphics.draw(ENEMY1_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY1_HEALTHBAR_PICTURE , enemy_x + 20/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end

if enemy_health == 3 then

love.graphics.draw(ENEMY1_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY1_HEALTHBAR_PICTURE , enemy_x + 20/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY1_HEALTHBAR_PICTURE , enemy_x + 40/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end


end


if changeforpicture == 2 then

if enemy_health == 1 and enemy_isalive == true then

love.graphics.draw(ENEMY2_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end

if enemy_health == 2 then

love.graphics.draw(ENEMY2_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY2_HEALTHBAR_PICTURE , enemy_x + 20/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end

if enemy_health == 3 then

love.graphics.draw(ENEMY2_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY2_HEALTHBAR_PICTURE , enemy_x + 20/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY2_HEALTHBAR_PICTURE , enemy_x + 40/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end

end


if changeforpicture == 3 then

if enemy_health == 1 and enemy_isalive == true then

love.graphics.draw(ENEMY3_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end

if enemy_health == 2 then

love.graphics.draw(ENEMY3_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY3_HEALTHBAR_PICTURE , enemy_x + 20/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end

if enemy_health == 3 then

love.graphics.draw(ENEMY3_HEALTHBAR_PICTURE , enemy_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY3_HEALTHBAR_PICTURE , enemy_x + 20/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(ENEMY3_HEALTHBAR_PICTURE , enemy_x + 40/2 * scale_x , enemy_y - 10/2 * scale_y , 0 , scale_x , scale_y)

end

end


end




function DRAW_GRASS()




if GRASSES.frameSpeed >= 5 * 0.018 then
GRASSES.frameSpeed = 0


if GRASSES.frame < 4 then
    GRASSES.frame = GRASSES.frame + 1
else
    GRASSES.frame = 1
end

else

GRASSES.frameSpeed = GRASSES.frameSpeed + 0.028

end

GRASSES.img  = GRASSES.GRASS[GRASSES.frame]




love.graphics.draw(GRASSES.img , GRASSES.x , GRASSES.y , 0 , scale_x , scale_y)






if GRASSES1.frameSpeed >= 5 * 0.018 then
GRASSES1.frameSpeed = 0


if GRASSES1.frame < 4 then
    GRASSES1.frame = GRASSES1.frame + 1
else
    GRASSES1.frame = 1
end

else

GRASSES1.frameSpeed = GRASSES1.frameSpeed + 0.028

end

GRASSES1.img  = GRASSES1.GRASS[GRASSES1.frame]





love.graphics.draw(GRASSES1.img , GRASSES1.x , GRASSES1.y , 0 , scale_x , scale_y)





end



--SHWOING GROUND :: starts here 

function GROUND_SHOW()


love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[1] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[2] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[3] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[4] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)

love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[1] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[2] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[3] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[4] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)




end



function DRAW_RAIN()



if THERAIN_frameSpeed >= 5 * 0.018 then
THERAIN_frameSpeed = 0


if THERAIN_frame < 8 then
    THERAIN_frame = THERAIN_frame + 1
else
    THERAIN_frame = 1
end

else

THERAIN_frameSpeed = THERAIN_frameSpeed + 0.028

end

RAIN.img  = THERAIN[THERAIN_frame]
RAIN1.img = THERAIN[THERAIN_frame]





love.graphics.draw(RAIN.img , RAIN.x , RAIN.y , 0 , scale_x , scale_y)
love.graphics.draw(RAIN1.img , RAIN1.x , RAIN1.y , 0 , scale_x , scale_y)



end

function DRAW_RAIN_RED()



if THERAIN_RED_frameSpeed >= 5 * 0.018 then
THERAIN_RED_frameSpeed = 0


if THERAIN_RED_frame < 8 then
    THERAIN_RED_frame = THERAIN_RED_frame + 1
else
    THERAIN_RED_frame = 1
end

else

THERAIN_RED_frameSpeed = THERAIN_RED_frameSpeed + 0.028

end

RAIN_RED.img  = THERAIN_RED[THERAIN_RED_frame]

love.graphics.draw(RAIN_RED.img , RAIN_RED.x , RAIN_RED.y , 0 , scale_x , scale_y)

end


function DRAW_WATER_DROP()

for i = 1 , #WATER_DROP_LB do

if WATER_DROP_LB[i].frameSpeed >= 5 * 0.018 then
WATER_DROP_LB[i].frameSpeed = 0


if WATER_DROP_LB[i].frame < 27 then
    WATER_DROP_LB[i].frame = WATER_DROP_LB[i].frame + 1
else
    WATER_DROP_LB[i].frame = 1
end

else

WATER_DROP_LB[i].frameSpeed = WATER_DROP_LB[i].frameSpeed + 0.028

end


WATER_DROP_LB[i].img  = THEWATER_DROP[WATER_DROP_LB[i].frame]


love.graphics.draw(WATER_DROP_LB[i].img , WATER_DROP_LB[i].x , WATER_DROP_LB[i].y , 0 , scale_x , scale_y)



end


for i = 1 , #WATER_DROP_RB do

if WATER_DROP_RB[i].frameSpeed >= 5 * 0.018 then
WATER_DROP_RB[i].frameSpeed = 0


if WATER_DROP_RB[i].frame < 27 then
    WATER_DROP_RB[i].frame = WATER_DROP_RB[i].frame + 1
else
    WATER_DROP_RB[i].frame = 1
end

else

WATER_DROP_RB[i].frameSpeed = WATER_DROP_RB[i].frameSpeed + 0.028

end


WATER_DROP_RB[i].img  = THEWATER_DROP[WATER_DROP_RB[i].frame]


love.graphics.draw(WATER_DROP_RB[i].img , WATER_DROP_RB[i].x , WATER_DROP_RB[i].y , 0 , scale_x , scale_y)



end


end




function DRAW_WATER_DROP_RED()

for i = 1 , #WATER_DROP_LB_RED do

if WATER_DROP_LB_RED[i].frameSpeed >= 5 * 0.018 then
WATER_DROP_LB_RED[i].frameSpeed = 0


if WATER_DROP_LB_RED[i].frame < 27 then
    WATER_DROP_LB_RED[i].frame = WATER_DROP_LB_RED[i].frame + 1
else
    WATER_DROP_LB_RED[i].frame = 1
end

else

WATER_DROP_LB_RED[i].frameSpeed = WATER_DROP_LB_RED[i].frameSpeed + 0.028

end


WATER_DROP_LB_RED[i].img  = THEWATER_DROP_RED[WATER_DROP_LB_RED[i].frame]


love.graphics.draw(WATER_DROP_LB_RED[i].img , WATER_DROP_LB_RED[i].x , WATER_DROP_LB_RED[i].y , 0 , scale_x , scale_y)



end


end



function DRAW_LIGHTNING()



if THELIGHTNING_R_frameSpeed >= 5 * 0.018 then
THELIGHTNING_R_frameSpeed = 0


if THELIGHTNING_R_frame < 6 then
    THELIGHTNING_R_frame = THELIGHTNING_R_frame + 1
else
    THELIGHTNING_R_frame = 1
end

else

THELIGHTNING_R_frameSpeed = THELIGHTNING_R_frameSpeed + 0.028

end

LIGHTNING_R_1.img  = THELIGHTNING_R[THELIGHTNING_R_frame]
LIGHTNING_R_2.img = THELIGHTNING_R[THELIGHTNING_R_frame]





love.graphics.draw(LIGHTNING_R_1.img , LIGHTNING_R_1.x , LIGHTNING_R_1.y , 0 , scale_x , scale_y)
love.graphics.draw(LIGHTNING_R_2.img , LIGHTNING_R_2.x , LIGHTNING_R_2.y , 0 , scale_x , scale_y)



if THELIGHTNING_L_frameSpeed >= 5 * 0.018 then
THELIGHTNING_L_frameSpeed = 0


if THELIGHTNING_L_frame < 6 then
    THELIGHTNING_L_frame = THELIGHTNING_L_frame + 1
else
    THELIGHTNING_L_frame = 1
end

else

THELIGHTNING_L_frameSpeed = THELIGHTNING_L_frameSpeed + 0.028

end

LIGHTNING_L_1.img  = THELIGHTNING_R[THELIGHTNING_L_frame]
LIGHTNING_L_2.img = THELIGHTNING_R[THELIGHTNING_L_frame]





love.graphics.draw(LIGHTNING_L_1.img , LIGHTNING_L_1.x , LIGHTNING_L_1.y , 0 , scale_x , scale_y)
love.graphics.draw(LIGHTNING_L_2.img , LIGHTNING_L_2.x , LIGHTNING_L_2.y , 0 , scale_x , scale_y)


end






function DRAW_WIND()



if THEWIND_frameSpeed >= 5 * 0.018 then
THEWIND_frameSpeed = 0


if THEWIND_frame < 30 then
    THEWIND_frame = THEWIND_frame + 1
else
    THEWIND_frame = 1
end

else

THEWIND_frameSpeed = THEWIND_frameSpeed + 0.028

end

WIND.img  = THEWIND[THEWIND_frame]
WIND1.img = THEWIND[THEWIND_frame]





love.graphics.draw(WIND.img , WIND.x , WIND.y , 0 , scale_x , scale_y)
love.graphics.draw(WIND1.img , WIND1.x , WIND1.y , 0 , scale_x , scale_y)



end





function DRAW_SUN()



if THESUN_frameSpeed >= 5 * 0.018 then
THESUN_frameSpeed = 0


if THESUN_frame < 6 then
    THESUN_frame = THESUN_frame + 1
else
    THESUN_frame = 1
end

else

THESUN_frameSpeed = THESUN_frameSpeed + 0.028

end

SUN.img  = THESUN[THESUN_frame]
SUN1.img = THESUN[THESUN_frame]





love.graphics.draw(SUN.img , SUN.x , SUN.y , 0 , scale_x , scale_y)
love.graphics.draw(SUN1.img , SUN1.x , SUN1.y , 0 , scale_x , scale_y)



end







function DRAW_FLOWERS()

if theFLOWERS1_frameSpeed >= 5 * 0.018 then
theFLOWERS1_frameSpeed = 0


if theFLOWERS1_frame < 19 then
    theFLOWERS1_frame = theFLOWERS1_frame + 1
else
    theFLOWERS1_frame = 1
end

else

theFLOWERS1_frameSpeed = theFLOWERS1_frameSpeed + 0.028/2

end

FLOWERS1_1.img = theFLOWERS1[theFLOWERS1_frame]
FLOWERS1_2.img = theFLOWERS1[theFLOWERS1_frame]


love.graphics.draw(FLOWERS1_1.img , FLOWERS1_1.x , FLOWERS1_1.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS1_2.img , FLOWERS1_2.x , FLOWERS1_2.y , 0 , scale_x , scale_y)



if theFLOWERS2_frameSpeed >= 5 * 0.018 then
theFLOWERS2_frameSpeed = 0


if theFLOWERS2_frame < 19 then
    theFLOWERS2_frame = theFLOWERS2_frame + 1
else
    theFLOWERS2_frame = 1
end

else

theFLOWERS2_frameSpeed = theFLOWERS2_frameSpeed + 0.028/2

end

FLOWERS2_1.img  = theFLOWERS2[theFLOWERS2_frame]
FLOWERS2_2.img = theFLOWERS2[theFLOWERS2_frame]





love.graphics.draw(FLOWERS2_1.img , FLOWERS2_1.x , FLOWERS2_1.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS2_2.img , FLOWERS2_2.x , FLOWERS2_2.y , 0 , scale_x , scale_y)




if theFLOWERS3_frameSpeed >= 5 * 0.018 then
theFLOWERS3_frameSpeed = 0


if theFLOWERS3_frame < 19 then
    theFLOWERS3_frame = theFLOWERS3_frame + 1
else
    theFLOWERS3_frame = 1
end

else

theFLOWERS3_frameSpeed = theFLOWERS3_frameSpeed + 0.028/2

end

FLOWERS3_1.img  = theFLOWERS3[theFLOWERS3_frame]
FLOWERS3_2.img = theFLOWERS3[theFLOWERS3_frame]





love.graphics.draw(FLOWERS3_1.img , FLOWERS3_1.x , FLOWERS3_1.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS3_2.img , FLOWERS3_2.x , FLOWERS3_2.y , 0 , scale_x , scale_y)





if theFLOWERS4_frameSpeed >= 5 * 0.018 then
theFLOWERS4_frameSpeed = 0


if theFLOWERS4_frame < 19 then
    theFLOWERS4_frame = theFLOWERS4_frame + 1
else
    theFLOWERS4_frame = 1
end

else

theFLOWERS4_frameSpeed = theFLOWERS4_frameSpeed + 0.028/2

end

FLOWERS4_1.img  = theFLOWERS4[theFLOWERS4_frame]
FLOWERS4_2.img = theFLOWERS4[theFLOWERS4_frame]





love.graphics.draw(FLOWERS4_1.img , FLOWERS4_1.x , FLOWERS4_1.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS4_2.img , FLOWERS4_2.x , FLOWERS4_2.y , 0 , scale_x , scale_y)




end
    

function DRAW_BOSS()


if  boss.shouldgethit == false and boss.helper.isAlive == false then

if boss_frameSpeed_ATTACK >= 5 * 0.018 then
boss_frameSpeed_ATTACK = 0


if boss_frame_ATTACK < 11 then
    boss_frame_ATTACK = boss_frame_ATTACK + 1
else
    boss_frame_ATTACK = 1
end

else

boss_frameSpeed_ATTACK = boss_frameSpeed_ATTACK + 0.030/2

end


boss.img = boss.BOSSIMAGES.BOSS_ATTACK[boss_frame_ATTACK]


elseif boss.shouldgethit == true then


if boss_frameSpeed_GETHIT >= 5 * 0.018 then
boss_frameSpeed_GETHIT = 0


if boss_frame_GETHIT < 2 then
    boss_frame_GETHIT = boss_frame_GETHIT + 1
else
    boss_frame_GETHIT = 1
end

else

boss_frameSpeed_GETHIT = boss_frameSpeed_GETHIT + 0.028

end


love.graphics.draw(ATTACK_HELP , 610/2 * scale_x , 150/2 * scale_y , 0 , scale_x , scale_y)
boss.img = boss.BOSSIMAGES.BOSS_GETHIT[boss_frame_GETHIT] 



elseif boss.shouldgethit == false and boss.helper.isAlive == true then


if boss_frameSpeed_WAIT >= 5 * 0.018 then
boss_frameSpeed_WAIT = 0


if boss_frame_WAIT < 11 then
    boss_frame_WAIT = boss_frame_WAIT + 1
else
    boss_frame_WAIT = 1
end

else

boss_frameSpeed_WAIT = boss_frameSpeed_WAIT + 0.028

end


boss.img = boss.BOSSIMAGES.BOSS_WAIT[boss_frame_WAIT]


end

love.graphics.draw(boss.img , boss.x , boss.y , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill' , boss.x + 140 , boss.y + 170 , 30 , 180)

end

function FPS()

T = T + DELTA_T
if T > Tlimit then
T = 0
return true
else
return false    
end

end    




function DRAW_BOSS_DEAD()

if BOSS_DEAD_shouldshow == true  then

BOSS_DEAD_t = BOSS_DEAD_t + 1

if BOSS_DEAD_t <= BOSS_DEAD_timeforshow then

love.graphics.draw(BOSS_DEAD , BOSS_DEAD_X , BOSS_DEAD_Y , 0 , scale_x , scale_y)

end

if BOSS_DEAD_t > BOSS_DEAD_timeforshow then
BOSS_DEAD_t = 0
BOSS_DEAD_shouldshow = false
end


if THEFLAMES_frameSpeed >= 5 * 0.018 then
THEFLAMES_frameSpeed = 0


if THEFLAMES_frame < 17 then
    THEFLAMES_frame = THEFLAMES_frame + 1
else
    THEFLAMES_frame = 1
end

else

THEFLAMES_frameSpeed = THEFLAMES_frameSpeed + 0.028/2

end

FLAMES_BOSS1.img = THEFLAMES[THEFLAMES_frame]

love.graphics.draw(FLAMES_BOSS1.img , FLAMES_BOSS1.x , FLAMES_BOSS1.y , 0 , scale_x , scale_y)


end


end













function DRAW_BOSS2()


if  boss2.shouldgethit == false and boss2.SECOND_ATTACK == false then

if boss2_frameSpeed_ATTACK >= 5 * 0.018 then
boss2_frameSpeed_ATTACK = 0


if boss2_frame_ATTACK < 24 then
    boss2_frame_ATTACK = boss2_frame_ATTACK + 1
else
    boss2_frame_ATTACK = 1
end

else

boss2_frameSpeed_ATTACK = boss2_frameSpeed_ATTACK + 0.0899/4

end


boss2.img = boss2.BOSSIMAGES.BOSS_ATTACK[boss2_frame_ATTACK]


love.graphics.draw(boss2.img , boss2.x - 200/2 * scale_x , boss2.y - 10/2 * scale_y , 0 , scale_x , scale_y)


elseif boss2.shouldgethit == true then


if boss2_frameSpeed_GETHIT >= 5 * 0.018 then
boss2_frameSpeed_GETHIT = 0


if boss2_frame_GETHIT < 4 then
    boss2_frame_GETHIT = boss2_frame_GETHIT + 1
else
    boss2_frame_GETHIT = 1
end

else

boss2_frameSpeed_GETHIT = boss2_frameSpeed_GETHIT + 0.028

end


boss2.img = boss2.BOSSIMAGES.BOSS_GETHIT[boss2_frame_GETHIT]

love.graphics.draw(ATTACK_HELP , 510/2 * scale_x , 70/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(boss2.img , boss2.x - 200/2 * scale_x , boss2.y - 10/2 * scale_y , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill' , boss2.x - 10 , boss2.y + 100 , 120 , 220)



elseif boss2.shouldgethit == false and boss2.SECOND_ATTACK == true then


if boss2_frameSpeed_WAIT >= 5 * 0.028 then
boss2_frameSpeed_WAIT = 0


if boss2_frame_WAIT < 10 then
    boss2_frame_WAIT = boss2_frame_WAIT + 1
else
    boss2_frame_WAIT = 1
end

else

boss2_frameSpeed_WAIT = boss2_frameSpeed_WAIT + 0.046666666666666/2.05

end


boss2.img = boss2.BOSSIMAGES.BOSS_WAIT[boss2_frame_WAIT]




love.graphics.draw(boss2.img , boss2.x - 120/2 * scale_x , boss2.y - 230/2 * scale_y , 0 , scale_x , scale_y)

end





end





function DRAW_BOSS2_DEAD()

if BOSS2_DEAD_shouldshow == true  then

if player.x >= 215/2 * scale_x then
    player.x = player.x
end

BOSS2_DEAD_t = BOSS2_DEAD_t + 1

if BOSS2_DEAD_t <= BOSS2_DEAD_timeforshow then

love.graphics.draw(BOSS2_DEAD , boss2.x - 220/2 * scale_x , boss2.y , 0 , scale_x , scale_y)

end

if BOSS2_DEAD_t > BOSS2_DEAD_timeforshow then
BOSS2_DEAD_t = 0
BOSS2_DEAD_shouldshow = false
end



if THEFLAMES_frameSpeed >= 5 * 0.018 then
THEFLAMES_frameSpeed = 0


if THEFLAMES_frame < 17 then
    THEFLAMES_frame = THEFLAMES_frame + 1
else
    THEFLAMES_frame = 1
end

else

THEFLAMES_frameSpeed = THEFLAMES_frameSpeed + 0.028/2

end

FLAMES_BOSS2.img = THEFLAMES[THEFLAMES_frame]

love.graphics.draw(FLAMES_BOSS2.img , FLAMES_BOSS2.x , FLAMES_BOSS2.y , 0 , scale_x , scale_y)


end

end







function BOSS2_DRIL()

if boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[17] then

if player.y >= 325/2 * scale_y then        
player_GOT_DRIL = true
else
player_GOT_DRIL = false
end

if player_GOT_DRIL == true then
if player_should_dril == true then
playerGETTREMBL()
player_should_dril = false
end



end

else



player_should_dril = true



end

end


function BOSS2_TREMBL()


if boss2.img == boss2.BOSSIMAGES.BOSS_WAIT[8] or boss2.img == boss2.BOSSIMAGES.BOSS_WAIT[9] then



if jumping == false then        
player_GOT_TREMBL = true
else
player_GOT_TREMBL = false
end

if player_GOT_TREMBL == true then
if player_should_trembl == true then
playerGETTREMBL()
player_should_trembl = false
end
end

else

player_should_trembl  = true    

end

end



function DRAW_BACKGROUND_BOSS3()



if BACKGROUND3_frameSpeed >= 5 * 0.018 then
BACKGROUND3_frameSpeed = 0


if BACKGROUND3_frame < 19 then
    BACKGROUND3_frame = BACKGROUND3_frame + 1
else
    BACKGROUND3_frame = 1
end

else

BACKGROUND3_frameSpeed = BACKGROUND3_frameSpeed + 0.028/2

end

BACKGROUND3_IMG  = BACKGROUND3[BACKGROUND3_frame]

BOSS3_TREMBL()
BOSS3_MAKING_EARTH_SHAKE()

love.graphics.draw(BACKGROUND3_IMG , background2.x , background2.y , 0 , scale_x , scale_y)

end





function DRAW_BOSS3()


if boss3.changeToLight == true then

BOSS3_LIGHT()

else



if boss3.shouldgethit == false and boss3.FIRST_ATTACK == true and boss3.SECOND_ATTACK == false and boss3.THIRD_ATTACK == false then


if boss3.RANDOM_ATTACK == 1 then

BOSS3_FIRE()

elseif boss3.RANDOM_ATTACK == 2 then

BOSS3_GLAD()

elseif boss3.RANDOM_ATTACK == 3 then

BOSS3_GOUL()

elseif boss3.RANDOM_ATTACK == 4 then

BOSS3_SKEL()

elseif boss3.RANDOM_ATTACK == 5 then

BOSS3_CREEP()

end


elseif boss3.shouldgethit == false and boss3.FIRST_ATTACK == false and boss3.SECOND_ATTACK == true and boss3.THIRD_ATTACK == false then


if boss3.RANDOM_ATTACK == 1 then

BOSS3_FIRE()

elseif boss3.RANDOM_ATTACK == 2 then

BOSS3_GLAD()

elseif boss3.RANDOM_ATTACK == 3 then

BOSS3_GOUL()

elseif boss3.RANDOM_ATTACK == 4 then

BOSS3_SKEL()

elseif boss3.RANDOM_ATTACK == 5 then

BOSS3_CREEP()

end


elseif boss3.shouldgethit == false and boss3.FIRST_ATTACK == false and boss3.SECOND_ATTACK == false and boss3.THIRD_ATTACK == true then


if boss3.RANDOM_ATTACK == 1 then

BOSS3_FIRE()

elseif boss3.RANDOM_ATTACK == 2 then

BOSS3_GLAD()

elseif boss3.RANDOM_ATTACK == 3 then

BOSS3_GOUL()

elseif boss3.RANDOM_ATTACK == 4 then

BOSS3_SKEL()

elseif boss3.RANDOM_ATTACK == 5 then

BOSS3_CREEP()

end


elseif boss3.shouldgethit == true and boss3.FIRST_ATTACK == false and boss3.SECOND_ATTACK == false and boss3.THIRD_ATTACK == false then


if boss3_frameSpeed_GETHIT >= 5 * 0.018 then
boss3_frameSpeed_GETHIT  = 0


if boss3_frame_GETHIT < 8 then
    boss3_frame_GETHIT = boss3_frame_GETHIT + 1
else
    boss3_frame_GETHIT = 1
end

else

boss3_frameSpeed_GETHIT  = boss3_frameSpeed_GETHIT  + 0.028/2

end

boss3.img  = boss3.BOSSIMAGES.BOSS_GETHIT[boss3_frame_GETHIT]

love.graphics.draw(ATTACK_HELP , 550/2 * scale_x , 200/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(boss3.img , boss3.x - 20/2 * scale_x , boss3.y + 100/2 * scale_y , 0 , scale_x , scale_y)
--love.graphics.rectangle('fill' , boss3.x + 50 , boss3.y + 240 , 110 , 130)


end

end

end



function BOSS3_LIGHT()

if boss3_frameSpeed_TO_LIGHT >= 5 * 0.018 then
boss3_frameSpeed_TO_LIGHT  = 0


if boss3_frame_TO_LIGHT < 4 then
    boss3_frame_TO_LIGHT = boss3_frame_TO_LIGHT + 1
else
    boss3_frame_TO_LIGHT = 1
end

else

boss3_frameSpeed_TO_LIGHT  = boss3_frameSpeed_TO_LIGHT  + 0.028/2

end

boss3.img  = boss3.BOSSIMAGES.BOSS3_TO_LIGHT[boss3_frame_TO_LIGHT]

love.graphics.draw(boss3.img , boss3.x - 90/2 * scale_x , boss3.y + 120/2 * scale_y , 0 , scale_x , scale_y)

end



function BOSS3_FIRE()

if boss3_frameSpeed_TO_FIRE >= 5 * 0.018 then
boss3_frameSpeed_TO_FIRE  = 0


if boss3_frame_TO_FIRE < 30 then
    boss3_frame_TO_FIRE = boss3_frame_TO_FIRE + 1
else
    boss3_frame_TO_FIRE = 1
end

else

boss3_frameSpeed_TO_FIRE  = boss3_frameSpeed_TO_FIRE  + 0.2/2

end

boss3.img  = boss3.BOSSIMAGES.BOSS3_TO_FIRE[boss3_frame_TO_FIRE]

love.graphics.draw(boss3.img , boss3.x - 10/2 * scale_x , boss3.y + 60/2 * scale_y , 0 , scale_x , scale_y)

end



function BOSS3_GLAD()

if boss3_frameSpeed_TO_GLAD >= 5 * 0.018 then
boss3_frameSpeed_TO_GLAD  = 0


if boss3_frame_TO_GLAD < 35 then
    boss3_frame_TO_GLAD = boss3_frame_TO_GLAD + 1
else
    boss3_frame_TO_GLAD = 1
end

else

boss3_frameSpeed_TO_GLAD  = boss3_frameSpeed_TO_GLAD  + 0.08

end

boss3.img  = boss3.BOSSIMAGES.BOSS3_TO_GLAD[boss3_frame_TO_GLAD]

love.graphics.draw(boss3.img , boss3.x - 70/2 * scale_x , boss3.y + 80/2 * scale_y , 0 , scale_x , scale_y)

end



function BOSS3_GOUL()

if boss3_frameSpeed_TO_GOUL >= 5 * 0.018 then
boss3_frameSpeed_TO_GOUL  = 0


if boss3_frame_TO_GOUL < 27 then
    boss3_frame_TO_GOUL = boss3_frame_TO_GOUL + 1
else
    boss3_frame_TO_GOUL = 1
end

else

boss3_frameSpeed_TO_GOUL  = boss3_frameSpeed_TO_GOUL  + 0.047 * 1/5

end

boss3.img  = boss3.BOSSIMAGES.BOSS3_TO_GOUL[boss3_frame_TO_GOUL]

love.graphics.draw(boss3.img , boss3.x - 180/2 * scale_x , boss3.y - 200/2 * scale_y , 0 , scale_x , scale_y)

end



function BOSS3_SKEL()

if boss3_frameSpeed_TO_SKEL >= 5 * 0.018 then
boss3_frameSpeed_TO_SKEL  = 0


if boss3_frame_TO_SKEL < 22 then
    boss3_frame_TO_SKEL = boss3_frame_TO_SKEL + 1
else
    boss3_frame_TO_SKEL = 1
end

else

boss3_frameSpeed_TO_SKEL  = boss3_frameSpeed_TO_SKEL  + 0.045 * 1/3.9

end

boss3.img  = boss3.BOSSIMAGES.BOSS3_TO_SKEL[boss3_frame_TO_SKEL]


--function for position and draw
BOSS3_TO_SKEL_DECIDE_POSITION()


end



function BOSS3_CREEP()

if boss3_frameSpeed_TO_CREEP >= 5 * 0.018 then
boss3_frameSpeed_TO_CREEP  = 0


if boss3_frame_TO_CREEP < 36 then
    boss3_frame_TO_CREEP = boss3_frame_TO_CREEP + 1
else
    boss3_frame_TO_CREEP = 1
end

else

boss3_frameSpeed_TO_CREEP  = boss3_frameSpeed_TO_CREEP  + 0.08/2

end

boss3.img  = boss3.BOSSIMAGES.BOSS3_TO_CREEP[boss3_frame_TO_CREEP]

love.graphics.draw(boss3.img , boss3.x - 40/2 * scale_x , boss3.y + 100/2 * scale_y , 0 , scale_x , scale_y)

end






function DRAW_BOSS3_DEAD()

if BOSS3_DEAD_shouldshow == true  then

if player.x >= 215 * scale_x then
    player.x = player.x
end

BOSS3_DEAD_t = BOSS3_DEAD_t + 1

if BOSS3_DEAD_t <= BOSS3_DEAD_timeforshow then

love.graphics.draw(BOSS3_DEAD , boss3.x + 10/2 * scale_x , boss3.y + 180/2 * scale_y , 0 , scale_x , scale_y)

end

if BOSS3_DEAD_t > BOSS3_DEAD_timeforshow then
BOSS3_DEAD_t = 0
BOSS3_DEAD_shouldshow = false
end



if THEFLAMES_frameSpeed >= 5 * 0.018 then
THEFLAMES_frameSpeed = 0


if THEFLAMES_frame < 17 then
    THEFLAMES_frame = THEFLAMES_frame + 1
else
    THEFLAMES_frame = 1
end

else

THEFLAMES_frameSpeed = THEFLAMES_frameSpeed + 0.028/2

end

FLAMES_BOSS3.img = THEFLAMES[THEFLAMES_frame]

love.graphics.draw(FLAMES_BOSS3.img , FLAMES_BOSS3.x , FLAMES_BOSS3.y , 0 , scale_x , scale_y)


end

end



-- function for BOSS3_TO_FIRE_ATTACK
function BOSS3_TO_FIRE_SHOULD_ATTACK()

for i = 1 , 30 do 

if boss3.img == boss3.BOSSIMAGES.BOSS3_TO_FIRE[i] then

return true 


end       

end

end


-- function for BOSS3_TO_GOUL_ATTACK
function BOSS3_TO_GOUL_SHOULD_ATTACK1()

return boss3.img == boss3.BOSSIMAGES.BOSS3_TO_GOUL[8] 

end

function BOSS3_TO_GOUL_SHOULD_ATTACK2()

return  boss3.img == boss3.BOSSIMAGES.BOSS3_TO_GOUL[16] 

end

function BOSS3_TO_GOUL_SHOULD_ATTACK3()

return boss3.img == boss3.BOSSIMAGES.BOSS3_TO_GOUL[25]  

end

function BOSS3_MAKING_EARTH_SHAKE()


if BOSS3_TO_GOUL_SHOULD_ATTACK1() or BOSS3_TO_GOUL_SHOULD_ATTACK2() or BOSS3_TO_GOUL_SHOULD_ATTACK3() then

if boss3_upTremble == true then
background2.y =  - 2/2 * scale_y
boss3_upTremble_T = boss3_upTremble_T + 1
if boss3_upTremble_T >= Tremble_Tlimit_boss3 then
boss3_upTremble_T = 0
boss3_upTremble = false
boss3_midTremble = true
end
end

if boss3_midTremble == true then
background2.y = 0
boss3_midTremble_T = boss3_midTremble_T + 1
if boss3_midTremble_T >= Tremble_Tlimit_boss3 then
boss3_midTremble_T = 0
boss3_midTremble = false
boss3_downTremble = true
end
end

if boss3_downTremble == true then
background2.y = 2/2 * scale_y
boss3_downTremble_T = boss3_downTremble_T + 1
if boss3_downTremble_T >= Tremble_Tlimit_boss3 then
boss3_downTremble_T = 0
boss3_downTremble = false
boss3_mid2Tremble = true
end
end

if boss3_mid2Tremble == true then
background2.y = 0
boss3_mid2Tremble_T = boss3_mid2Tremble_T + 1
if boss3_mid2Tremble_T >= Tremble_Tlimit_boss3 then
boss3_mid2Tremble_T = 0
boss3_mid2Tremble = false
boss3_upTremble = true
end
end

else

background2.y = 0

end    
end



function BOSS3_TREMBL()


if BOSS3_TO_GOUL_SHOULD_ATTACK1() then


if jumping == false then        
player_GOT_TREMBL1 = true
else
player_GOT_TREMBL1 = false
end

if player_GOT_TREMBL1 == true then
if player_should_trembl1 == true then
playerGETTREMBL()
player_should_trembl1 = false
end
end

elseif not BOSS3_TO_GOUL_SHOULD_ATTACK1() then

player_should_trembl1  = true    

end



if BOSS3_TO_GOUL_SHOULD_ATTACK2() then


if jumping == false then        
player_GOT_TREMBL2 = true
else
player_GOT_TREMBL2 = false
end

if player_GOT_TREMBL2 == true then
if player_should_trembl2 == true then
playerGETTREMBL()
player_should_trembl2 = false
end
end

elseif not BOSS3_TO_GOUL_SHOULD_ATTACK2() then

player_should_trembl2  = true    

end


if BOSS3_TO_GOUL_SHOULD_ATTACK3() then


if jumping == false then        
player_GOT_TREMBL3 = true
else
player_GOT_TREMBL3 = false
end

if player_GOT_TREMBL3 == true then
if player_should_trembl3 == true then
playerGETTREMBL()
player_should_trembl3 = false
end
end

elseif not BOSS3_TO_GOUL_SHOULD_ATTACK3() then

player_should_trembl3  = true    

end


end

  

-- function for BOSS3_TO_SKEL_ATTACK
function BOSS3_TO_SKEL_SHOULD_ATTACK()

return boss3.img == boss3.BOSSIMAGES.BOSS3_TO_SKEL[10] or boss3.img == boss3.BOSSIMAGES.BOSS3_TO_SKEL[11]  

end

function BOSS3_TO_SKEL_END_OF_ATTACK()

if boss3.img  == boss3.BOSSIMAGES.BOSS3_TO_SKEL[22] then   

skeleton_end_of_move = true

end

end

function BOSS3_TO_SKEL_CHANGE_POSITION()

if skeleton_end_of_move == true then

skeleton_position = love.math.random(1,2)
boss3_frame_TO_SKEL = 1

end

skeleton_end_of_move = false


end


function BOSS3_TO_SKEL_DECIDE_POSITION()

if skeleton_position == 1 then

love.graphics.draw(boss3.img , boss3.x - 660/2 * scale_x , boss3.y - 95/2 * scale_y , 0 , scale_x , scale_y)

elseif skeleton_position == 2 then

love.graphics.draw(boss3.img , boss3.x - 660/2 * scale_x , boss3.y - 205/2 * scale_y , 0 , scale_x , scale_y)

end

end

function BOSS3_TO_SKEL_ATTACK()

if BOSS3_TO_SKEL_SHOULD_ATTACK() then


if skeleton_position == 1 and player.y > 76/2 * scale_y then        
GOT_SKEL_ATTACK1 = true
else
GOT_SKEL_ATTACK1 = false
end

if GOT_SKEL_ATTACK1 == true then
if SHOULD_GET_SKEL_ATTACK == true then
playerGETTREMBL()
SHOULD_GET_SKEL_ATTACK = false
end
end


if skeleton_position == 2 and player.y <= 210/2 * scale_y then        
GOT_SKEL_ATTACK2 = true
else
GOT_SKEL_ATTACK2 = false
end

if GOT_SKEL_ATTACK2 == true then
if SHOULD_GET_SKEL_ATTACK == true then
playerGETTREMBL()
SHOULD_GET_SKEL_ATTACK = false
end
end




elseif not BOSS3_TO_SKEL_SHOULD_ATTACK() then

SHOULD_GET_SKEL_ATTACK  = true    

end

end  



-- function for BOSS3_TO_CREEP_ATTACK
function BOSS3_TO_CREEP_SHOULD_ATTACK()

for i = 1 , 36 do

if boss3.img == boss3.BOSSIMAGES.BOSS3_TO_CREEP[i] then

return true

end    

end

end


-- function for BOSS3_TO_GLAD_ATTACK
function BOSS3_TO_GLAD_SHOULD_ATTACK()

for i = 1 , 35 do

if boss3.img == boss3.BOSSIMAGES.BOSS3_TO_GLAD[i] then

return true

end    

end

end






function DRAW_CONGRATULATION()

--if should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == true and boss2_finished == false and should_summon_boss3 == false and boss3_finished == false and pass1 == 1 then --or 
--should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == true and boss3_finished == false  or
--should_summon_boss1 == true and boss1_finished == false and should_summon_boss2 == false and boss2_finished == false and should_summon_boss3 == false and boss3_finished == false  and enemys[1].isAlive == false and enemys[2].isAlive == false and boss.helper.isAlive == false and boss.isAlive == false then

--if should_summon_boss1 == false and should_summon_boss2 == false and should_summon_boss3 == false and enemys[1] == false and enemys[2] == false and boss.helper.isAlive == false and boss.isAlive == false and boss2.isAlive == false and boss3.isAlive == false then
--PURPLE

if CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then


love.graphics.draw(wing1_congs.img , wing1_congs.x , wing1_congs.y , 0 , scale_x , scale_y)
love.graphics.draw(wing2_congs.img , wing2_congs.x , wing2_congs.y , 0 , scale_x , scale_y)


--PURPLE
if PURPLE_CONG_FRAME_SPEED >= 5 * 0.018 then
PURPLE_CONG_FRAME_SPEED  = 0


if PURPLE_CONG_FRAME < 4 then
    PURPLE_CONG_FRAME = PURPLE_CONG_FRAME + 1
else
    PURPLE_CONG_FRAME = 1
end

else

PURPLE_CONG_FRAME_SPEED  = PURPLE_CONG_FRAME_SPEED  + 0.045

end

CONG1.img = PURPLE_CONG[PURPLE_CONG_FRAME]

love.graphics.draw(CONG1.img , CONG1.x , CONG1.y , 0 , scale_x , scale_y)



--BLUE
if BLUE_CONG_FRAME_SPEED >= 5 * 0.018 then
BLUE_CONG_FRAME_SPEED  = 0


if BLUE_CONG_FRAME < 4 then
    BLUE_CONG_FRAME = BLUE_CONG_FRAME + 1
else
    BLUE_CONG_FRAME = 1
end

else

BLUE_CONG_FRAME_SPEED  = BLUE_CONG_FRAME_SPEED  + 0.045

end

CONG2.img = BLUE_CONG[BLUE_CONG_FRAME]

love.graphics.draw(CONG2.img , CONG2.x , CONG2.y , 0 , scale_x , scale_y)




--GREEN
if GREEN_CONG_FRAME_SPEED >= 5 * 0.018 then
GREEN_CONG_FRAME_SPEED  = 0


if GREEN_CONG_FRAME < 4 then
    GREEN_CONG_FRAME = GREEN_CONG_FRAME + 1
else
    GREEN_CONG_FRAME = 1
end

else

GREEN_CONG_FRAME_SPEED  = GREEN_CONG_FRAME_SPEED  + 0.045

end

CONG3.img = GREEN_CONG[GREEN_CONG_FRAME]

love.graphics.draw(CONG3.img , CONG3.x , CONG3.y , 0 , scale_x , scale_y)



--YELLOW
if YELLOW_CONG_FRAME_SPEED >= 5 * 0.018 then
YELLOW_CONG_FRAME_SPEED  = 0


if YELLOW_CONG_FRAME < 4 then
    YELLOW_CONG_FRAME = YELLOW_CONG_FRAME + 1
else
    YELLOW_CONG_FRAME = 1
end

else

YELLOW_CONG_FRAME_SPEED  = YELLOW_CONG_FRAME_SPEED  + 0.045

end

CONG4.img = YELLOW_CONG[YELLOW_CONG_FRAME]

love.graphics.draw(CONG4.img , CONG4.x , CONG4.y , 0 , scale_x , scale_y)



--PURPLE_1
if PURPLE_CONG_FRAME_SPEED >= 5 * 0.018 then
PURPLE_CONG_FRAME_SPEED  = 0


if PURPLE_CONG_FRAME < 4 then
    PURPLE_CONG_FRAME = PURPLE_CONG_FRAME + 1
else
    PURPLE_CONG_FRAME = 1
end

else

PURPLE_CONG_FRAME_SPEED  = PURPLE_CONG_FRAME_SPEED  + 0.045

end

CONG1_1.img = PURPLE_CONG[PURPLE_CONG_FRAME]

love.graphics.draw(CONG1_1.img , CONG1_1.x , CONG1_1.y , 0 , scale_x , scale_y)



--BLUE_1
if BLUE_CONG_FRAME_SPEED >= 5 * 0.018 then
BLUE_CONG_FRAME_SPEED  = 0


if BLUE_CONG_FRAME < 4 then
    BLUE_CONG_FRAME = BLUE_CONG_FRAME + 1
else
    BLUE_CONG_FRAME = 1
end

else

BLUE_CONG_FRAME_SPEED  = BLUE_CONG_FRAME_SPEED  + 0.045

end

CONG2_1.img = BLUE_CONG[BLUE_CONG_FRAME]

love.graphics.draw(CONG2_1.img , CONG2_1.x , CONG2_1.y , 0 , scale_x , scale_y)




--GREEN_1
if GREEN_CONG_FRAME_SPEED >= 5 * 0.018 then
GREEN_CONG_FRAME_SPEED  = 0


if GREEN_CONG_FRAME < 4 then
    GREEN_CONG_FRAME = GREEN_CONG_FRAME + 1
else
    GREEN_CONG_FRAME = 1
end

else

GREEN_CONG_FRAME_SPEED  = GREEN_CONG_FRAME_SPEED  + 0.045

end

CONG3_1.img = GREEN_CONG[GREEN_CONG_FRAME]

love.graphics.draw(CONG3_1.img , CONG3_1.x , CONG3_1.y , 0 , scale_x , scale_y)



--YELLOW
if YELLOW_CONG_FRAME_SPEED >= 5 * 0.018 then
YELLOW_CONG_FRAME_SPEED  = 0


if YELLOW_CONG_FRAME < 4 then
    YELLOW_CONG_FRAME = YELLOW_CONG_FRAME + 1
else
    YELLOW_CONG_FRAME = 1
end

else

YELLOW_CONG_FRAME_SPEED  = YELLOW_CONG_FRAME_SPEED  + 0.045

end

CONG4_1.img = YELLOW_CONG[YELLOW_CONG_FRAME]

love.graphics.draw(CONG4_1.img , CONG4_1.x , CONG4_1.y , 0 , scale_x , scale_y)


--white_flying_bird


if WHITE_FLYINGBIRD_frameSpeed >= 8 * 0.018 then
WHITE_FLYINGBIRD_frameSpeed  = 0


if WHITE_FLYINGBIRD_frame < 11 then
    WHITE_FLYINGBIRD_frame = WHITE_FLYINGBIRD_frame + 1
else
    WHITE_FLYINGBIRD_frame = 1
end

else

WHITE_FLYINGBIRD_frameSpeed  = WHITE_FLYINGBIRD_frameSpeed  + 0.028

end

white_flyingbird1.img = WHITE_FLYINGBIRD[WHITE_FLYINGBIRD_frame]
white_flyingbird2.img = WHITE_FLYINGBIRD_L[WHITE_FLYINGBIRD_frame]

white_flyingbird3.img = WHITE_FLYINGBIRD[WHITE_FLYINGBIRD_frame]
white_flyingbird4.img = WHITE_FLYINGBIRD_L[WHITE_FLYINGBIRD_frame]



love.graphics.draw(CONGRATULATION , player.x , player.y - 150/2 * scale_y , 0 , scale_x , scale_y)

love.graphics.draw(white_flyingbird1.img , white_flyingbird1.x , white_flyingbird1.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird2.img , white_flyingbird2.x , white_flyingbird2.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird3.img , white_flyingbird3.x , white_flyingbird3.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird4.img , white_flyingbird4.x , white_flyingbird4.y , 0 , scale_x , scale_y)


end

end





function menu_animation()

if menu_anim_framespeed >= 5 * 0.018 then
menu_anim_framespeed  = 0


if menu_anim_frame < 10 then
    menu_anim_frame = menu_anim_frame + 1
else
    menu_anim_frame = 1
end

else

menu_anim_framespeed  = menu_anim_framespeed  + 0.028/2

end

menu = menu_anim[menu_anim_frame]

end

function is_base_menu()

return (menu ~= SCORE_IMAGE and menu ~= amuzesh and studio_bool == false)

end


function menu_pad_choice()

if menu_pad == menu_pad_b then

set()
GAME_PlAY = true



elseif menu_pad == menu_pad then

menu = amuzesh
menu_pad = menu_pad_bazgasht




elseif menu_pad == menu_pad_s then

menu = SCORE_IMAGE
menu_pad = menu_pad_bazgasht




elseif menu_pad == menu_pad_e then

love.event.quit()


end



end








function pasus_display()





love.graphics.draw(background1.img , background1.x , background1.y , 0 , scale_x , scale_y)
love.graphics.draw(background2.img , background2.x , background1.y , 0 , scale_x , scale_y)

if not( CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false) then
love.graphics.draw(Crow1.img , Crow1.x , Crow1.y , 0 , scale_x , scale_y)
love.graphics.draw(flyingbird.img , flyingbird.x , flyingbird.y , 0 , scale_x , scale_y)
end

if enemys[1].isAlive == true or enemys[2].isAlive == true or boss.isAlive == true then
love.graphics.draw(deadline,300/2 * scale_x ,0 , 0 , scale_x , scale_y)
end



if should_summon_boss1 == true then
love.graphics.draw(RAIN.img , RAIN.x , RAIN.y , 0 , scale_x , scale_y)
love.graphics.draw(RAIN1.img , RAIN1.x , RAIN1.y , 0 , scale_x , scale_y)

love.graphics.draw(LIGHTNING_R_1.img , LIGHTNING_R_1.x , LIGHTNING_R_1.y , 0 , scale_x , scale_y)
love.graphics.draw(LIGHTNING_R_2.img , LIGHTNING_R_2.x , LIGHTNING_R_2.y , 0 , scale_x , scale_y)

love.graphics.draw(LIGHTNING_L_1.img , LIGHTNING_L_1.x , LIGHTNING_L_1.y , 0 , scale_x , scale_y)
love.graphics.draw(LIGHTNING_L_2.img , LIGHTNING_L_2.x , LIGHTNING_L_2.y , 0 , scale_x , scale_y)

for i = 1 , 27 do
love.graphics.draw(WATER_DROP_LB[i].img , WATER_DROP_LB[i].x , WATER_DROP_LB[i].y , 0 , scale_x , scale_y)
love.graphics.draw(WATER_DROP_RB[i].img , WATER_DROP_RB[i].x , WATER_DROP_RB[i].y , 0 , scale_x , scale_y)
end

end



if should_summon_boss2 == true then

love.graphics.draw(SUN.img , SUN.x , SUN.y , 0 , scale_x , scale_y)
love.graphics.draw(SUN1.img , SUN1.x , SUN1.y , 0 , scale_x , scale_y)

love.graphics.draw(WIND.img , WIND.x , WIND.y , 0 , scale_x , scale_y)
love.graphics.draw(WIND1.img , WIND1.x , WIND1.y , 0 , scale_x , scale_y)

love.graphics.draw(FLOWERS1_1.img , FLOWERS1_1.x , FLOWERS1_1.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS1_2.img , FLOWERS1_2.x , FLOWERS1_2.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS2_1.img , FLOWERS2_1.x , FLOWERS2_1.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS2_2.img , FLOWERS2_2.x , FLOWERS2_2.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS3_1.img , FLOWERS3_1.x , FLOWERS3_1.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS3_2.img , FLOWERS3_2.x , FLOWERS3_2.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS4_1.img , FLOWERS4_1.x , FLOWERS4_1.y , 0 , scale_x , scale_y)
love.graphics.draw(FLOWERS4_2.img , FLOWERS4_2.x , FLOWERS4_2.y , 0 , scale_x , scale_y)



if boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[16] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[17] then
love.graphics.draw(JAG , player.x , 430/2 * scale_y , 0 , scale_x , scale_y)
end




if boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[12] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[13] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[14] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[15] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[16] or boss2.img == boss2.BOSSIMAGES.BOSS_ATTACK[17] then
love.graphics.draw(JAG_NOT , player.x , player.y - 100/2 * scale_y , 0 , scale_x , scale_y)
end


end

if CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then
love.graphics.draw(wing1_congs.img , wing1_congs.x , wing1_congs.y , 0 , scale_x , scale_y)
love.graphics.draw(wing2_congs.img , wing2_congs.x , wing2_congs.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG1.img , CONG1.x , CONG1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG2.img , CONG2.x , CONG2.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG3.img , CONG3.x , CONG3.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG4.img , CONG4.x , CONG4.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG1_1.img , CONG1_1.x , CONG1_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG2_1.img , CONG2_1.x , CONG2_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG3_1.img , CONG3_1.x , CONG3_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG4_1.img , CONG4_1.x , CONG4_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONGRATULATION , player.x , player.y - 150/2 * scale_y , 0 , scale_x , scale_y)

love.graphics.draw(white_flyingbird1.img , white_flyingbird1.x , white_flyingbird1.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird2.img , white_flyingbird2.x , white_flyingbird2.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird3.img , white_flyingbird3.x , white_flyingbird3.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird4.img , white_flyingbird4.x , white_flyingbird4.y , 0 , scale_x , scale_y)
end

if CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then
love.graphics.draw(wing1_congs.img , wing1_congs.x , wing1_congs.y , 0 , scale_x , scale_y)
love.graphics.draw(wing2_congs.img , wing2_congs.x , wing2_congs.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG1.img , CONG1.x , CONG1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG2.img , CONG2.x , CONG2.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG3.img , CONG3.x , CONG3.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG4.img , CONG4.x , CONG4.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG1_1.img , CONG1_1.x , CONG1_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG2_1.img , CONG2_1.x , CONG2_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG3_1.img , CONG3_1.x , CONG3_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG4_1.img , CONG4_1.x , CONG4_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONGRATULATION , player.x , player.y - 150/2 * scale_y , 0 , scale_x , scale_y)

love.graphics.draw(white_flyingbird1.img , white_flyingbird1.x , white_flyingbird1.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird2.img , white_flyingbird2.x , white_flyingbird2.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird3.img , white_flyingbird3.x , white_flyingbird3.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird4.img , white_flyingbird4.x , white_flyingbird4.y , 0 , scale_x , scale_y)
end


love.graphics.draw(GRASSES.img , GRASSES.x , GRASSES.y , 0 , scale_x , scale_y)
love.graphics.draw(GRASSES1.img , GRASSES1.x , GRASSES1.y , 0 , scale_x , scale_y)

love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[1] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[2] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[3] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[4] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)

love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[1] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[2] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[3] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[4] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)


if not( headofmamouth == HEADOFMAMOUTH[1] and not ( enemys[1].isAlive == true or enemys[2].isAlive == true ) ) then
love.graphics.draw(headofmamouth , headofmamouthX , headofmamouthY , 0 , scale_x , scale_y)
end

if should_summon_boss3 == true or (should_summon_boss1 == false and boss1_finished == true and should_summon_boss2 == false and boss2_finished == true and should_summon_boss3 == false and boss3_finished == true) then

love.graphics.draw(RAIN_RED.img , RAIN_RED.x , RAIN_RED.y , 0 , scale_x , scale_y)
for i = 1 , 27 do
love.graphics.draw(WATER_DROP_LB_RED[i].img , WATER_DROP_LB_RED[i].x , WATER_DROP_LB_RED[i].y , 0 , scale_x , scale_y)
end

if not( headofmamouth == HEADOFMAMOUTH[1] and not ( enemys[1].isAlive == true or enemys[2].isAlive == true ) ) then
love.graphics.draw(headofmamouth , headofmamouthX , headofmamouthY , 0 , scale_x , scale_y)
end

love.graphics.draw(GRASSES.img , GRASSES.x , GRASSES.y , 0 , scale_x , scale_y)
love.graphics.draw(GRASSES1.img , GRASSES1.x , GRASSES1.y , 0 , scale_x , scale_y)

love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[1] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[2] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[3] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND_TO_SHOW.img , GROUND_TO_SHOW[4] , GROUND_TO_SHOW.y , 0 , scale_x , scale_y)

love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[1] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[2] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[3] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)
love.graphics.draw(GROUND1_TO_SHOW.img , GROUND1_TO_SHOW[4] , GROUND1_TO_SHOW.y , 0 , scale_x , scale_y)


    DRAW_BACKGROUND_BOSS3()

if CONG_HANDLER == true and BOSS_DEAD_shouldshow == false and BOSS2_DEAD_shouldshow == false and BOSS3_DEAD_shouldshow == false then
love.graphics.draw(wing1_congs.img , wing1_congs.x , wing1_congs.y , 0 , scale_x , scale_y)
love.graphics.draw(wing2_congs.img , wing2_congs.x , wing2_congs.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG1.img , CONG1.x , CONG1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG2.img , CONG2.x , CONG2.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG3.img , CONG3.x , CONG3.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG4.img , CONG4.x , CONG4.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG1_1.img , CONG1_1.x , CONG1_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG2_1.img , CONG2_1.x , CONG2_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG3_1.img , CONG3_1.x , CONG3_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONG4_1.img , CONG4_1.x , CONG4_1.y , 0 , scale_x , scale_y)
love.graphics.draw(CONGRATULATION , player.x , player.y - 150/2 * scale_y , 0 , scale_x , scale_y)

love.graphics.draw(white_flyingbird1.img , white_flyingbird1.x , white_flyingbird1.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird2.img , white_flyingbird2.x , white_flyingbird2.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird3.img , white_flyingbird3.x , white_flyingbird3.y , 0 , scale_x , scale_y)
love.graphics.draw(white_flyingbird4.img , white_flyingbird4.x , white_flyingbird4.y , 0 , scale_x , scale_y)
end


end


if #boss.BBullets > 0 or should_summon_boss1 == true or should_summon_boss3 == true then
love.graphics.draw(BLOCKJUMPFORFIGHTINGBOSS , BLOCKJUMPS[blockforfightingboss1].x , BLOCKJUMPS[blockforfightingboss1].y , 0 , scale_x , scale_y)
love.graphics.draw(BLOCKJUMPFORFIGHTINGBOSS , BLOCKJUMPS[blockforfightingboss2].x , BLOCKJUMPS[blockforfightingboss2].y , 0 , scale_x , scale_y)
end




if amuzeshi_gameplay == true then
love.graphics.draw(touch_pad_lefty, 0 , 0 , 0 , scale_x , scale_y)    
end


love.graphics.draw(player.img , player.x , player.y , 0 , scale_x , scale_y)



if amuzeshi_gameplay == true then
love.graphics.draw(A_background , background1.x , background1.y , 0 , scale_x , scale_y)

if headofmamouth == HEADOFMAMOUTH[6] then

love.graphics.draw(AA_background , background1.x , background1.y , 0 , scale_x , scale_y)

end

end



for i = 1 , #bullets do
if bullets[i].visible ~= false then 
    love.graphics.draw(bullets[i].img , bullets[i].x , bullets[i].y , 0 , scale_x , scale_y)
end
end
for i = 1 , #enemys[1].EBullets do
if enemys[1].EBullets[i].visible ~= false then 
    love.graphics.draw(enemys[1].EBullets[i].img , enemys[1].EBullets[i].x , enemys[1].EBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[1].EBullets[i].x,enemys[1].EBullets[i].y,10,5)
end
end
for i = 1 , #enemys[2].EBullets do
if enemys[2].EBullets[i].visible ~= false then 
    love.graphics.draw(enemys[2].EBullets[i].img , enemys[2].EBullets[i].x , enemys[2].EBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end
for i = 1 , #boss.helper.EBullets do
if boss.helper.EBullets[i].visible ~= false then 
    love.graphics.draw(boss.helper.EBullets[i].img , boss.helper.EBullets[i].x , boss.helper.EBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end
for i = 1 , #boss.BBullets do
if boss.BBullets[i].visible ~= false then 
    love.graphics.draw(boss.BULLET_IMG , boss.BBullets[i].x , boss.BBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end



--drawing BOSS2 bullets :: start
for i = 1 , #boss2.BBullets do
if boss2.BBullets[i].visible ~= false then 
    love.graphics.draw(boss2.BULLET_IMG , boss2.BBullets[i].x , boss2.BBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end
for i = 1 , #SCORES do
love.graphics.draw(SCORES[i].img , SCORES[i].x , SCORES[i].y , 0 , scale_x , scale_y)
end

for i = 1 , #AMMOTOSHOW do
love.graphics.draw(AMMOTOSHOW[i].img , AMMOTOSHOW[i].x , AMMOTOSHOW[i].y , 0 , scale_x , scale_y)
end

love.graphics.draw(AMMOTIME.img , AMMOTIME.x , AMMOTIME.y , 0 , scale_x , scale_y)
love.graphics.draw(CLOCK , AMMOTIME.x - 48/2 * scale_x , AMMOTIME.y - 3/2 * scale_y , 0 , scale_x , scale_y)
love.graphics.draw(AMMO_BULLET , AMMOTOSHOW[2].x + 75/2 * scale_x , AMMOTOSHOW[2].y - 17/2 * scale_y , 0 , scale_x , scale_y)


if clothes_all.belt_id ~= nil and clothes_all.belt.img ~= nil then

if player.health >= 4 and movingLeft == true and jumping == false  then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_l , clothes_all.belt.y_l , clothes_all.belt.ro_l , -clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and movingRight == true or player.health >= 4 and jumping == true and movingLeft == false then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_r , clothes_all.belt.y_r , clothes_all.belt.ro_r , clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and ducking == true then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_d , clothes_all.belt.y_d , clothes_all.belt.ro_d , clothes_all.belt.scale_x , clothes_all.belt.scale_y)
elseif player.health >= 4 and movingLeft == true and jumping == true  then
love.graphics.draw(clothes_all.belt.img , clothes_all.belt.x_l , clothes_all.belt.y_l , clothes_all.belt.ro_l , -clothes_all.belt.scale_x , clothes_all.belt.scale_y)
end

end



if clothes_all.hat_id ~= nil and clothes_all.head_right.img ~= nil and clothes_all.head_left.img ~= nil then

if player.health == 5 and movingLeft == true and jumping == false then
love.graphics.draw(clothes_all.head_left.img , clothes_all.head_left.x , clothes_all.head_left.y , 0 , scale_x , scale_y)
elseif player.health == 5 and movingRight == true or player.health == 5 and jumping == true and movingLeft == false then
love.graphics.draw(clothes_all.head_right.img , clothes_all.head_right.x , clothes_all.head_right.y , 0 , scale_x , scale_y)   
elseif player.health == 5 and ducking == true then
love.graphics.draw(clothes_all.head_right.img , clothes_all.head_right.x , clothes_all.head_right.y , 0 , scale_x , scale_y)
elseif player.health == 5 and movingLeft == true and jumping == true then
love.graphics.draw(clothes_all.head_left.img , clothes_all.head_left.x , clothes_all.head_left.y , 0 , scale_x , scale_y)       
end

end






love.graphics.draw(player_guns.img , player_guns.x , player_guns.y , 0 , scale_x , scale_y)



for i = 1 , #bullets do
if bullets[i].visible ~= false then 
    love.graphics.draw(bullets[i].img , bullets[i].x , bullets[i].y , 0 , scale_x , scale_y)
end
end


if boss3.isAlive == true then


for i = 1 , #boss3.BBullets do
if boss3.BBullets[i].visible ~= false then 
    love.graphics.draw(boss3.BULLET_IMG , boss3.BBullets[i].x , boss3.BBullets[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end 

for i = 1 , #boss3.BBullets1 do
if boss3.BBullets1[i] == nil then
break
elseif boss3.BBullets1 ~= nil then
if boss3.BBullets1[i].goingright == false and boss3.BBullets1[i].goingleft == true and boss3.BBullets1[i].visible ~= false then
boss3:BULLETIMG1()
    love.graphics.draw(boss3.BULLET1_IMG , boss3.BBullets1[i].x , boss3.BBullets1[i].y , 0 , scale_x , scale_y)
elseif boss3.BBullets1[i].goingright == true and boss3.BBullets1[i].goingleft == false and boss3.BBullets1[i].visible ~= false then 
    love.graphics.draw(boss3.BULLET1_2IMG , boss3.BBullets1[i].x , boss3.BBullets1[i].y , 0 , scale_x , scale_y)
boss3:BULLETIMG1_2()
end 
end
end

for i = 1 , #boss3.BBullets2 do
if boss3.BBullets2[i].visible ~= false then 
    love.graphics.draw(boss3.BULLET2_IMG , boss3.BBullets2[i].x , boss3.BBullets2[i].y , 0 , scale_x , scale_y)
--    love.graphics.rectangle('fill',enemys[2].EBullets[i].x,enemys[2].EBullets[i].y,10,5)
end
end



else


boss3.BBullets = {}


boss3.BBullets1 = {}


boss3.BBullets2 = {}


end -- if boss3.isAlive == true



end--function end



function gameover_explode_anim()

if gameover_explode_bool == true then

if gameover_explode_framespeed >= 5 then
gameover_explode_framespeed  = 0


if gameover_explode_frame < 33 then
    gameover_explode_frame = gameover_explode_frame + 1
else
    gameover_explode_frame = 1
end

else

gameover_explode_framespeed = gameover_explode_framespeed  + 2/2.5

end

gameover_explode_to_show = gameover_explode[gameover_explode_frame]


end

end

function end_explotion()

if gameover_explode_to_show == gameover_explode[33] and gameover_explode_bool == true then


gameover_explode_bool = false
GAME_PlAY = false
gamepaused = false
gameover_explode_frame = 1
gameover_explode_framespeed = 0
gameover_explode_to_show = gameover_explode[1]

for i = 1 , #list_of_audio_sources do

love.audio.stop(list_of_audio_sources[i]) 

end

love.audio.stop(explotion_gameover)
explotion_gameover_once = 0
after_lost_choose = true


end

end

function gameover_update()

gameover_explode_anim()
end_explotion()

end

function gameover_show()

if gameover_explode_bool == true then
pasus_display()
love.graphics.draw(gameover_explode_to_show , player.x - 368/2 * scale_x , player.y - 210/2 * scale_y , 0 , scale_x , scale_y)

if play_music == 1 then

if gameover_explode_to_show == gameover_explode[9] then

if explotion_gameover_once < 1 then
explotion_gameover:play()
explotion_gameover_once = explotion_gameover_once + 1
end

end


end

end

end    



function set_volume_zero()

for i = 1 , 46 do

list_of_audio_sources[i]:setVolume(0.0)

end

explotion_gameover:setVolume(0.0)

end

function set_volume()

studio_music:setVolume(1.0)
menu_sound:setVolume(0.8)
GAMEOVER_MUSIC:setVolume(0.9)
BOSS1_THEME_MUSIC:setVolume(0.8)
RAIN_SOUND:setVolume(0.5)
LIGHTENING_SOUND:setVolume(0.6)
BOSS1_WAIT_SOUND:setVolume(1)
BOSS1_GETHIT_SOUND:setVolume(1)
BOSS1_ATTACK_SOUND:setVolume(0.3)
BOSS1_DIE_SOUND:setVolume(1)
BOSS1_INFLAME_SOUND:setVolume(1)
BOSS2_THEME_MUSIC:setVolume(0.7)
WIND_SOUND:setVolume(0.6)
BOSS2_JUMPING_SOUND:setVolume(1)
BOSS2_ATTACK_SOUND:setVolume(1)
BOSS2_GEHIT_SOUND:setVolume(1)
BOSS2_DIE_SOUND:setVolume(1)
BOSS2_INFLAME_SOUND:setVolume(1)
BOSS3_THEME_MUSIC:setVolume(0.7)
BOSS3_TO_FIRE_SOUND:setVolume(1)
BOSS3_TO_CREEP_SOUND:setVolume(1)
BOSS3_TO_GLAD_SOUND:setVolume(1)
BOSS3_TO_GIANT_SOUND:setVolume(1)
BOSS3_TO_SKEL_SOUND:setVolume(1)
BOSS3_TO_LIGHT_SOUND:setVolume(1)
BOSS3_WAIT_SOUND:setVolume(1)
BOSS3_DIE_SOUND:setVolume(1)
BOSS3_INFLAME_SOUND:setVolume(1)
BLOOD_RAIN_SOUND:setVolume(0.5)
WATER_SOUND:setVolume(0.5)
CONGRATULATIONS_SOUND:setVolume(0.7)
CONGRATULATIONS_VOICE_SOUND:setVolume(1)
CROWS_SOUND:setVolume(1)
ENEMY1_GET_HIT_SOUND:setVolume(1)
ENEMY2_GET_HIT_SOUND:setVolume(1)
BOSS1_HELPER_GET_HIT_SOUND:setVolume(1)
ENEMY1_DIE_SOUND:setVolume(1)
ENEMY2_DIE_SOUND:setVolume(1)
BOSS1_HELPER_DIE_SOUND:setVolume(1)
LIGHT_GUN_SOUND:setVolume(0.7)
HAND_GUN_SOUND:setVolume(0.7)
SHOT_GUN_SOUND:setVolume(0.9)
HEAVY_GUN_SOUND:setVolume(0.7)
LAZER_GUN_SOUND:setVolume(0.7)
JUMP_SOUND:setVolume(0.7)
GET_HIT_SOUND:setVolume(1)
EARTHQ:setVolume(1)
explotion_gameover:setVolume(1.0)

end






--amuzeshi_gamplay updating

function amuzeshi_gameplay_update()

if enemys[1].isAlive == false then

if amuzeshi_gameplay_enemy_1_time_to_reborn > 0 then

amuzeshi_gameplay_enemy_1_time_to_reborn = amuzeshi_gameplay_enemy_1_time_to_reborn - 1

else

enemys[1]:reborn()
amuzeshi_gameplay_enemy_1_time_to_reborn = 80

end

end



if enemys[2].isAlive == false then

if amuzeshi_gameplay_enemy_2_time_to_reborn > 0 then

amuzeshi_gameplay_enemy_2_time_to_reborn = amuzeshi_gameplay_enemy_2_time_to_reborn - 1

else

enemys[2]:reborn()
amuzeshi_gameplay_enemy_2_time_to_reborn = 80

end

end


end





















--[[
files -> jupiter
example of use in begining

if SCORE_SAVE_BOOL == true then

if not love.filesystem.exists("save.txt") then

jupiter = require "jupiter"
data = {_fileName = "save.txt", scoore}
success = jupiter.save(data)

else

jupiter = require "jupiter"
newData = jupiter.load("save.txt")
newData[#newData+1] = scoore

function zsort(object1, object2)
    return object1 > object2
end

table.sort( newData, zsort )

if #newData > 9 then
for i = 10 , #newData do	

table.remove(newData,i)

end
end

success1 = jupiter.save(newData)

end 

SCORE_SAVE_BOOL = false



--love.system.openURL("http://love2d.org/")

end--score_save_bool

]]






--set functions for extra clothes: