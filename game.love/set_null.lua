

function set()


after_lost_choose = false


gamepaused = false


timer_pad = 0	


menu_pad = menu_pad_asli




--score IMAGES
SCORE_IMAGE = love.graphics.newImage("scores.png")

--bool to save score rightly
SCORE_SAVE_BOOL = true


--sound && music sources and booleans :: starts here (should copy to set_null file) 

if is_base_menu() and GAME_PlAY == false then

if play_music == 0 then 

play_img = play_m

play_img_a = play_m_a

end


if play_music == 1 then 

if BOSS1_THEME_MUSIC:getVolume() == 0 then

play_img = play_m

play_img_a = play_m_a

else

play_img = play_p

play_img_a = play_p_a

end

end

elseif GAME_PlAY == true then

if play_img == play_p or play_img_a == play_p_a then

play_music = 1 

--GAMEOVER
GAMEOVER_MUSIC_BOOLEAN = false
GAMEOVER_MUSIC:setVolume(0.9)




--boss1 theme music
BOSS1_THEME_MUSIC_BOOLEAN = false
BOSS1_THEME_MUSIC:setVolume(0.8)

--rain sound
RAIN_SOUND_BOOLEAN = false
RAIN_SOUND:setVolume(0.5)

--lightening sound
LIGHTENING_SOUND_BOOLEAN = false
LIGHTENING_SOUND:setVolume(0.6)


--boss1 wait
BOSS1_WAIT_SOUND:setVolume(1)

--boss1 gethit
BOSS1_GETHIT_SOUND:setVolume(1)

--boss1 attack
BOSS1_ATTACK_SOUND:setVolume(1)

--boss1 die
BOSS1_DIE_SOUND_PLAYED = 0
BOSS1_DIE_SOUND:setVolume(1)

--boss1 in flames
BOSS1_INFLAME_SOUND:setVolume(1)















--boss2 theme music
BOSS2_THEME_MUSIC_BOOLEAN = false
BOSS2_THEME_MUSIC:setVolume(0.7)
--

--wind sound
WIND_SOUND_BOOLEAN = false
WIND_SOUND:setVolume(0.6)
--

--boss2 jumping sound
BOSS2_JUMPING_SOUND:setVolume(1)
--

--boss2 attack sound
BOSS2_ATTACK_SOUND:setVolume(1)
--

--boss2 gethit sound 
BOSS2_GEHIT_SOUND:setVolume(1)
--

--boss2 die
BOSS2_DIE_SOUND_PLAYED = 0
BOSS2_DIE_SOUND:setVolume(1)

--boss2 in flames
BOSS2_INFLAME_SOUND:setVolume(1)





--boss3 theme music
BOSS3_THEME_MUSIC_BOOLEAN = false
BOSS3_THEME_MUSIC:setVolume(0.7)


--boss3 to fire
BOSS3_TO_FIRE_SOUND:setVolume(1)
--

--boss3 to creep
BOSS3_TO_CREEP_SOUND:setVolume(1)
--

--boss3 to glad
BOSS3_TO_GLAD_SOUND:setVolume(1)
--

--boss3 to giant
BOSS3_TO_GIANT_SOUND:setVolume(1)
--

--boss3 to skel
BOSS3_TO_SKEL_SOUND:setVolume(1)
--

--boss3 to light
BOSS3_TO_LIGHT_SOUND:setVolume(1)
--

--boss3 wait
BOSS3_WAIT_SOUND:setVolume(1)
--

--boss3 die
BOSS3_DIE_SOUND_PLAYED = 0
BOSS3_DIE_SOUND:setVolume(1)
--

--boss3 in flames
BOSS3_INFLAME_SOUND:setVolume(1)
--



--blood rain sound
BLOOD_RAIN_SOUND_BOOLEAN = false
BLOOD_RAIN_SOUND:setVolume(0.5)


--water sound
WATER_SOUND_BOOLEAN = false
WATER_SOUND:setVolume(0.5)














--music for CONGRATULATIONS
CONGRATULATIONS_SOUND_BOOLEAN = false
CONGRATULATIONS_SOUND:setVolume(0.7)

--voice for CONGRATULATIONS
CONGRATULATIONS_VOICE_SOUND_BOOLEAN = false
CONGRATULATIONS_VOICE_SOUND_PLAYED = 0 
CONGRATULATIONS_VOICE_SOUND:setVolume(1)








--sounds for CROWS

CROWS_SOUND_BOOLEAN = false
CROWS_SOUND:setVolume(1)

--sound for get hit

ENEMY1_GET_HIT_SOUND_PLAYED = 0
ENEMY1_GET_HIT_SOUND:setVolume(1)


ENEMY2_GET_HIT_SOUND_PLAYED = 0
ENEMY2_GET_HIT_SOUND:setVolume(1)


BOSS1_HELPER_GET_HIT_SOUND_PLAYED = 0
BOSS1_HELPER_GET_HIT_SOUND:setVolume(1)


--sound for die

ENEMY1_DIE_SOUND_PLAYED = 0
ENEMY1_DIE_SOUND:setVolume(1)


ENEMY2_DIE_SOUND_PLAYED = 0
ENEMY2_DIE_SOUND:setVolume(1)


BOSS1_HELPER_DIE_SOUND_PLAYED = 0
BOSS1_HELPER_DIE_SOUND:setVolume(1)












--SOUNDS for ROBOT:::

--sounds for guns:
--light gun
LIGHT_GUN_SOUND_PLAYED = 0
LIGHT_GUN_SOUND:setVolume(0.7)

--hand gun
HAND_GUN_SOUND_PLAYED = 0
HAND_GUN_SOUND:setVolume(0.7)

--shot gun
SHOT_GUN_SOUND_PLAYED = 0
SHOT_GUN_SOUND:setVolume(0.9)

--heavy gun
HEAVY_GUN_SOUND_PLAYED = 0
HEAVY_GUN_SOUND:setVolume(0.7)

--lazer gun
LAZER_GUN_SOUND_PLAYED = 0
LAZER_GUN_SOUND:setVolume(0.7)



--sound for jump
JUMP_SOUND_PLAYED = 0
JUMP_SOUND:setVolume(0.7)


--sound for get hit and get tremble
GET_HIT_SOUND:setVolume(1)






--sound for background shake
EARTHQ:setVolume(1)





elseif play_img == play_p or play_img_a == play_p_a then


for i = 1 , 46 do

list_of_audio_sources[i]:setVolume(0.0)

end

explotion_gameover:setVolume(0.0)



end





end


touch_pad_lefty = love.graphics.newImage('touch_pad_lefty.png')

touchX_up = 110/2 * scale_x + 53/2 * scale_x * 0.45
touchY_up = 322/2 * scale_y - 57/2.2 * scale_y
touch_up = nil

touchX_right = 178/2 * scale_x +  53/2 * scale_x * 1.35
touchY_right = 368/2 * scale_y - 57/2 * scale_y * 0.4
touch_right = nil

touchX_left = 42/2 * scale_x
touchY_left = 368/2 * scale_y - 57/2 * scale_y * 0.4
touch_left = nil

touchX_down = 110/2 * scale_x + 53/2 * scale_x * 0.45
touchY_down = 420/2 * scale_y + 57/2.2 * scale_y * 0.2
touch_down = nil

touchX_shoot = 400/2 * scale_x
touchY_shoot = 0 * scale_y
touch_shoot = nil

timer = 0

-- for give meaning to looping the game :: start the variable
PASSING_FINISHeD_GAME = 0


CONG_HANDLER = false



if not love.filesystem.exists("checkpoint.txt") then
jupiter = require "jupiter"
data = {_fileName = "checkpoint.txt", 1}
success = jupiter.save(data)

checkpoint_saved = 1

else

jupiter = require "jupiter"
newData = jupiter.load("checkpoint.txt")	
checkpoint_saved = newData[1]

end	



if checkpoint_saved == 1 then

--BOSS1 MODE ::  THE STANDARD MODE	

should_summon_boss1 = true
should_summon_boss2 = false
should_summon_boss3 = false

boss1_finished = false
boss2_finished = false
boss3_finished = false

handle_SHOT_GUN = false
handle_HEAVY_GUN = false
handle_LAZER_GUN = false


elseif checkpoint_saved == 2 then

--BOSS2 MODE

should_summon_boss1 = false
should_summon_boss2 = true
should_summon_boss3 = false

boss1_finished = true
boss2_finished = false
boss3_finished = false

handle_SHOT_GUN = true
handle_HEAVY_GUN = false
handle_LAZER_GUN = false

elseif checkpoint_saved == 3 then

--BOSS3 MODE

should_summon_boss1 = false
should_summon_boss2 = false
should_summon_boss3 = true

boss1_finished = true
boss2_finished = true
boss3_finished = false

handle_HEAVY_GUN = true
handle_SHOT_GUN = false
handle_LAZER_GUN = false

end







player = {x = 100/2 * scale_x ,y = 365/2 * scale_y ,img = nil ,health = 5}


player_GOT_TREMBL = false
player_should_trembl = false

player_GOT_TREMBL1 = false
player_should_trembl1 = false

player_GOT_TREMBL2 = false
player_should_trembl2 = false

player_GOT_TREMBL3 = false
player_should_trembl3 = false

player_GOT_DRIL = false
player_should_dril = false












-- PLAYER begin

-- Animation clip for player when he stands





playerStanding_frameSpeed = 0
playerStanding_frame = 1




playerStandingWithTwobattry_frameSpeed = 0
playerStandingWithTwobattry_frame = 1





playerStandingWithOnebattry_frameSpeed = 0
playerStandingWithOnebattry_frame = 1



-- the end!



-- Animation clip for player when he moves to right





playerMovingRight_frameSpeed = 0
playerMovingRight_frame = 1





playerMovingRightWithTwobattry_frameSpeed = 0
playerMovingRightWithTwobattry_frame = 1





playerMovingRightWithOnebattry_frameSpeed = 0
playerMovingRightWithOnebattry_frame = 1



-- the end!



-- Animation clip for player when he moves to left





playerMovingLeft_frameSpeed = 0
playerMovingLeft_frame = 1





playerMovingLeftWithTwobattry_frameSpeed = 0
playerMovingLeftWithTwobattry_frame = 1





playerMovingLeftWithOnebattry_frameSpeed = 0
playerMovingLeftWithOnebattry_frame = 1



-- the end!



-- PLAYER end































--Array for enemys_helicoopter::

enemys[1].x = 480/2 * scale_x
enemys[1].y = 360/2 * scale_y
enemys[1].isAlive = true

enemys[1].health = 3
enemys[1].goingUp = true 
enemys[1].goingDown = false
enemys[1].shouldAttack = false
enemys[1].attackSpeed = 0
enemys[1].X_TIME = false
enemys[1].TIMEFORDIE = 0
enemys[1].X_TIMEFORDIE = enemys[1].x
enemys[1].changeforpicture = love.math.random(1,3)
enemys[1].hit_effect_start = false
enemys[1].hit_effect_TIME = 0


if enemys[1].changeforpicture == 1 then
enemys[1].img = love.graphics.newImage('crowenemy1.png')
enemys[1].helicoopter_frame = 1
elseif enemys[1].changeforpicture == 2 then
enemys[1].img = love.graphics.newImage('crowenemynumber2_1.png')
enemys[1].helicoopter_frame = 5
elseif enemys[1].changeforpicture == 3 then
enemys[1].img = love.graphics.newImage('crowenemynumber3_1.png')
enemys[1].helicoopter_frame = 9
end	





enemys[1].helicoopter_frameSpeed = 0






enemys[2].x = 650/2 * scale_x
enemys[2].y = 120/2 * scale_y
enemys[2].isAlive = true

enemys[2].health = 3
enemys[2].goingUp = true 
enemys[2].goingDown = false
enemys[2].shouldAttack = false
enemys[2].attackSpeed = 0
enemys[2].X_TIME = false
enemys[2].TIMEFORDIE = 0
enemys[2].X_TIMEFORDIE = enemys[2].x
enemys[2].changeforpicture = love.math.random(1,3)
enemys[2].hit_effect_start = false
enemys[2].hit_effect_TIME = 0


if enemys[2].changeforpicture == 1 then
enemys[2].img = love.graphics.newImage('crowenemy1.png')
enemys[2].helicoopter_frame = 1
elseif enemys[2].changeforpicture == 2 then
enemys[2].img = love.graphics.newImage('crowenemynumber2_1.png')
enemys[2].helicoopter_frame = 5
elseif enemys[2].changeforpicture == 3 then
enemys[2].img = love.graphics.newImage('crowenemynumber3_1.png')
enemys[2].helicoopter_frame = 9
end	




enemys[2].helicoopter_frameSpeed = 0









--the end !












boss.x = 500/2 * scale_x
boss.y = 100/2 * scale_y
boss.isAlive = false
boss.health = 3
boss.shouldAttack = false
boss.attackSpeed = 0
boss.shouldgethit = false
boss.should_summon_helper = false

boss.BULLET_IMG_FRAMESPEED = 0
boss.BULLET_IMG_FRAME = 1
















BOSS_WALKING_frame = 1
BOSS_WALKING_frameSpeed = 0
BOSS_WALKING_IMG = BOSS_WALKING[1]
BOSS_WALKING_X = 1300/2 * scale_x
BOSS_WALKING_Y = boss.y










boss_frameSpeed_ATTACK = 0
boss_frame_ATTACK = 1
boss_frameSpeed_GETHIT = 0
boss_frame_GETHIT = 1
boss_frameSpeed_WAIT = 0
boss_frame_WAIT = 1


 
BBullet = love.graphics.newImage('bbullet.png')
boss.img = nil
boss.t = 0
boss.t1 = 0

BOSS_DEAD = love.graphics.newImage('boss_dead.png')
BOSS_DEAD_timeforshow = 400
BOSS_DEAD_t = 0
BOSS_DEAD_shouldshow = false
BOSS_DEAD_X = boss.x
BOSS_DEAD_Y = boss.y




boss.helper.x = 480/2 * scale_x
boss.helper.y = 360/2 * scale_y
boss.helper.isAlive = nil

boss.helper.health = 3
boss.helper.goingUp = true 
boss.helper.goingDown = false
boss.helper.shouldAttack = false
boss.helper.attackSpeed = 0
boss.helper.X_TIME = false
boss.helper.TIMEFORDIE = 0
boss.helper.X_TIMEFORDIE = enemys[1].x
boss.helper.img = nil
boss.helper.changeforpicture = love.math.random(1,3)
boss.helper.hit_effect_start = false
boss.helper.hit_effect_TIME = 0



boss.helper.helicoopter_frameSpeed = 0

if boss.helper.changeforpicture == 1 then
boss.helper.img = love.graphics.newImage('crowenemy1.png')
boss.helper.helicoopter_frame = 1
elseif boss.helper.changeforpicture == 2 then
boss.helper.img = love.graphics.newImage('crowenemynumber2_1.png')
boss.helper.helicoopter_frame = 5
elseif boss.helper.changeforpicture == 3 then
boss.helper.img = love.graphics.newImage('crowenemynumber3_1.png')
boss.helper.helicoopter_frame = 9
end	












boss2.x = 100/2 * scale_x
boss2.y = 100/2 * scale_y
boss2.isAlive = false
boss2.health = 3
boss2.shouldAttack = false
boss2.attackSpeed = 0
boss2.shouldgethit = false
boss2.SECOND_ATTACK = false
boss2_midTremble = false
boss2_downTremble = false
boss2_mid2Tremble = false
boss2_upTremble = true

boss2_midTremble_T = 0
boss2_downTremble_T = 0
boss2_mid2Tremble_T = 0
boss2_upTremble_T = 0
Tremble_Tlimit = 3





boss2.BULLET_IMG_FRAMESPEED = 0
boss2.BULLET_IMG_FRAME = 1

boss2.BULLET_IMG = love.graphics.newImage('boss_bullet.png')




JAG = love.graphics.newImage('jag.png')
JAG_NOT = love.graphics.newImage('jag_not.png')











BOSS2_WALKING_frame = 1
BOSS2_WALKING_frameSpeed = 0
BOSS2_WALKING_IMG = BOSS2_WALKING[1]
BOSS2_WALKING_X = 1100/2 * scale_x
BOSS2_WALKING_Y = boss2.y








boss2_frameSpeed_ATTACK = 0
boss2_frame_ATTACK = 1
boss2_frameSpeed_GETHIT = 0
boss2_frame_GETHIT = 1
boss2_frameSpeed_WAIT = 0
boss2_frame_WAIT = 1




boss2.img = nil
boss2.t = 0
boss2.t1 = 0


BOSS2_DEAD_timeforshow = 400
BOSS2_DEAD_t = 0
BOSS2_DEAD_shouldshow = false
BOSS2_DEAD_X = boss2.x
BOSS2_DEAD_Y = boss2.y



















boss3.FIRST_ATTACK = true
boss3.SECOND_ATTACK = false
boss3.THIRD_ATTACK = false
boss3.changeToLight = false
boss3.to_first = false
boss3.to_second = false
boss3.to_third = false
boss3.to_get = false
boss3.t = 0
boss3.t1 = 0
boss3.t2 = 0
boss3.t3 = 0
boss3.t4 = 0
boss3.t5 = 0



boss3.x = 500/2 * scale_x
boss3.y = 100/2 * scale_y
boss3.isAlive = false
boss3.health = 3


boss3.shouldAttack = false
boss3.attackSpeed = 0

boss3.shouldAttack1 = false
boss3.attackSpeed1 = 0




boss3.shouldgethit = false
boss3_midTremble = false
boss3_downTremble = false
boss3_mid2Tremble = false
boss3_upTremble = true

boss3_midTremble_T = 0
boss3_downTremble_T = 0
boss3_mid2Tremble_T = 0
boss3_upTremble_T = 0
Tremble_Tlimit_boss3 = 3


GOT_SKEL_ATTACK1 = false
GOT_SKEL_ATTACK2 = false

SHOULD_GET_SKEL_ATTACK = false

skeleton_position = love.math.random(1,2)
skeleton_end_of_move = false


--BOSS3_TO_FIRE BULLETS:

boss3.BULLET_IMG_FRAMESPEED = 0
boss3.BULLET_IMG_FRAME = 1




--BOSS3_TO_CREEP BULLETS:

boss3.BULLET1_IMG_FRAMESPEED = 0
boss3.BULLET1_IMG_FRAME = 1



boss3.BULLET1_2IMG_FRAMESPEED = 0
boss3.BULLET1_2IMG_FRAME = 1


--BOSS3_TO_GLAD BULLETS:

boss3.BULLET2_IMG_FRAMESPEED = 0
boss3.BULLET2_IMG_FRAME = 1

boss3.BULLET2_IMG = love.graphics.newImage('boss3_to_glad_bullet (1).png')




--boss3 gethit



--boss3 walk

BOSS3_WALKING_frame = 1
BOSS3_WALKING_frameSpeed = 0
BOSS3_WALKING_IMG = BOSS3_WALKING[1]
BOSS3_WALKING_X = 1300/2 * scale_x
BOSS3_WALKING_Y = boss3.y



boss3_frameSpeed_GETHIT = 0
boss3_frame_GETHIT = 1


boss3_frameSpeed_TO_LIGHT = 0
boss3_frame_TO_LIGHT = 1


boss3_frameSpeed_TO_FIRE = 0
boss3_frame_TO_FIRE = 1


boss3_frameSpeed_TO_GLAD = 0
boss3_frame_TO_GLAD = 1


boss3_frameSpeed_TO_GOUL = 0
boss3_frame_TO_GOUL = 1


boss3_frameSpeed_TO_SKEL = 0
boss3_frame_TO_SKEL = 1


boss3_frameSpeed_TO_CREEP = 0
boss3_frame_TO_CREEP = 1



BBullet = love.graphics.newImage('bbullet.png')
boss3.img = nil
boss3.t = 0
boss3.t1 = 0

BOSS3_DEAD = love.graphics.newImage('boss3_dead.png')
BOSS3_DEAD_timeforshow = 400
BOSS3_DEAD_t = 0
BOSS3_DEAD_shouldshow = false
BOSS3_DEAD_X = boss3.x
BOSS3_DEAD_Y = boss3.y




-- blockJump Class starts :: here




BLOCKJUMPS[blockJumpForHelis].visible = true 
BLOCKJUMPS[blockJumpForHelis].x = 105/2 * scale_x 
BLOCKJUMPS[blockJumpForHelis].y = 312/2  * scale_y
BLOCKJUMPS[blockJumpForHelis].width = 100/2  * scale_x
BLOCKJUMPS[blockJumpForHelis].height = 30/2  * scale_y
BLOCKJUMPS[blockJumpForHelis].GROUND = 205/2 * scale_y
BLOCKJUMPS[blockJumpForHelis].onBlock = false









BLOCKJUMPS[blockforfightingboss1].visible = true 
BLOCKJUMPS[blockforfightingboss1].x = 890/2  * scale_x
BLOCKJUMPS[blockforfightingboss1].y = 310/2  * scale_y
BLOCKJUMPS[blockforfightingboss1].width = 100/2  * scale_x
BLOCKJUMPS[blockforfightingboss1].height = 30/2  * scale_y
BLOCKJUMPS[blockforfightingboss1].GROUND = 205/2 * scale_y
BLOCKJUMPS[blockforfightingboss1].onBlock = false






BLOCKJUMPS[blockforfightingboss2].visible = true 
BLOCKJUMPS[blockforfightingboss2].x = 890/2 * scale_x
BLOCKJUMPS[blockforfightingboss2].y = 180/2  * scale_y
BLOCKJUMPS[blockforfightingboss2].width = 100/2  * scale_x
BLOCKJUMPS[blockforfightingboss2].height = 30/2  * scale_y
BLOCKJUMPS[blockforfightingboss2].GROUND = 75/2 * scale_y
BLOCKJUMPS[blockforfightingboss2].onBlock = false








--blockJump class ends :: here




-- Animation clip for HEADOFMAMOUTH

HEADOFMAMOUTHAnimationStart = false

headofmamouthMainX = 47/2 * scale_x
headofmamouthMainY = 322/2 * scale_y
headofmamouthX = headofmamouthMainX
headofmamouthY = headofmamouthMainY


HEADOFMAMOUTH_framespeed = 0
HEADOFMAMOUTH_frame = 1

--the end!







-- gun IMAGES :: starts here




--init for gun
player_guns.img  = love.graphics.newImage('lightgun.png')




















--NUMBERS and SCORES










SCORES[1].x = 310/2 * scale_x   SCORES[1].y = 0   SCORES[1].img = NUMBER0   SCORES[1].toshow = 0
SCORES[2].x = 350/2 * scale_x   SCORES[2].y = 0   SCORES[2].img = NUMBER0   SCORES[2].toshow = 0
SCORES[3].x = 390/2 * scale_x   SCORES[3].y = 0   SCORES[3].img = NUMBER0   SCORES[3].toshow = 0
SCORES[4].x = 430/2 * scale_x   SCORES[4].y = 0   SCORES[4].img = NUMBER0   SCORES[4].toshow = 0



--AMMO class :: starts here





AMMOTOSHOW[1].x = 90/2 * scale_x   AMMOTOSHOW[1].y = 495/2 * scale_y   AMMOTOSHOW[1].img = NUMBER1   AMMOTOSHOW[1].toshow = 5
AMMOTOSHOW[2].x = 50/2 * scale_x   AMMOTOSHOW[2].y = 495/2 * scale_y   AMMOTOSHOW[2].img = NUMBER5   AMMOTOSHOW[2].toshow = 1
AMMOTOSHOW[3].x = 10/2 * scale_x   AMMOTOSHOW[3].y = 495/2 * scale_y   AMMOTOSHOW[3].img = NUMBER0   AMMOTOSHOW[3].toshow = 0
AMMOTIME.x = 750/2 * scale_x       AMMOTIME.y = 495/2 * scale_y        AMMOTIME.img = NUMBER0        AMMOTIME.toshow = 9


AMMO_BULLET = AMMO_BULLET_HANDGUN

--AMMO class :: ends here




--Animation clip for crow


Crow_frameSpeed = 0
Crow_frame = 1


Crow1 = {x = 388/2 * scale_x , y = 24/2 * scale_y , img = love.graphics.newImage('crow1.png')} 

--the end!
-- Animation clip for FLYINGBIRD :: starts here




FLYINGBIRD_frameSpeed = 0
FLYINGBIRD_frame = 1

flyingbird = {x = 1000/2 * scale_x , y = 35/2 * scale_y , img = FLYINGBIRD[1]}


-- the end!
-- Animation for Grass :: starts here






GRASSES = {x = 0 , y = 435/2 * scale_y , img = GRASS[1] , frameSpeed = 0 , frame = 1 , GRASS = GRASS}


GRASSES1 = {x = 800/2 * scale_x , y = 435/2 * scale_y , img = GRASS[1] , frameSpeed = 0 , frame = 1 , GRASS = GRASS}


GROUNDD = love.graphics.newImage('ground.png')
GROUNDD1 = love.graphics.newImage('ground1.png')
GROUND_TO_SHOW = {0 , 200/2 * scale_x , 400/2 * scale_x , 600/2 * scale_x , y = 495/2 * scale_y , img = GROUNDD}
GROUND1_TO_SHOW = {800/2 * scale_x , 1000/2 * scale_x , 1200/2 * scale_x , 1400/2 * scale_x , y = 495/2 * scale_y , img = GROUNDD1}

-- the end


--Animation for RAIN :: starts here






THERAIN_frameSpeed = 0
THERAIN_frame = 1

THERAIN_RED_frameSpeed = 0
THERAIN_RED_frame = 1

RAIN = { x = 0 , y = 0 , img = THERAIN[1]}
RAIN1 = { x = 800/2 * scale_x , y = 0 , img = THERAIN[1] }

RAIN_RED = { x = 0 , y = 0 , img = THERAIN_RED[1]}

-- the end





--Animation for WATER_DROP :: starts here






-- the end








--Animation for lightning :: starts here







THELIGHTNING_R_frameSpeed = 0
THELIGHTNING_R_frame = 1

LIGHTNING_R_1 = { x = 0 , y = -25/2 * scale_y , img = THELIGHTNING_R[1]}
LIGHTNING_R_2 = { x = 800/2 * scale_x , y = -25/2 * scale_y , img = THELIGHTNING_R[1] }





THELIGHTNING_L_frameSpeed = 0
THELIGHTNING_L_frame = 1

LIGHTNING_L_1 = { x = 480/2 * scale_x , y = -25/2 * scale_y , img = THELIGHTNING_L[1]}
LIGHTNING_L_2 = { x = 1280/2 * scale_x , y = -25/2 * scale_y , img = THELIGHTNING_L[1] }

--end!



--Animation for WIND :: starts here





THEWIND_frameSpeed = 0
THEWIND_frame = 1

WIND = { x = 0 , y = 0 , img = THEWIND[1]}
WIND1 = { x = 800/2 * scale_x , y = 0 , img = THEWIND[1] }

-- the end




--Animation for WIND :: starts here





THESUN_frameSpeed = 0
THESUN_frame = 1

SUN = { x = 225/2 * scale_x , y = 0 , img = THESUN[1]}
SUN1 = { x = 1025/2 * scale_x , y = 0 , img = THESUN[1]}


-- the end



-- animation for FLOWERS1 & 2 :: starts here





theFLOWERS1_frameSpeed = 0
theFLOWERS1_frame = 1

FLOWERS1_1 = { x = 600/2 * scale_x , y = 270/2 * scale_y , img = theFLOWERS1[1]}
FLOWERS1_2 = { x = 1400/2 * scale_x , y = 270/2 * scale_y , img = theFLOWERS1[1] }






theFLOWERS2_frameSpeed = 0
theFLOWERS2_frame = 1

FLOWERS2_1 = { x = 600/2 * scale_x , y = 0 , img = theFLOWERS2[1]}
FLOWERS2_2 = { x = 1400/2 * scale_x , y = 0 , img = theFLOWERS2[1]}





theFLOWERS3_frameSpeed = 0
theFLOWERS3_frame = 1

FLOWERS3_1 = { x = 0 , y = 0 , img = theFLOWERS3[1]}
FLOWERS3_2 = { x = 800/2 * scale_x , y = 0 , img = theFLOWERS3[1]}






theFLOWERS4_frameSpeed = 0
theFLOWERS4_frame = 1

FLOWERS4_1 = { x = 0 , y = 270/2 * scale_y , img = theFLOWERS4[1]}
FLOWERS4_2 = { x = 800/2 * scale_x , y = 270/2 * scale_y , img = theFLOWERS4[1]}






-- end!


-- Animation for FLAMING_BOSSES









THEFLAMES_frameSpeed = 0
THEFLAMES_frame = 1

FLAMES_BOSS1 = { x = 480/2 * scale_x , y = 60/2 * scale_y , img = THEFLAMES[1]}
FLAMES_BOSS2 = { x = 380/2 * scale_x , y = 10/2 * scale_y , img = THEFLAMES[1]}
FLAMES_BOSS3 = { x = 480/2 * scale_x , y = 60/2 * scale_y , img = THEFLAMES[1]}

-- the end!






-- BACKGROUND 3 :: starts here



BACKGROUND3_frame = 1
BACKGROUND3_frameSpeed = 0
BACKGROUND3_IMG = love.graphics.newImage('background3 (1).png')

-- end!




-- CONGRATULATION variables and PICTURES ::: starts here




BLUE_CONG_FRAME = 1
BLUE_CONG_FRAME_SPEED = 0

GREEN_CONG_FRAME = 1
GREEN_CONG_FRAME_SPEED = 0

YELLOW_CONG_FRAME = 1
YELLOW_CONG_FRAME_SPEED = 0

PURPLE_CONG_FRAME = 1
PURPLE_CONG_FRAME_SPEED = 0



CONG1 = { x = 0 , y = 0 , img = PURPLE_CONG[1]}
CONG2 = { x = 200/2 * scale_x , y = 0 , img = BLUE_CONG[1]}
CONG3 = { x = 400/2 * scale_x , y = 0 , img = GREEN_CONG[1]}
CONG4 = { x = 590/2 * scale_x , y = 0 , img = YELLOW_CONG[1]}

CONG1_1 = { x = 800/2 * scale_x , y = 0 , img = PURPLE_CONG[1]}
CONG2_1 = { x = 1000/2 * scale_x , y = 0 , img = BLUE_CONG[1]}
CONG3_1 = { x = 1200/2 * scale_x , y = 0 , img = GREEN_CONG[1]}
CONG4_1 = { x = 1390/2 * scale_x , y = 0 , img = YELLOW_CONG[1]}







WHITE_FLYINGBIRD_frameSpeed = 0
WHITE_FLYINGBIRD_frame = 1

white_flyingbird1 = {x = 0 , y = 85/2 * scale_y , img = WHITE_FLYINGBIRD[1]}
white_flyingbird2 = {x = 440/2 * scale_x , y = 85/2 * scale_y , img = WHITE_FLYINGBIRD_L[1]}

white_flyingbird3 = {x = 800/2 * scale_x , y = 85/2 * scale_y , img = WHITE_FLYINGBIRD[1]}
white_flyingbird4 = {x = 1240/2 * scale_x , y = 85/2 * scale_y , img = WHITE_FLYINGBIRD_L[1]}

WINGS_CONG = love.graphics.newImage('wings_cong.png')

wing1_congs = {x = 0 , y = 0 , img = WINGS_CONG} 
wing2_congs = {x = 800/2 * scale_x , y = 0 , img = WINGS_CONG} 




-- the end




WATER_DROP_LB[1] = { x = 0 , y = 400/2 * scale_y , img = THEWATER_DROP[1] , frameSpeed = 0 , frame = 1}
WATER_DROP_LB[2] = { x = 40/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[5] , frameSpeed = 0 , frame = 5} 
WATER_DROP_LB[3] = { x = 80/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[19] , frameSpeed = 0 , frame = 19}
WATER_DROP_LB[4] = { x = 120/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[10] , frameSpeed = 0 , frame = 10}  
WATER_DROP_LB[5] = { x = 160/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[7] , frameSpeed = 0 , frame = 7}
WATER_DROP_LB[6] = { x = 200/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[15] , frameSpeed = 0 , frame = 15} 
WATER_DROP_LB[7] = { x = 240/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[18] , frameSpeed = 0 , frame = 18}
WATER_DROP_LB[8] = { x = 280/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_LB[9] = { x = 320/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[8] , frameSpeed = 0 , frame = 8}
WATER_DROP_LB[10] = { x = 360/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[22] , frameSpeed = 0 , frame = 22} 
WATER_DROP_LB[11] = { x = 400/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[17] , frameSpeed = 0 , frame = 17}
WATER_DROP_LB[12] = { x = 440/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[17] , frameSpeed = 0 , frame = 20}
WATER_DROP_LB[13] = { x = 480/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[9] , frameSpeed = 0 , frame = 9}
WATER_DROP_LB[14] = { x = 540/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP[12] , frameSpeed = 0 , frame = 12} 
WATER_DROP_LB[15] = { x = 560/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[16] , frameSpeed = 0 , frame = 16}
WATER_DROP_LB[16] = { x = 600/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP[7] , frameSpeed = 0 , frame = 7} 
WATER_DROP_LB[17] = { x = 640/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[10] , frameSpeed = 0 , frame = 10}
WATER_DROP_LB[18] = { x = 680/2 * scale_x , y = 310/2 * scale_y , img = THEWATER_DROP[2] , frameSpeed = 0 , frame = 2} 
WATER_DROP_LB[19] = { x = 720/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[15] , frameSpeed = 0 , frame = 15}
WATER_DROP_LB[20] = { x = 780/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[24] , frameSpeed = 0 , frame = 24} 
WATER_DROP_LB[21] = { x = 40/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[27] , frameSpeed = 0 , frame = 27} 
WATER_DROP_LB[22] = { x = 120/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[14] , frameSpeed = 0 , frame = 14}
WATER_DROP_LB[23] = { x = 200/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[25] , frameSpeed = 0 , frame = 25} 
WATER_DROP_LB[24] = { x = 280/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[13] , frameSpeed = 0 , frame = 13}
WATER_DROP_LB[25] = { x = 360/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[23] , frameSpeed = 0 , frame = 23} 
WATER_DROP_LB[26] = { x = 440/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[11] , frameSpeed = 0 , frame = 11}
WATER_DROP_LB[27] = { x = 520/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[21] , frameSpeed = 0 , frame = 21} 
WATER_DROP_LB[28] = { x = 600/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[5] , frameSpeed = 0 , frame = 5}
WATER_DROP_LB[29] = { x = 680/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_LB[30] = { x = 760/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[6] , frameSpeed = 0 , frame = 6}




WATER_DROP_RB[1] = { x = 800/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[1] , frameSpeed = 0 , frame = 1}
WATER_DROP_RB[2] = { x = 840/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[5] , frameSpeed = 0 , frame = 4} 
WATER_DROP_RB[3] = { x = 880/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[19] , frameSpeed = 0 , frame = 19}
WATER_DROP_RB[4] = { x = 920/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[10] , frameSpeed = 0 , frame = 7}  
WATER_DROP_RB[5] = { x = 960/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[7] , frameSpeed = 0 , frame = 7}
WATER_DROP_RB[6] = { x = 1000/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[15] , frameSpeed = 0 , frame = 10} 
WATER_DROP_RB[7] = { x = 1040/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[18] , frameSpeed = 0 , frame = 18}
WATER_DROP_RB[8] = { x = 1080/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP[20] , frameSpeed = 0 , frame = 13} 
WATER_DROP_RB[9] = { x = 1120/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[8] , frameSpeed = 0 , frame = 8}
WATER_DROP_RB[10] = { x = 1160/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[22] , frameSpeed = 0 , frame = 16} 
WATER_DROP_RB[11] = { x = 1200/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[17] , frameSpeed = 0 , frame = 17}
WATER_DROP_RB[12] = { x = 1260/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP[17] , frameSpeed = 0 , frame = 19}
WATER_DROP_RB[13] = { x = 1280/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[9] , frameSpeed = 0 , frame = 9}
WATER_DROP_RB[14] = { x = 1340/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP[12] , frameSpeed = 0 , frame = 21} 
WATER_DROP_RB[15] = { x = 1360/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[16] , frameSpeed = 0 , frame = 16}
WATER_DROP_RB[16] = { x = 1400/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP[7] , frameSpeed = 0 , frame = 24} 
WATER_DROP_RB[17] = { x = 1440/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[10] , frameSpeed = 0 , frame = 10}
WATER_DROP_RB[18] = { x = 1480/2 * scale_x , y = 310/2 * scale_y , img = THEWATER_DROP[2] , frameSpeed = 0 , frame = 9} 
WATER_DROP_RB[19] = { x = 1520/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP[15] , frameSpeed = 0 , frame = 15}
WATER_DROP_RB[20] = { x = 1580/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP[24] , frameSpeed = 0 , frame = 5} 
WATER_DROP_RB[21] = { x = 840/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[27] , frameSpeed = 0 , frame = 27} 
WATER_DROP_RB[22] = { x = 920/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[14] , frameSpeed = 0 , frame = 14}
WATER_DROP_RB[23] = { x = 1000/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[25] , frameSpeed = 0 , frame = 25} 
WATER_DROP_RB[24] = { x = 1080/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[13] , frameSpeed = 0 , frame = 13}
WATER_DROP_RB[25] = { x = 1160/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[23] , frameSpeed = 0 , frame = 23} 
WATER_DROP_RB[26] = { x = 1240/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[11] , frameSpeed = 0 , frame = 11}
WATER_DROP_RB[27] = { x = 1320/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[21] , frameSpeed = 0 , frame = 21} 
WATER_DROP_RB[28] = { x = 1400/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[5] , frameSpeed = 0 , frame = 5}
WATER_DROP_RB[29] = { x = 1480/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_RB[30] = { x = 1520/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP[6] , frameSpeed = 0 , frame = 6}


WATER_DROP_LB_RED[1] = { x = 0 , y = 400/2 * scale_y , img = THEWATER_DROP_RED[1] , frameSpeed = 0 , frame = 1}
WATER_DROP_LB_RED[2] = { x = 40/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP_RED[5] , frameSpeed = 0 , frame = 5} 
WATER_DROP_LB_RED[3] = { x = 80/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[19] , frameSpeed = 0 , frame = 19}
WATER_DROP_LB_RED[4] = { x = 120/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP_RED[10] , frameSpeed = 0 , frame = 10}  
WATER_DROP_LB_RED[5] = { x = 160/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[7] , frameSpeed = 0 , frame = 7}
WATER_DROP_LB_RED[6] = { x = 200/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP_RED[15] , frameSpeed = 0 , frame = 15} 
WATER_DROP_LB_RED[7] = { x = 240/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[18] , frameSpeed = 0 , frame = 18}
WATER_DROP_LB_RED[8] = { x = 280/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP_RED[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_LB_RED[9] = { x = 320/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[8] , frameSpeed = 0 , frame = 8}
WATER_DROP_LB_RED[10] = { x = 360/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP_RED[22] , frameSpeed = 0 , frame = 22} 
WATER_DROP_LB_RED[11] = { x = 400/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[17] , frameSpeed = 0 , frame = 17}
WATER_DROP_LB_RED[12] = { x = 440/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP_RED[17] , frameSpeed = 0 , frame = 20}
WATER_DROP_LB_RED[13] = { x = 480/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[9] , frameSpeed = 0 , frame = 9}
WATER_DROP_LB_RED[14] = { x = 540/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP_RED[12] , frameSpeed = 0 , frame = 12} 
WATER_DROP_LB_RED[15] = { x = 560/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[16] , frameSpeed = 0 , frame = 16}
WATER_DROP_LB_RED[16] = { x = 600/2 * scale_x , y = 300/2 * scale_y , img = THEWATER_DROP_RED[7] , frameSpeed = 0 , frame = 7} 
WATER_DROP_LB_RED[17] = { x = 640/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[10] , frameSpeed = 0 , frame = 10}
WATER_DROP_LB_RED[18] = { x = 680/2 * scale_x , y = 310/2 * scale_y , img = THEWATER_DROP_RED[2] , frameSpeed = 0 , frame = 2} 
WATER_DROP_LB_RED[19] = { x = 720/2 * scale_x , y = 400/2 * scale_y , img = THEWATER_DROP_RED[15] , frameSpeed = 0 , frame = 15}
WATER_DROP_LB_RED[20] = { x = 780/2 * scale_x , y = 290/2 * scale_y , img = THEWATER_DROP_RED[24] , frameSpeed = 0 , frame = 24} 
WATER_DROP_LB_RED[21] = { x = 40/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[27] , frameSpeed = 0 , frame = 27} 
WATER_DROP_LB_RED[22] = { x = 120/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[14] , frameSpeed = 0 , frame = 14}
WATER_DROP_LB_RED[23] = { x = 200/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[25] , frameSpeed = 0 , frame = 25} 
WATER_DROP_LB_RED[24] = { x = 280/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[13] , frameSpeed = 0 , frame = 13}
WATER_DROP_LB_RED[25] = { x = 360/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[23] , frameSpeed = 0 , frame = 23} 
WATER_DROP_LB_RED[26] = { x = 440/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[11] , frameSpeed = 0 , frame = 11}
WATER_DROP_LB_RED[27] = { x = 520/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[21] , frameSpeed = 0 , frame = 21} 
WATER_DROP_LB_RED[28] = { x = 600/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[5] , frameSpeed = 0 , frame = 5}
WATER_DROP_LB_RED[29] = { x = 680/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[20] , frameSpeed = 0 , frame = 20} 
WATER_DROP_LB_RED[30] = { x = 760/2 * scale_x , y = 410/2 * scale_y , img = THEWATER_DROP_RED[6] , frameSpeed = 0 , frame = 6}




-- the end







background1 = {x = 0 , y = 0 , img = nil}
background2 = {x = 800/2 * scale_x , y = 0 , img = nil}
background1.img = backgroundimg
background2.img = backgroundimg


menu = GAMEOVER



GAME_PlAY = true

scoore = 0


AMMO = 50
AMMO_TIME = 0


movingRight = false
movingLeft = false
standing = false
jumping = false
ducking = false

timeLimit = 0.15

jumped = false

speed = 4/2
bulletspeed = 10/2
canshoot = true
shootTime = 75
shotFire = false

MAINGROUND = 340/2 * scale_y
GROUND = MAINGROUND 
gravity = 93
gravityT = 1
JumpTime = 1
Jumptiming = 0

pass = 0
pass1 = 0
passing = true
--boss is isAlive
GAME_PlAY_CHANGE = 0

--init : end!








player.img = love.graphics.newImage('character_1_1.png')










end























































function null()



playerDockedImg = nil
playerDockedImgWithTwobattry = nil
playerDockedImgWithOnebattry = nil

playerJumping = nil
playerJumpingWithTwobattry = nil
playerJumpingWithOnebattry = nil

HEADLEFT = nil
HEADRIGHT = nil
BELT = nil





playerStanding[1] = nil
playerStanding[2] = nil
playerStanding[3] = nil
playerStanding[4] = nil
playerStanding[5] = nil




playerStandingWithTwobattry[1] = nil
playerStandingWithTwobattry[2] = nil
playerStandingWithTwobattry[3] = nil
playerStandingWithTwobattry[4] = nil
playerStandingWithTwobattry[5] = nil




playerStandingWithOnebattry[1] = nil
playerStandingWithOnebattry[2] = nil
playerStandingWithOnebattry[3] = nil
playerStandingWithOnebattry[4] = nil
playerStandingWithOnebattry[5] = nil



playerMovingRight[1] = nil
playerMovingRight[2] = nil
playerMovingRight[3] = nil
playerMovingRight[4] = nil
playerMovingRight[5] = nil
playerMovingRight[6] = nil
playerMovingRight[7] = nil
playerMovingRight[8] = nil
playerMovingRight[9] = nil
playerMovingRight[10] = nil
playerMovingRight[11] = nil
playerMovingRight[12] = nil





playerMovingRightWithTwobattry[1] = nil
playerMovingRightWithTwobattry[2] = nil
playerMovingRightWithTwobattry[3] = nil
playerMovingRightWithTwobattry[4] = nil
playerMovingRightWithTwobattry[5] = nil
playerMovingRightWithTwobattry[6] = nil
playerMovingRightWithTwobattry[7] = nil
playerMovingRightWithTwobattry[8] = nil
playerMovingRightWithTwobattry[9] = nil
playerMovingRightWithTwobattry[10] = nil
playerMovingRightWithTwobattry[11] = nil
playerMovingRightWithTwobattry[12] = nil




playerMovingRightWithOnebattry[1] = nil
playerMovingRightWithOnebattry[2] = nil
playerMovingRightWithOnebattry[3] = nil
playerMovingRightWithOnebattry[4] = nil
playerMovingRightWithOnebattry[5] = nil
playerMovingRightWithOnebattry[6] = nil
playerMovingRightWithOnebattry[7] = nil
playerMovingRightWithOnebattry[8] = nil
playerMovingRightWithOnebattry[9] = nil
playerMovingRightWithOnebattry[10] = nil
playerMovingRightWithOnebattry[11] = nil
playerMovingRightWithOnebattry[12] = nil




playerMovingLeft[1] = nil
playerMovingLeft[2] = nil
playerMovingLeft[3] = nil
playerMovingLeft[4] = nil
playerMovingLeft[5] = nil
playerMovingLeft[6] = nil
playerMovingLeft[7] = nil
playerMovingLeft[8] = nil
playerMovingLeft[9] = nil
playerMovingLeft[10] = nil
playerMovingLeft[11] = nil
playerMovingLeft[12] = nil





playerMovingLeftWithTwobattry[1] = nil
playerMovingLeftWithTwobattry[2] = nil
playerMovingLeftWithTwobattry[3] = nil
playerMovingLeftWithTwobattry[4] = nil
playerMovingLeftWithTwobattry[5] = nil
playerMovingLeftWithTwobattry[6] = nil
playerMovingLeftWithTwobattry[7] = nil
playerMovingLeftWithTwobattry[8] = nil
playerMovingLeftWithTwobattry[9] = nil
playerMovingLeftWithTwobattry[10] = nil
playerMovingLeftWithTwobattry[11] = nil
playerMovingLeftWithTwobattry[12] = nil



playerMovingLeftWithOnebattry[1] = nil
playerMovingLeftWithOnebattry[2] = nil
playerMovingLeftWithOnebattry[3] = nil
playerMovingLeftWithOnebattry[4] = nil
playerMovingLeftWithOnebattry[5] = nil
playerMovingLeftWithOnebattry[6] = nil
playerMovingLeftWithOnebattry[7] = nil
playerMovingLeftWithOnebattry[8] = nil
playerMovingLeftWithOnebattry[9] = nil
playerMovingLeftWithOnebattry[10] = nil
playerMovingLeftWithOnebattry[11] = nil
playerMovingLeftWithOnebattry[12] = nil





enemys[1].helicoopter[1] = nil
enemys[1].helicoopter[2] = nil
enemys[1].helicoopter[3] = nil
enemys[1].helicoopter[4] = nil
enemys[1].helicoopter[5] = nil
enemys[1].helicoopter[6] = nil
enemys[1].helicoopter[7] = nil
enemys[1].helicoopter[8] = nil
enemys[1].helicoopter[9] = nil
enemys[1].helicoopter[10] = nil
enemys[1].helicoopter[11] = nil
enemys[1].helicoopter[12] = nil




enemys[2].helicoopter[1] = nil
enemys[2].helicoopter[2] = nil
enemys[2].helicoopter[3] = nil
enemys[2].helicoopter[4] = nil
enemys[2].helicoopter[5] = nil
enemys[2].helicoopter[6] = nil
enemys[2].helicoopter[7] = nil
enemys[2].helicoopter[8] = nil
enemys[2].helicoopter[9] = nil
enemys[2].helicoopter[10] = nil
enemys[2].helicoopter[11] = nil
enemys[2].helicoopter[12] = nil



CROWENEMY_SHOOT = nil
CROWENEMY_DIE = nil

CROWENEMYNUMBER2_SHOOT = nil
CROWENEMYNUMBER2_DIE = nil

CROWENEMYNUMBER3_SHOOT = nil
CROWENEMYNUMBER3_DIE = nil


bulletE1 = nil
bulletE2 = nil
bulletE3 = nil



boss.BULLET_IMG = nil

boss.BULLET_IMGS[1] = nil
boss.BULLET_IMGS[2] = nil
boss.BULLET_IMGS[3] = nil
boss.BULLET_IMGS[4] = nil
boss.BULLET_IMGS[5] = nil
boss.BULLET_IMGS[6] = nil
boss.BULLET_IMGS[7] = nil
boss.BULLET_IMGS[8] = nil
boss.BULLET_IMGS[9] = nil
boss.BULLET_IMGS[10] = nil
boss.BULLET_IMGS[11] = nil
boss.BULLET_IMGS[12] = nil
boss.BULLET_IMGS[13] = nil
boss.BULLET_IMGS[14] = nil
boss.BULLET_IMGS[15] = nil
boss.BULLET_IMGS[16] = nil
boss.BULLET_IMGS[17] = nil
boss.BULLET_IMGS[18] = nil
boss.BULLET_IMGS[19] = nil
boss.BULLET_IMGS[20] = nil
boss.BULLET_IMGS[21] = nil
boss.BULLET_IMGS[22] = nil
boss.BULLET_IMGS[23] = nil
boss.BULLET_IMGS[24] = nil
boss.BULLET_IMGS[25] = nil
boss.BULLET_IMGS[26] = nil









boss.BOSSIMAGES.BOSS_ATTACK[1] = nil
boss.BOSSIMAGES.BOSS_ATTACK[2] = nil
boss.BOSSIMAGES.BOSS_ATTACK[3] = nil
boss.BOSSIMAGES.BOSS_ATTACK[4] = nil
boss.BOSSIMAGES.BOSS_ATTACK[5] = nil
boss.BOSSIMAGES.BOSS_ATTACK[6] = nil
boss.BOSSIMAGES.BOSS_ATTACK[7] = nil
boss.BOSSIMAGES.BOSS_ATTACK[8] = nil
boss.BOSSIMAGES.BOSS_ATTACK[9] = nil
boss.BOSSIMAGES.BOSS_ATTACK[10] = nil
boss.BOSSIMAGES.BOSS_ATTACK[11] = nil
boss.BOSSIMAGES.BOSS_ATTACK[12] = nil
boss.BOSSIMAGES.BOSS_ATTACK[13] = nil
boss.BOSSIMAGES.BOSS_ATTACK[14] = nil
boss.BOSSIMAGES.BOSS_ATTACK[15] = nil
boss.BOSSIMAGES.BOSS_ATTACK[16] = nil
boss.BOSSIMAGES.BOSS_ATTACK[17] = nil
boss.BOSSIMAGES.BOSS_ATTACK[18] = nil
boss.BOSSIMAGES.BOSS_ATTACK[19] = nil
boss.BOSSIMAGES.BOSS_ATTACK[20] = nil
boss.BOSSIMAGES.BOSS_ATTACK[21] = nil

BOSS_WALKING[1] = nil
BOSS_WALKING[2] = nil
BOSS_WALKING[3] = nil
BOSS_WALKING[4] = nil
BOSS_WALKING[5] = nil
BOSS_WALKING[6] = nil
BOSS_WALKING[7] = nil
BOSS_WALKING[8] = nil
BOSS_WALKING[9] = nil
BOSS_WALKING[10] = nil
BOSS_WALKING[11] = nil
BOSS_WALKING[12] = nil



boss.BOSSIMAGES.BOSS_WAIT[1] = nil
boss.BOSSIMAGES.BOSS_WAIT[2] = nil
boss.BOSSIMAGES.BOSS_WAIT[3] = nil
boss.BOSSIMAGES.BOSS_WAIT[4] = nil
boss.BOSSIMAGES.BOSS_WAIT[5] = nil
boss.BOSSIMAGES.BOSS_WAIT[6] = nil
boss.BOSSIMAGES.BOSS_WAIT[7] = nil
boss.BOSSIMAGES.BOSS_WAIT[8] = nil
boss.BOSSIMAGES.BOSS_WAIT[9] = nil
boss.BOSSIMAGES.BOSS_WAIT[10] = nil
boss.BOSSIMAGES.BOSS_WAIT[11] = nil






boss.BOSSIMAGES.BOSS_GETHIT[1] = nil
boss.BOSSIMAGES.BOSS_GETHIT[2] = nil




 

boss.img = nil


BOSS_DEAD = nil


boss.helper.helicoopter[1] = nil
boss.helper.helicoopter[2] = nil
boss.helper.helicoopter[3] = nil
boss.helper.helicoopter[4] = nil
boss.helper.helicoopter[5] = nil
boss.helper.helicoopter[6] = nil
boss.helper.helicoopter[7] = nil
boss.helper.helicoopter[8] = nil
boss.helper.helicoopter[9] = nil
boss.helper.helicoopter[10] = nil
boss.helper.helicoopter[11] = nil
boss.helper.helicoopter[12] = nil







boss2.BULLET_IMG = nil

boss2.BULLET_IMGS[1] = nil
boss2.BULLET_IMGS[2] = nil
boss2.BULLET_IMGS[3] = nil
boss2.BULLET_IMGS[4] = nil
boss2.BULLET_IMGS[5] = nil
boss2.BULLET_IMGS[6] = nil
boss2.BULLET_IMGS[7] = nil





JAG = nil
JAG_NOT = nil




boss2.BOSSIMAGES.BOSS_ATTACK[1] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[2] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[3] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[4] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[5] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[6] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[7] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[8] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[9] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[10] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[11] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[12] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[13] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[14] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[15] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[16] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[17] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[18] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[19] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[20] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[21] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[22] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[23] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[24] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[25] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[26] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[27] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[28] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[29] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[30] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[31] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[32] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[33] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[34] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[35] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[36] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[37] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[38] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[39] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[40] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[41] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[42] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[43] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[44] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[45] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[46] = nil
boss2.BOSSIMAGES.BOSS_ATTACK[47] = nil



BOSS2_WALKING[1] = nil
BOSS2_WALKING[2] = nil
BOSS2_WALKING[3] = nil
BOSS2_WALKING[4] = nil
BOSS2_WALKING[5] = nil
BOSS2_WALKING[6] = nil
BOSS2_WALKING[7] = nil
BOSS2_WALKING[8] = nil
BOSS2_WALKING[9] = nil
BOSS2_WALKING[10] = nil
BOSS2_WALKING[11] = nil
BOSS2_WALKING[12] = nil
BOSS2_WALKING[13] = nil
BOSS2_WALKING[14] = nil



boss2.BOSSIMAGES.BOSS_WAIT[1] = nil
boss2.BOSSIMAGES.BOSS_WAIT[2] = nil
boss2.BOSSIMAGES.BOSS_WAIT[3] = nil
boss2.BOSSIMAGES.BOSS_WAIT[4] = nil
boss2.BOSSIMAGES.BOSS_WAIT[5] = nil
boss2.BOSSIMAGES.BOSS_WAIT[6] = nil
boss2.BOSSIMAGES.BOSS_WAIT[7] = nil
boss2.BOSSIMAGES.BOSS_WAIT[8] = nil
boss2.BOSSIMAGES.BOSS_WAIT[9] = nil
boss2.BOSSIMAGES.BOSS_WAIT[10] = nil
boss2.BOSSIMAGES.BOSS_WAIT[11] = nil
boss2.BOSSIMAGES.BOSS_WAIT[12] = nil
boss2.BOSSIMAGES.BOSS_WAIT[13] = nil
boss2.BOSSIMAGES.BOSS_WAIT[14] = nil
boss2.BOSSIMAGES.BOSS_WAIT[15] = nil
boss2.BOSSIMAGES.BOSS_WAIT[16] = nil
boss2.BOSSIMAGES.BOSS_WAIT[17] = nil
boss2.BOSSIMAGES.BOSS_WAIT[18] = nil
boss2.BOSSIMAGES.BOSS_WAIT[19] = nil
boss2.BOSSIMAGES.BOSS_WAIT[20] = nil




boss2.BOSSIMAGES.BOSS_GETHIT[1] = nil
boss2.BOSSIMAGES.BOSS_GETHIT[2] = nil
boss2.BOSSIMAGES.BOSS_GETHIT[3] = nil
boss2.BOSSIMAGES.BOSS_GETHIT[4] = nil


BBullet = nil
boss2.img = nil


BOSS2_DEAD = nil

boss3.BULLET_IMG = nil

boss3.BULLET_IMGS[1] = nil
boss3.BULLET_IMGS[2] = nil
boss3.BULLET_IMGS[3] = nil
boss3.BULLET_IMGS[4] = nil
boss3.BULLET_IMGS[5] = nil
boss3.BULLET_IMGS[6] = nil
boss3.BULLET_IMGS[7] = nil
boss3.BULLET_IMGS[8] = nil
boss3.BULLET_IMGS[9] = nil
boss3.BULLET_IMGS[10] = nil
boss3.BULLET_IMGS[11] = nil
boss3.BULLET_IMGS[12] = nil
boss3.BULLET_IMGS[13] = nil
boss3.BULLET_IMGS[14] = nil
boss3.BULLET_IMGS[15] = nil
boss3.BULLET_IMGS[16] = nil
boss3.BULLET_IMGS[17] = nil
boss3.BULLET_IMGS[18] = nil
boss3.BULLET_IMGS[19] = nil
boss3.BULLET_IMGS[20] = nil
boss3.BULLET_IMGS[21] = nil
boss3.BULLET_IMGS[22] = nil
boss3.BULLET_IMGS[23] = nil
boss3.BULLET_IMGS[24] = nil
boss3.BULLET_IMGS[25] = nil
boss3.BULLET_IMGS[26] = nil
boss3.BULLET_IMGS[27] = nil
boss3.BULLET_IMGS[28] = nil
boss3.BULLET_IMGS[29] = nil
boss3.BULLET_IMGS[30] = nil
boss3.BULLET_IMGS[31] = nil
boss3.BULLET_IMGS[32] = nil
boss3.BULLET_IMGS[33] = nil
boss3.BULLET_IMGS[34] = nil





boss3.BULLET1_IMG = nil

boss3.BULLET1_IMGS[1] = nil
boss3.BULLET1_IMGS[2] = nil
boss3.BULLET1_IMGS[3] = nil
boss3.BULLET1_IMGS[4] = nil
boss3.BULLET1_IMGS[5] = nil
boss3.BULLET1_IMGS[6] = nil


boss3.BULLET1_2IMG = nil

boss3.BULLET1_2IMGS[1] = nil
boss3.BULLET1_2IMGS[2] = nil
boss3.BULLET1_2IMGS[3] = nil
boss3.BULLET1_2IMGS[4] = nil
boss3.BULLET1_2IMGS[5] = nil
boss3.BULLET1_2IMGS[6] = nil


boss3.BULLET2_IMG = nil

boss3.BULLET2_IMGS[1] = nil
boss3.BULLET2_IMGS[2] = nil
boss3.BULLET2_IMGS[3] = nil
boss3.BULLET2_IMGS[4] = nil
boss3.BULLET2_IMGS[5] = nil
boss3.BULLET2_IMGS[6] = nil
boss3.BULLET2_IMGS[7] = nil
boss3.BULLET2_IMGS[8] = nil




boss3.BOSSIMAGES.BOSS_GETHIT[1] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[2] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[3] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[4] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[5] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[6] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[7] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[8] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[9] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[10] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[11] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[12] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[13] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[14] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[15] = nil
boss3.BOSSIMAGES.BOSS_GETHIT[16] = nil




boss3.BOSSIMAGES.BOSS3_TO_LIGHT[1] = nil
boss3.BOSSIMAGES.BOSS3_TO_LIGHT[2] = nil
boss3.BOSSIMAGES.BOSS3_TO_LIGHT[3] = nil
boss3.BOSSIMAGES.BOSS3_TO_LIGHT[4] = nil
boss3.BOSSIMAGES.BOSS3_TO_LIGHT[5] = nil
boss3.BOSSIMAGES.BOSS3_TO_LIGHT[6] = nil
boss3.BOSSIMAGES.BOSS3_TO_LIGHT[7] = nil
boss3.BOSSIMAGES.BOSS3_TO_LIGHT[8] = nil



boss3.BOSSIMAGES.BOSS3_TO_FIRE[1] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[2] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[3] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[4] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[5] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[6] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[7] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[8] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[9] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[10] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[11] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[12] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[13] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[14] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[15] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[16] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[17] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[18] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[19] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[20] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[21] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[22] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[23] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[24] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[25] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[26] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[27] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[28] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[29] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[30] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[31] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[32] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[33] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[34] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[35] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[36] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[37] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[38] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[39] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[40] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[41] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[42] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[43] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[44] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[45] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[46] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[47] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[48] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[49] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[50] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[51] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[52] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[53] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[54] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[55] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[56] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[57] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[58] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[59] = nil
boss3.BOSSIMAGES.BOSS3_TO_FIRE[60] = nil



boss3.BOSSIMAGES.BOSS3_TO_GLAD[1] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[2] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[3] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[4] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[5] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[6] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[7] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[8] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[9] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[10] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[11] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[12] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[13] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[14] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[15] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[16] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[17] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[18] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[19] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[20] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[21] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[22] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[23] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[24] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[25] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[26] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[27] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[28] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[29] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[30] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[31] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[32] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[33] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[34] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[35] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[36] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[37] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[38] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[39] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[40] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[41] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[42] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[43] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[44] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[45] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[46] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[47] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[48] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[49] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[50] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[51] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[52] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[53] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[54] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[55] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[56] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[57] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[58] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[59] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[60] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[61] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[62] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[63] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[64] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[65] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[66] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[67] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[68] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[69] = nil
boss3.BOSSIMAGES.BOSS3_TO_GLAD[70] = nil




boss3.BOSSIMAGES.BOSS3_TO_GOUL[1] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[2] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[3] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[4] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[5] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[6] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[7] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[8] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[9] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[10] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[11] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[12] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[13] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[14] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[15] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[16] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[17] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[18] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[19] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[20] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[21] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[22] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[23] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[24] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[25] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[26] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[27] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[28] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[29] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[30] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[31] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[32] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[33] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[34] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[35] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[36] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[37] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[38] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[39] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[40] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[41] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[42] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[43] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[44] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[45] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[46] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[47] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[48] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[49] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[50] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[51] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[52] = nil
boss3.BOSSIMAGES.BOSS3_TO_GOUL[53] = nil




boss3.BOSSIMAGES.BOSS3_TO_SKEL[1] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[2] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[3] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[4] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[5] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[6] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[7] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[8] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[9] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[10] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[11] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[12] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[13] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[14] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[15] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[16] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[17] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[18] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[19] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[20] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[21] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[22] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[23] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[24] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[25] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[26] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[27] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[28] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[29] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[30] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[31] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[32] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[33] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[34] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[35] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[36] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[37] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[38] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[39] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[40] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[41] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[42] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[43] = nil
boss3.BOSSIMAGES.BOSS3_TO_SKEL[44] = nil




boss3.BOSSIMAGES.BOSS3_TO_CREEP[1] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[2] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[3] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[4] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[5] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[6] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[7] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[8] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[9] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[10] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[11] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[12] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[13] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[14] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[15] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[16] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[17] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[18] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[19] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[20] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[21] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[22] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[23] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[24] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[25] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[26] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[27] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[28] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[29] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[30] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[31] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[32] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[33] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[34] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[35] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[36] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[37] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[38] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[39] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[40] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[41] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[42] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[43] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[44] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[45] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[46] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[47] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[48] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[49] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[50] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[51] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[52] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[53] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[54] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[55] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[56] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[57] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[58] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[59] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[60] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[61] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[62] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[63] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[64] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[65] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[67] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[68] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[69] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[70] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[71] = nil
boss3.BOSSIMAGES.BOSS3_TO_CREEP[72] = nil




BOSS3_WALKING[1] = nil
BOSS3_WALKING[2] = nil
BOSS3_WALKING[3] = nil
BOSS3_WALKING[4] = nil
BOSS3_WALKING[5] = nil
BOSS3_WALKING[6] = nil
BOSS3_WALKING[7] = nil
BOSS3_WALKING[8] = nil
BOSS3_WALKING[9] = nil
BOSS3_WALKING[10] = nil
BOSS3_WALKING[11] = nil
BOSS3_WALKING[12] = nil
BOSS3_WALKING[13] = nil
BOSS3_WALKING[14] = nil

BBullet = nil
BOSS3_DEAD = nil





end	