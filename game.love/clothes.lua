function new_clothes()

local self = {}


self.head_right = {img = nil , x = nil , y = nil}
self.head_left = {img = nil , x = nil , y = nil}
self.hat_id = nil
self.belt = {img = nil , x_d = nil , y_d = nil , x_r = nil , y_r = nil , x_l = nil , y_l = nil , scale_x = nil , scale_y = nil , ro_d = nil , ro_r = nil , ro_l = nil}
self.belt_id = nil
self.show_cloth_in_room = {x = 200 , y = 170}



self.set_first_hat_id = function()


if not love.filesystem.exists("ALLhats_tg.txt") then
self.set_hat_id(0)
else
jupiter = require "jupiter"
newData = jupiter.load("ALLhats_tg.txt")
self.hat_id = newData[1]
end


end



self.set_first_belt_id = function()


if not love.filesystem.exists("ALLbelts_tg.txt") then
self.set_belt_id(0)
else
jupiter = require "jupiter"
newData = jupiter.load("ALLbelts_tg.txt")
self.belt_id = newData[1]
end


end



self.set_hat_id = function(id)

jupiter = require "jupiter"
data = {_fileName = "ALLhats_tg.txt", id}
success = jupiter.save(data)
self.hat_id = id


end



self.set_belt_id = function(id)

jupiter = require "jupiter"
data = {_fileName = "ALLbelts_tg.txt", id}
success = jupiter.save(data)
self.belt_id = id


end



self.set_hat = function()


if self.hat_id == 0 then

self.head_right.img = love.graphics.newImage("hat0_right.png")
self.head_left.img = love.graphics.newImage("hat0_left.png")

elseif self.hat_id == 1 then

self.head_right.img = love.graphics.newImage("hat1_right.png")
self.head_left.img = love.graphics.newImage("hat1_left.png")

elseif self.hat_id == 2 then

self.head_right.img = love.graphics.newImage("hat2_right.png")
self.head_left.img = love.graphics.newImage("hat2_left.png")

elseif self.hat_id == 3 then

self.head_right.img = love.graphics.newImage("hat3_right.png")
self.head_left.img = love.graphics.newImage("hat3_left.png")

elseif self.hat_id == 4 then

self.head_right.img = love.graphics.newImage("hat4_right.png")
self.head_left.img = love.graphics.newImage("hat4_left.png")

elseif self.hat_id == 5 then

self.head_right.img = love.graphics.newImage("hat5_right.png")
self.head_left.img = love.graphics.newImage("hat5_left.png")

elseif self.hat_id == 6 then

self.head_right.img = love.graphics.newImage("hat6_right.png")
self.head_left.img = love.graphics.newImage("hat6_left.png")

elseif self.hat_id == 7 then

self.head_right.img = love.graphics.newImage("hat7_right.png")
self.head_left.img = love.graphics.newImage("hat7_left.png")

elseif self.hat_id == 8 then

self.head_right.img = love.graphics.newImage("hat8_right.png")
self.head_left.img = love.graphics.newImage("hat8_left.png")

elseif self.hat_id == 9 then

self.head_right.img = love.graphics.newImage("hat9_right.png")
self.head_left.img = love.graphics.newImage("hat9_left.png")

elseif self.hat_id == 10 then

self.head_right.img = love.graphics.newImage("hat10_right.png")
self.head_left.img = love.graphics.newImage("hat10_left.png")

end

end



self.set_belt = function()

if self.belt_id == 0 then

self.belt.img = love.graphics.newImage("belt0.png")

elseif self.belt_id == 1 then

self.belt.img = love.graphics.newImage("belt1.png")

elseif self.belt_id == 2 then

self.belt.img = love.graphics.newImage("belt2.png")

elseif self.belt_id == 3 then

self.belt.img = love.graphics.newImage("belt3.png")

elseif self.belt_id == 4 then

self.belt.img = love.graphics.newImage("belt4.png")

elseif self.belt_id == 5 then

self.belt.img = love.graphics.newImage("belt5.png")

elseif self.belt_id == 6 then

self.belt.img = love.graphics.newImage("belt6.png")

elseif self.belt_id == 7 then

self.belt.img = love.graphics.newImage("belt7.png")

elseif self.belt_id == 8 then

self.belt.img = love.graphics.newImage("belt8.png")

elseif self.belt_id == 9 then

self.belt.img = love.graphics.newImage("belt9.png")

elseif self.belt_id == 10 then

self.belt.img = love.graphics.newImage("belt10.png")

end

end



self.update_hat_position = function(player,ducking)

screen_width = love.graphics.getWidth()
screen_height = love.graphics.getHeight()
width = 800/2
height = 530/2
scale_x = (screen_width/width)
scale_y = (screen_height/height)

if self.hat_id == 0 then

if ducking == false then

self.head_right.x = player.x
self.head_right.y = player.y - 23/2 * scale_y

else

self.head_right.x = player.x + 5/2 * scale_x
self.head_right.y = player.y + 15/2 * scale_y

end


self.head_left.y = player.y - 23/2 * scale_y
self.head_left.x = player.x + 14/2 * scale_x

elseif self.hat_id == 1 then

if ducking == false then

self.head_right.x = player.x - 10/2 * scale_x
self.head_right.y = player.y - 38/2 * scale_y

else

self.head_right.x = player.x - 9/2 * scale_x
self.head_right.y = player.y + 5/2 * scale_y

end


self.head_left.y = player.y - 38/2 * scale_y
self.head_left.x = player.x + 25/2 * scale_x

elseif self.hat_id == 2 then

if ducking == false then

self.head_right.x = player.x - 5/2 * scale_x
self.head_right.y = player.y - 48/2 * scale_y

else

self.head_right.x = player.x - 4/2 * scale_x
self.head_right.y = player.y - 4/2 * scale_y

end
 

self.head_left.y = player.y - 48/2 * scale_y
self.head_left.x = player.x + 20/2 * scale_x

elseif self.hat_id == 3 then

if ducking == false then

self.head_right.x = player.x - 9/2 * scale_x
self.head_right.y = player.y - 48/2 * scale_y

else

self.head_right.x = player.x - 8/2 * scale_x 
self.head_right.y = player.y - 4/2 * scale_y

end


self.head_left.y = player.y - 48/2 * scale_y
self.head_left.x = player.x + 26/2 * scale_x

elseif self.hat_id == 4 then

if ducking == false then

self.head_right.x = player.x - 9/2 * scale_x
self.head_right.y = player.y - 48/2 * scale_y

else

self.head_right.x = player.x - 8/2 * scale_x
self.head_right.y = player.y - 4/2 * scale_y

end


self.head_left.y = player.y - 48/2 * scale_y
self.head_left.x = player.x + 26/2 * scale_x

elseif self.hat_id == 5 then

if ducking == false then

self.head_right.x = player.x + 14/2 * scale_x
self.head_right.y = player.y - 26/2 * scale_y

else

self.head_right.x = player.x + 10/2 * scale_x
self.head_right.y = player.y + 18/2 * scale_y

end

 
self.head_left.y = player.y - 26/2 * scale_y 
self.head_left.x = player.x + 22/2 * scale_x

elseif self.hat_id == 6 then


if ducking == false then

self.head_right.x = player.x - 4/2 * scale_x
self.head_right.y = player.y - 38/2 * scale_y

else

self.head_right.x = player.x - 3/2 * scale_x
self.head_right.y = player.y + 9/2 * scale_y

end


self.head_left.y = player.y - 38/2 * scale_y
self.head_left.x = player.x + 19/2 * scale_x

elseif self.hat_id == 7 then

if ducking == false then

self.head_right.x = player.x - 2/2 * scale_x
self.head_right.y = player.y - 57/2 * scale_y 

else

self.head_right.x = player.x - 1/2 * scale_x
self.head_right.y = player.y - 10/2 * scale_y

end


self.head_left.y = player.y - 57/2 * scale_y
self.head_left.x = player.x + 21/2 * scale_x


elseif self.hat_id == 8 then

if ducking == false then

self.head_right.x = player.x + 13/2 * scale_x
self.head_right.y = player.y - 31/2 * scale_y

else

self.head_right.x = player.x + 14/2 * scale_x
self.head_right.y = player.y + 5 * scale_y

end


self.head_left.y = player.y - 31/2 * scale_y
self.head_left.x = player.x + 16/2 * scale_x

elseif self.hat_id == 9 then

if ducking == false then

self.head_right.x = player.x + 3/2 * scale_x
self.head_right.y = player.y - 59/2 * scale_y

else

self.head_right.x = player.x + 4/2 * scale_x
self.head_right.y = player.y - 8 * scale_y

end


self.head_left.y = player.y - 59/2 * scale_y
self.head_left.x = player.x + 24/2 * scale_x

elseif self.hat_id == 10 then

if ducking == false then

self.head_right.x = player.x - 2 * scale_x
self.head_right.y = player.y - 56/2 * scale_y

else

self.head_right.x = player.x - 1/2 * scale_x
self.head_right.y = player.y - 8 * scale_y

end


self.head_left.y = player.y - 56/2 * scale_y
self.head_left.x = player.x + 19/2 * scale_x

end

end








self.update_belt_position = function(player)

screen_width = love.graphics.getWidth()
screen_height = love.graphics.getHeight()
width = 800/2
height = 530/2
scale_x = (screen_width/width)
scale_y = (screen_height/height)

if self.belt_id == 0 then

self.belt.ro_d = -0.05
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/3.6
self.belt.scale_y = scale_y/1.6
self.belt.x_d = player.x + 5/2 * scale_x
self.belt.y_d = player.y + 65/2 * scale_y
self.belt.x_r = player.x + 3 * scale_x
self.belt.y_r = player.y + 24/2 * scale_y
self.belt.x_l = player.x + 73/2 * scale_x
self.belt.y_l = player.y + 24/2 * scale_y


elseif self.belt_id == 1 then

self.belt.ro_d = 0
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/2.2
self.belt.scale_y = scale_y/1.7
self.belt.x_d = player.x + 5/2 * scale_x
self.belt.y_d = player.y + 55/2 * scale_y
self.belt.x_r = player.x
self.belt.y_r = player.y + 23/2 * scale_y
self.belt.x_l = player.x + 75/2 * scale_x
self.belt.y_l = player.y + 23/2 * scale_y


elseif self.belt_id == 2 then

self.belt.ro_d = -0.2
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/2.2
self.belt.scale_y = scale_y/1.7
self.belt.x_d = player.x
self.belt.y_d = player.y + 70/2 * scale_y
self.belt.x_r = player.x
self.belt.y_r = player.y + 23/2 * scale_y
self.belt.x_l = player.x + 75/2 * scale_x
self.belt.y_l = player.y + 23/2 * scale_y


elseif self.belt_id == 3 then

self.belt.ro_d = 0
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/2.5
self.belt.scale_y = scale_y/2.1
self.belt.x_d = player.x + 2 * scale_x
self.belt.y_d = player.y + 68/2 * scale_y
self.belt.x_r = player.x + 1 * scale_x
self.belt.y_r = player.y + 24/2 * scale_y
self.belt.x_l = player.x + 75/2 * scale_x
self.belt.y_l = player.y + 24/2 * scale_y


elseif self.belt_id == 4 then

self.belt.ro_d = 0
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/2.2
self.belt.scale_y = scale_y/1.4
self.belt.x_d = player.x + 5/2 * scale_x
self.belt.y_d = player.y + 65/2 * scale_y
self.belt.x_r = player.x 
self.belt.y_r = player.y + 24/2 * scale_y
self.belt.x_l = player.x + 73/2 * scale_x
self.belt.y_l = player.y + 24/2 * scale_y


elseif self.belt_id == 5 then

self.belt.ro_d = -0.05
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/3.45
self.belt.scale_y = scale_y/2.25
self.belt.x_d = player.x + 3/2 * scale_x
self.belt.y_d = player.y + 65/2 * scale_y
self.belt.x_r = player.x + 1 * scale_x
self.belt.y_r = player.y + 23/2 * scale_y
self.belt.x_l = player.x + 73/2 * scale_x
self.belt.y_l = player.y + 23/2 * scale_y


elseif self.belt_id == 6 then

self.belt.ro_d = 0
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/2.8
self.belt.scale_y = scale_y/2.1
self.belt.x_d = player.x - 1 * scale_x
self.belt.y_d = player.y + 65/2 * scale_y
self.belt.x_r = player.x - 2 * scale_x
self.belt.y_r = player.y + 25/2 * scale_y
self.belt.x_l = player.x + 80/2 * scale_x
self.belt.y_l = player.y + 25/2 * scale_y


elseif self.belt_id == 7 then

self.belt.ro_d = 0
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/3.2
self.belt.scale_y = scale_y/1.95
self.belt.x_d = player.x + 3 * scale_x
self.belt.y_d = player.y + 62/2 * scale_y
self.belt.x_r = player.x + 2 * scale_x
self.belt.y_r = player.y + 24/2 * scale_y
self.belt.x_l = player.x + 69/2 * scale_x
self.belt.y_l = player.y + 24/2 * scale_y


elseif self.belt_id == 8 then

self.belt.ro_d = 0
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/3.65
self.belt.scale_y = scale_y/2.35
self.belt.x_d = player.x + 3 * scale_x
self.belt.y_d = player.y + 62/2 * scale_y
self.belt.x_r = player.x + 3 * scale_x
self.belt.y_r = player.y + 27/2 * scale_y
self.belt.x_l = player.x + 69/2 * scale_x
self.belt.y_l = player.y + 27/2 * scale_y


elseif self.belt_id == 9 then

self.belt.ro_d = 0
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/3
self.belt.scale_y = scale_y/2
self.belt.x_d = player.x + 1 * scale_x
self.belt.y_d = player.y + 66/2 * scale_y
self.belt.x_r = player.x 
self.belt.y_r = player.y + 25/2 * scale_y
self.belt.x_l = player.x + 75/2 * scale_x
self.belt.y_l = player.y + 25/2 * scale_y


elseif self.belt_id == 10 then

self.belt.ro_d = 0
self.belt.ro_r = 0
self.belt.ro_l = 0
self.belt.scale_x = scale_x/3
self.belt.scale_y = scale_y/2
self.belt.x_d = player.x + 3 * scale_x
self.belt.y_d = player.y + 68/2 * scale_y
self.belt.x_r = player.x + 3 * scale_x
self.belt.y_r = player.y + 27/2 * scale_y
self.belt.x_l = player.x + 73/2 * scale_x
self.belt.y_l = player.y + 27/2 * scale_y


end

end











self.draw_hat_in_room = function(show_cloth_in_room,id)

screen_width = love.graphics.getWidth()
screen_height = love.graphics.getHeight()
width = 800/2
height = 530/2
scale_x = (screen_width/width)
scale_y = (screen_height/height)

if id == 0 then

local img = love.graphics.newImage("hat0_right.png")

local x = show_cloth_in_room.x * scale_x
local y = (show_cloth_in_room.y - 23/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 1 then

local img = love.graphics.newImage("hat1_right.png")
local x = (show_cloth_in_room.x - 10/2) * scale_x
local y = (show_cloth_in_room.y - 38/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 2 then

local img = love.graphics.newImage("hat2_right.png")
local x = (show_cloth_in_room.x - 5/2 )* scale_x
local y = (show_cloth_in_room.y - 48/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 3 then

local img = love.graphics.newImage("hat3_right.png")
local x = (show_cloth_in_room.x - 9/2 )* scale_x
local y = (show_cloth_in_room.y - 48/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 4 then

local img = love.graphics.newImage("hat4_right.png")
local x = (show_cloth_in_room.x - 9/2 )* scale_x
local y = (show_cloth_in_room.y - 48/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 5 then

local img = love.graphics.newImage("hat5_right.png")
local x = (show_cloth_in_room.x + 14/2) * scale_x
local y = (show_cloth_in_room.y - 26/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 6 then

local img = love.graphics.newImage("hat6_right.png")
local x = (show_cloth_in_room.x - 4/2 )* scale_x
local y = (show_cloth_in_room.y - 38/2) * scale_y


love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 7 then

local img = love.graphics.newImage("hat7_right.png")
local x = (show_cloth_in_room.x - 2/2 )* scale_x
local y = (show_cloth_in_room.y - 57/2) * scale_y 

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 8 then

local img = love.graphics.newImage("hat8_right.png")
local x = (show_cloth_in_room.x + 13/2) * scale_x
local y = (show_cloth_in_room.y - 31/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 9 then

local img = love.graphics.newImage("hat9_right.png")
local x = (show_cloth_in_room.x + 3/2 )* scale_x
local y = (show_cloth_in_room.y - 59/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

elseif id == 10 then

local img = love.graphics.newImage("hat10_right.png")
local x = (show_cloth_in_room.x - 2) * scale_x
local y = (show_cloth_in_room.y - 56/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x , scale_y)

end

end




self.draw_belt_in_room = function(show_cloth_in_room,id)

screen_width = love.graphics.getWidth()
screen_height = love.graphics.getHeight()
width = 800/2
height = 530/2
scale_x = (screen_width/width)
scale_y = (screen_height/height)

if id == 0 then

local img = love.graphics.newImage("belt0.png")

local x = (show_cloth_in_room.x + 3) * scale_x
local y = (show_cloth_in_room.y + 24/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/3.6 , scale_y/1.6)

elseif id == 1 then

local img = love.graphics.newImage("belt1.png")
local x = (show_cloth_in_room.x ) * scale_x
local y = (show_cloth_in_room.y + 23/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/2.2 , scale_y/1.7)

elseif id == 2 then

local img = love.graphics.newImage("belt2.png")
local x = (show_cloth_in_room.x  )* scale_x
local y = (show_cloth_in_room.y + 23/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/2.2 , scale_y/1.7)

elseif id == 3 then

local img = love.graphics.newImage("belt3.png")
local x = (show_cloth_in_room.x + 1 )* scale_x
local y = (show_cloth_in_room.y + 24/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/2.5 , scale_y/2.1)

elseif id == 4 then

local img = love.graphics.newImage("belt4.png")
local x = (show_cloth_in_room.x )* scale_x
local y = (show_cloth_in_room.y + 24/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/2.2 , scale_y/1.4)

elseif id == 5 then

local img = love.graphics.newImage("belt5.png")
local x = (show_cloth_in_room.x + 1) * scale_x
local y = (show_cloth_in_room.y + 23/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/3.45 , scale_y/2.25)

elseif id == 6 then

local img = love.graphics.newImage("belt6.png")
local x = (show_cloth_in_room.x - 2 )* scale_x
local y = (show_cloth_in_room.y + 25/2) * scale_y


love.graphics.draw(img, x , y , 0.02 , scale_x/2.8 , scale_y/2.1)

elseif id == 7 then

local img = love.graphics.newImage("belt7.png")
local x = (show_cloth_in_room.x + 2 )* scale_x
local y = (show_cloth_in_room.y + 24/2) * scale_y 

love.graphics.draw(img, x , y , 0 , scale_x/3.2 , scale_y/1.95)

elseif id == 8 then

local img = love.graphics.newImage("belt8.png")
local x = (show_cloth_in_room.x + 3) * scale_x
local y = (show_cloth_in_room.y + 27/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/3.65 , scale_y/2.35)

elseif id == 9 then

local img = love.graphics.newImage("belt9.png")
local x = (show_cloth_in_room.x  )* scale_x
local y = (show_cloth_in_room.y + 25/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/3 , scale_y/2)

elseif id == 10 then

local img = love.graphics.newImage("belt10.png")
local x = (show_cloth_in_room.x + 3) * scale_x
local y = (show_cloth_in_room.y + 27/2) * scale_y

love.graphics.draw(img, x , y , 0 , scale_x/3 , scale_y/2)

end

end





return self


end
