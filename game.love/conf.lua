function love.conf(t)
t.tittle = "my first excersize"
t.window.width = 800/2
t.window.height = 530/2
t.console = true
t.name = "mmm"
t.externalstorage = true
t.window.fullscreen = love._os == "Android" or love._os == "iOS"
end